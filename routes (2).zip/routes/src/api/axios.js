import axios from "axios";

/* 🔁 Convert all object keys to lowercase (deep) */
const toLowerCaseKeys = (data) => {
  if (Array.isArray(data)) {
    return data.map(toLowerCaseKeys);
  }

  if (data !== null && typeof data === "object") {
    return Object.keys(data).reduce((acc, key) => {
      acc[key.toLowerCase()] = toLowerCaseKeys(data[key]);
      return acc;
    }, {});
  }

  return data;
};

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000",
  withCredentials: true,
});

/* ✅ RESPONSE INTERCEPTOR */
api.interceptors.response.use(
  (response) => {
    response.data = toLowerCaseKeys(response.data);
    return response;
  },
  (error) => Promise.reject(error)
);

export default api;
