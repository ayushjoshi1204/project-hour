import express from "express";
import { getPool } from "../config/azure_db.js";
import { authenticateToken, authorizeAdminOrPM } from "../middleware/auth.js";

const router = express.Router();

// =======================
// GET ALL ALLOCATIONS
// =======================
router.get("/", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(`
      SELECT a.*, e.Name AS EmployeeName, p.ProjectCode, p.Entity
      FROM Allocations a
      JOIN Employees e ON a.EmployeeID = e.EmployeeID
      JOIN Projects p ON a.ProjectID = p.ProjectID
      ORDER BY a.AllocationID
    `);

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch allocations" });
  }
});

// =======================
// CREATE ALLOCATION
// =======================
router.post("/", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { employeeId, projectId, empName, role, allocatedHours } = req.body;

    const pool = await getPool();
    const request = pool.request();

    request
      .input("employeeId", employeeId)
      .input("projectId", projectId)
      .input("empName", empName)
      .input("role", role)
      .input("allocatedHours", allocatedHours);

    const result = await request.query(`
      INSERT INTO Allocations (EmployeeID, ProjectID, EmpName, Role, AllocatedHours)
      OUTPUT INSERTED.*
      VALUES (@employeeId, @projectId, @empName, @role, @allocatedHours)
    `);

    res.status(201).json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create allocation" });
  }
});

// =======================
// DELETE ALLOCATION
// =======================
router.delete("/:id", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.params.id);

    const result = await request.query(`
      DELETE FROM Allocations
      OUTPUT DELETED.AllocationID
      WHERE AllocationID = @id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Allocation not found" });

    res.json({ message: "Allocation deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete allocation" });
  }
});

export default router;
