import express from "express";
import bcrypt from "bcrypt";
import { getPool } from "../config/azure_db.js";
import { authenticateToken, authorizeAdminOrPM } from "../middleware/auth.js";

const router = express.Router();

const VALID_ROLES = ["admin", "employee", "pm"];

const EMPLOYEE_SELECT = `
  EmployeeID, EmpID, Name, Email, Role, DOJ, Status,
  Team, Tribe, WorkHoursPerWeek,
  CreatedAt, UpdatedAt
`;

// =======================
// GET ALL EMPLOYEES (Admin + PM)
// =======================
router.get("/", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees ORDER BY EmployeeID`
    );
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch employees" });
  }
});

// =======================
// GET EMPLOYEE BY ID
// =======================
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.params.id);

    const result = await request.query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees WHERE EmployeeID = @id`
    );

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Employee not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch employee" });
  }
});

// =======================
// GET EMPLOYEE BY EmpID
// =======================
router.get("/empid/:empid", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("empid", req.params.empid);

    const result = await request.query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees WHERE EmpID = @empid`
    );

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Employee not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch employee" });
  }
});

// =======================
// CREATE EMPLOYEE
// =======================
router.post("/", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { empId, name, email, password, role, doj } = req.body;

    if (!empId || !name || !email || !password || !role || !doj)
      return res.status(400).json({ error: "All fields are required" });

    if (!VALID_ROLES.includes(role))
      return res.status(400).json({ error: "Invalid role" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const pool = await getPool();
    const request = pool.request();

    request
      .input("empId", empId)
      .input("name", name)
      .input("email", email)
      .input("password", hashedPassword)
      .input("role", role)
      .input("doj", doj);

    const result = await request.query(`
      INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status)
      OUTPUT INSERTED.${EMPLOYEE_SELECT.replace(/,\s*$/g, "").replaceAll(", ", ", INSERTED.")}
      VALUES (@empId, @name, @email, @password, @role, @doj, 'active')
    `);

    res.status(201).json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create employee" });
  }
});

// =======================
// UPDATE EMPLOYEE
// =======================
router.put("/:id", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { empId, name, email, role, doj, status } = req.body;

    if (!empId || !name || !email || !role || !doj || !status)
      return res.status(400).json({ error: "All fields are required" });

    if (!VALID_ROLES.includes(role))
      return res.status(400).json({ error: "Invalid role" });

    const pool = await getPool();
    const request = pool.request();

    request
      .input("id", req.params.id)
      .input("empId", empId)
      .input("name", name)
      .input("email", email)
      .input("role", role)
      .input("doj", doj)
      .input("status", status);

    const result = await request.query(`
      UPDATE Employees
      SET EmpID=@empId, Name=@name, Email=@email, Role=@role, DOJ=@doj, Status=@status
      OUTPUT INSERTED.${EMPLOYEE_SELECT.replace(/,\s*$/g, "").replaceAll(", ", ", INSERTED.")}
      WHERE EmployeeID=@id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Employee not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update employee" });
  }
});

// =======================
// DELETE EMPLOYEE
// =======================
router.delete("/:id", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.params.id);

    const result = await request.query(`
      DELETE FROM Employees
      OUTPUT DELETED.EmployeeID
      WHERE EmployeeID=@id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Employee not found" });

    res.json({ message: "Employee deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete employee" });
  }
});

export default router;
