import express from "express";
import { getPool } from "../config/azure_db.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();

/* ================= HELPERS ================= */

function parsePeriod(q) {
  const year = Number(q.year);
  const month = Number(q.month);
  if (!year || !month || month < 1 || month > 12) {
    const err = new Error("Invalid year/month");
    err.status = 400;
    throw err;
  }
  const start = new Date(Date.UTC(year, month - 1, 1));
  const end = new Date(Date.UTC(year, month, 1));
  return { year, month, start, end };
}

function countWeekdays(start, end) {
  let count = 0;
  const d = new Date(start);
  while (d < end) {
    const day = d.getUTCDay();
    if (day !== 0 && day !== 6) count++;
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return count;
}

function clampPct(x) {
  return Math.max(0, Math.min(100, Number(x || 0)));
}

function iso(d) {
  return d.toISOString().slice(0, 10);
}

function yearlyAvailableHours(whpw, year) {
  const start = new Date(Date.UTC(year, 0, 1));
  const end = new Date(Date.UTC(year + 1, 0, 1));
  return Number(((whpw / 5) * countWeekdays(start, end)).toFixed(2));
}

/* ================= EMPLOYEE DASHBOARD ================= */

router.get("/employee/:employeeId", authenticateToken, async (req, res) => {
  try {
    const employeeId = Number(req.params.employeeId);
    const { year, month, start, end } = parsePeriod(req.query);

    if (
      req.user.role !== "admin" &&
      req.user.role !== "pm" &&
      req.user.employeeId !== employeeId
    ) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const pool = await getPool();

    /* Employee */
    const empRes = await pool.request()
      .input("employeeId", employeeId)
      .query(`
        SELECT EmployeeID, Name,
               ISNULL(WorkHoursPerWeek,42.5) AS WorkHoursPerWeek
        FROM Employees WHERE EmployeeID=@employeeId
      `);

    if (!empRes.recordset.length) {
      return res.status(404).json({ error: "Employee not found" });
    }

    const emp = empRes.recordset[0];
    const availableHours =
      (emp.WorkHoursPerWeek / 5) * countWeekdays(start, end);

    /* Allocations */
    const allocRes = await pool.request()
      .input("employeeId", employeeId)
      .input("start", iso(start))
      .input("end", iso(end))
      .query(`
        SELECT a.ProjectID, p.ProjectCode, a.AllocatedHours
        FROM Allocations a
        JOIN Projects p ON p.ProjectID=a.ProjectID
        WHERE a.EmployeeID=@employeeId
          AND p.StartDate < @end
          AND p.EndDate >= @start
      `);

    const allocatedHours = allocRes.recordset.reduce(
      (s, r) => s + Number(r.AllocatedHours || 0),
      0
    );

    /* Timesheets */
    const tsRes = await pool.request()
      .input("employeeId", employeeId)
      .input("start", iso(start))
      .input("end", iso(end))
      .query(`
        SELECT p.ProjectCode, SUM(te.Hours) AS Hours
        FROM TimesheetEntries te
        JOIN Timesheets t ON t.TimesheetID=te.TimesheetID
        JOIN Allocations a ON a.AllocationID=te.AllocationID
        JOIN Projects p ON p.ProjectID=a.ProjectID
        WHERE t.EmployeeID=@employeeId
          AND te.EntryDate>=@start AND te.EntryDate<@end
        GROUP BY p.ProjectCode
      `);

    const timesheetHours = tsRes.recordset.reduce(
      (s, r) => s + Number(r.Hours || 0),
      0
    );

    const byProject = tsRes.recordset.map(r => ({
      projectCode: r.ProjectCode,
      logged: Number(r.Hours),
      utilizationPercent: clampPct(
        availableHours > 0 ? (r.Hours / availableHours) * 100 : 0
      ),
    }));

    res.json({
      employeeId,
      name: emp.Name,
      period: { year, month },
      availableHours: Number(availableHours.toFixed(2)),
      yearlyAvailableHours: yearlyAvailableHours(emp.WorkHoursPerWeek, year),
      allocatedHours: Number(allocatedHours.toFixed(2)),
      timesheetHours: Number(timesheetHours.toFixed(2)),
      utilizationPercent: clampPct(
        yearlyAvailableHours(emp.WorkHoursPerWeek, year) > 0
          ? (timesheetHours /
              yearlyAvailableHours(emp.WorkHoursPerWeek, year)) *
              100
          : 0
      ),
      byProject,
      weekly: []
    });

  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

/* ================= TRIBE DASHBOARD ================= */

router.get("/tribe", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Admin only" });
    }

    const { year, month, start, end } = parsePeriod(req.query);
    const tribe = req.query.tribe;

    const pool = await getPool();

    const empRes = await pool.request()
      .input("tribe", tribe)
      .query(`
        SELECT EmployeeID, Name,
               ISNULL(WorkHoursPerWeek,42.5) AS WorkHoursPerWeek
        FROM Employees WHERE Tribe=@tribe
      `);

    const rows = empRes.recordset.map(e => ({
      employeeId: e.EmployeeID,
      name: e.Name,
      yearlyAvailableHours: yearlyAvailableHours(e.WorkHoursPerWeek, year)
    }));

    res.json({
      tribe,
      period: { year, month },
      rows
    });

  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

/* ================= TEAM DASHBOARD ================= */

router.get("/team", authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Admin only" });
    }

    const { year, month } = parsePeriod(req.query);
    const team = req.query.team === "TribeLead" ? "Tribe Lead" : req.query.team;

    const pool = await getPool();

    const empRes = await pool.request()
      .input("team", team)
      .query(`
        SELECT EmployeeID, Name,
               ISNULL(WorkHoursPerWeek,42.5) AS WorkHoursPerWeek
        FROM Employees WHERE Team=@team
      `);

    const rows = empRes.recordset.map(e => ({
      employeeId: e.EmployeeID,
      name: e.Name,
      yearlyAvailableHours: yearlyAvailableHours(e.WorkHoursPerWeek, year)
    }));

    res.json({
      team,
      period: { year, month },
      rows
    });

  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
