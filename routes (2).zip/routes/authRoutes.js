import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { getPool } from "../config/azure_db.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();

// =======================
// LOGIN
// =======================
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: "Email and password are required" });

    const pool = await getPool();
    const request = pool.request();
    request.input("email", email);

    const result = await request.query(
      "SELECT * FROM Employees WHERE Email = @email"
    );

    if (result.recordset.length === 0)
      return res.status(401).json({ error: "Invalid credentials" });

    const employee = result.recordset[0];

    if (employee.Status !== "active")
      return res.status(403).json({ error: "Account is inactive" });

    const validPassword = await bcrypt.compare(password, employee.Password);
    if (!validPassword)
      return res.status(401).json({ error: "Invalid credentials" });

    const token = jwt.sign(
      {
        employeeId: employee.EmployeeID,
        empId: employee.EmpID,
        name: employee.Name,
        email: employee.Email,
        role: employee.Role,
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.json({
      token,
      user: {
        employeeId: employee.EmployeeID,
        empId: employee.EmpID,
        name: employee.Name,
        email: employee.Email,
        role: employee.Role,
      },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error during login" });
  }
});

// =======================
// SIGNUP
// =======================
router.post("/signup", async (req, res) => {
  try {
    const { empId, name, email, password } = req.body;
    if (!empId || !name || !email || !password)
      return res.status(400).json({ error: "All fields required" });

    const pool = await getPool();

    // Check existing
    const checkReq = pool.request();
    checkReq.input("email", email);
    checkReq.input("empId", empId);

    const exists = await checkReq.query(
      "SELECT 1 FROM Employees WHERE Email = @email OR EmpID = @empId"
    );

    if (exists.recordset.length > 0)
      return res.status(400).json({ error: "Email or EmpID already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);

    const insertReq = pool.request();
    insertReq
      .input("empId", empId)
      .input("name", name)
      .input("email", email)
      .input("password", hashedPassword)
      .input("role", "employee");

    const result = await insertReq.query(`
      INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status)
      OUTPUT INSERTED.EmployeeID, INSERTED.EmpID, INSERTED.Name, INSERTED.Email, INSERTED.Role
      VALUES (@empId, @name, @email, @password, @role, CAST(GETDATE() AS DATE), 'active')
    `);

    const employee = result.recordset[0];

    const token = jwt.sign(
      {
        employeeId: employee.EmployeeID,
        empId: employee.EmpID,
        name: employee.Name,
        email: employee.Email,
        role: employee.Role,
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.status(201).json({ token, user: employee });
  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ error: "Signup failed" });
  }
});

// =======================
// GET PROFILE
// =======================
router.get("/me", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.user.employeeId);

    const result = await request.query(`
      SELECT EmployeeID, EmpID, Name, Email, Role, DOJ, Status, CreatedAt, UpdatedAt
      FROM Employees WHERE EmployeeID = @id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "User not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch profile" });
  }
});

export default router;
