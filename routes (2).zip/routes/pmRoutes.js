import express from "express";
import { getPool } from "../config/azure_db.js";
import { authenticateToken, authorizePM } from "../middleware/auth.js";

const router = express.Router();

// =======================
// GET EMPLOYEES (PM)
// =======================
router.get("/employees", authenticateToken, authorizePM, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("role", "employee")
      .query("SELECT * FROM Employees WHERE Role=@role ORDER BY Name");

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch employees" });
  }
});

// =======================
// GET EMPLOYEE BY ID
// =======================
router.get("/employees/:id", authenticateToken, authorizePM, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("id", req.params.id)
      .query("SELECT * FROM Employees WHERE EmployeeID=@id");

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Employee not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch employee" });
  }
});

// =======================
// GET PROJECTS
// =======================
router.get("/projects", authenticateToken, authorizePM, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .query("SELECT * FROM Projects ORDER BY ProjectCode");

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

// =======================
// GET ALLOCATIONS
// =======================
router.get("/allocations", authenticateToken, authorizePM, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(`
      SELECT a.*, e.Name AS EmployeeName, e.EmpID, p.ProjectCode
      FROM Allocations a
      JOIN Employees e ON a.EmployeeID = e.EmployeeID
      JOIN Projects p ON a.ProjectID = p.ProjectID
      ORDER BY e.Name, p.ProjectCode
    `);

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch allocations" });
  }
});

export default router;
