import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from "../../api/axios"; // ✅ USE CENTRAL AXIOS INSTANCE

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    employees: 0,
    projects: 0,
    allocations: 0,
    timesheets: 0,
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [empRes, projRes, allocRes, timesheetRes] = await Promise.all([
        axios.get('/api/employees'),
        axios.get('/api/projects'),
        axios.get('/api/allocations'),
        axios.get('/api/timesheets/all'),
      ]);

      setStats({
        employees: empRes.data.length,
        projects: projRes.data.length,
        allocations: allocRes.data.length,
        timesheets: timesheetRes.data.length,
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  const statCardStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    padding: '16px 18px',
    borderRadius: '16px',
    boxShadow: '0 6px 16px rgba(15, 23, 42, 0.08)',
    border: '1px solid rgba(148, 163, 184, 0.25)',
    background: 'linear-gradient(135deg, #ffffff 0%, #f9fafb 100%)',
  };

  const statLabelStyle = {
    fontSize: 12,
    fontWeight: 400,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: '#6b7280',
  };

  const statValueStyle = {
    fontSize: 28,
    fontWeight: 400,
    color: '#0f172a',
  };

  const statFooterStyle = {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 8,
  };

  return (
    <div className="container" style={{ paddingTop: 24, paddingBottom: 24 }}>
      {/* Hero */}
      <div style={{ marginBottom: 24 }}>
        <h1
          style={{
            fontSize: 26,
            fontWeight: 400,
            color: '#0f172a',
          }}
        >
          Admin Dashboard
        </h1>
      </div>

      {/* Stat cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: 24,
          marginBottom: 32,
        }}
      >
        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Employees</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.employees}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#eff6ff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                👤
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total active employees in the system.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/admin/employees">
              <button className="btn-primary">View employees</button>
            </Link>
          </div>
        </div>

        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Projects</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.projects}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#ecfeff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                📁
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total projects currently tracked.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/admin/projects">
              <button className="btn-secondary">View projects</button>
            </Link>
          </div>
        </div>

        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Allocations</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.allocations}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#fefce8',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                📊
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total employee-to-project assignments.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/admin/allocations">
              <button className="btn-secondary">View allocations</button>
            </Link>
          </div>
        </div>

        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Timesheets</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.timesheets}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#eef2ff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                🕒
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total submitted weekly timesheets.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/admin/timesheets">
              <button className="btn-secondary">Manage timesheets</button>
            </Link>
          </div>
        </div>
      </div>

      {/* Submit Your Timesheet Action Card */}
      <div style={{ marginBottom: 32 }}>
        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Submit Your Timesheet</div>
            <p style={{ fontSize: 14, color: '#374151', marginTop: 8, marginBottom: 12 }}>
              As an admin, you can also submit your own timesheet. Fill out your weekly hours and allocations.
            </p>
          </div>
          <div style={{ marginTop: 16 }}>
            <button
              onClick={() => navigate('/employee/timesheet')}
              className="btn-success"
              title="Open your employee timesheet form"
            >
              Submit Timesheet
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};

export default AdminDashboard;
