import React, { useState, useEffect } from 'react';
import api from "../../api/axios"; // ✅ USE CENTRAL AXIOS INSTANCE

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentProject, setCurrentProject] = useState({
    projectCode: '', entity: '', billingAction: '', startDate: '', endDate: '', status: 'active', tribe: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await axios.get('/api/projects');
      setProjects(response.data);
    } catch (error) {
      setError('Failed to fetch projects');
    }
  };

  const openAddModal = () => {
    setCurrentProject({ projectCode: '', entity: '', billingAction: '', startDate: '', endDate: '', status: 'active', tribe: '' });
    setEditMode(false);
    setShowModal(true);
    setError('');
    setSuccess('');
  };

  const openEditModal = (project) => {
    setCurrentProject({
      ...project,
      projectCode: project.projectcode,
      billingAction: project.billingaction,
      startDate: project.startdate.split('T')[0],
      endDate: project.enddate.split('T')[0],
      tribe: project.tribe || ''
    });
    setEditMode(true);
    setShowModal(true);
    setError('');
    setSuccess('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      if (editMode) {
        await axios.put(`/api/projects/${currentProject.projectid}`, currentProject);
        setSuccess('Project updated successfully');
      } else {
        await axios.post('/api/projects', currentProject);
        setSuccess('Project created successfully');
      }
      fetchProjects();
      setTimeout(() => setShowModal(false), 1500);
    } catch (error) {
      setError(error.response?.data?.error || 'Operation failed');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      try {
        await axios.delete(`/api/projects/${id}`);
        setSuccess('Project deleted successfully');
        fetchProjects();
      } catch (error) {
        setError('Failed to delete project');
      }
    }
  };

  return (
    <div className="container">
      <h1>Projects Management</h1>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h2>Projects</h2>
          <button onClick={openAddModal} className="btn-primary">Add Project</button>
        </div>

        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}

        <table>
          <thead>
            <tr>
              <th>Project Code</th>
              <th>Entity</th>
              <th>Billing Action</th>
              <th>Tribe</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((proj) => (
              <tr key={proj.projectid}>
                <td>{proj.projectcode}</td>
                <td>{proj.entity}</td>
                <td>{proj.billingaction}</td>
                <td>{proj.tribe || '-'}</td>
                <td>{new Date(proj.startdate).toLocaleDateString()}</td>
                <td>{new Date(proj.enddate).toLocaleDateString()}</td>
                <td>{proj.status}</td>
                <td>
                  <button onClick={() => openEditModal(proj)} className="btn-primary" style={{ marginRight: '5px' }}>Edit</button>
                  <button onClick={() => handleDelete(proj.projectid)} className="btn-danger">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editMode ? 'Edit Project' : 'Add Project'}</h2>
              <button onClick={() => setShowModal(false)} className="modal-close">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Project Code*</label>
                <input value={currentProject.projectCode} onChange={(e) => setCurrentProject({...currentProject, projectCode: e.target.value})} required disabled={editMode} />
              </div>
              <div className="form-group">
                <label>Entity*</label>
                <input value={currentProject.entity} onChange={(e) => setCurrentProject({...currentProject, entity: e.target.value})} required />
              </div>
              <div className="form-group">
                <label>Billing Action*</label>
                <input value={currentProject.billingAction} onChange={(e) => setCurrentProject({...currentProject, billingAction: e.target.value})} required />
              </div>
              <div className="form-group">
                <label>Start Date*</label>
                <input type="date" value={currentProject.startDate} onChange={(e) => setCurrentProject({...currentProject, startDate: e.target.value})} required />
              </div>
              <div className="form-group">
                <label>End Date*</label>
                <input type="date" value={currentProject.endDate} onChange={(e) => setCurrentProject({...currentProject, endDate: e.target.value})} required />
              </div>
              <div className="form-group">
                <label>Tribe</label>
                <select value={currentProject.tribe} onChange={(e) => setCurrentProject({...currentProject, tribe: e.target.value})}>
                  <option value="">Not Specified</option>
                  <option value="UKI">UKI</option>
                  <option value="Non-UKI">Non-UKI</option>
                </select>
                <small style={{ color: '#6c757d', fontSize: '12px' }}>If not specified, tribe will be determined by allocated employees</small>
              </div>
              <div className="form-group">
                <label>Status*</label>
                <select value={currentProject.status} onChange={(e) => setCurrentProject({...currentProject, status: e.target.value})} required>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
              {error && <div className="error">{error}</div>}
              {success && <div className="success">{success}</div>}
              <button type="submit" className="btn-success" style={{ marginTop: '10px' }}>{editMode ? 'Update' : 'Create'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Projects;
