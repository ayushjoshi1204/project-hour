import express from "express";
import { getPool } from "../config/azure_db.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();

// =======================
// GET MY TIMESHEETS
// =======================
router.get("/my-timesheets", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("employeeId", req.user.employeeId)
      .query(`
        SELECT *
        FROM Timesheets
        WHERE EmployeeID = @employeeId
        ORDER BY WeekStartDate DESC
      `);

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch timesheets" });
  }
});

// =======================
// GET TIMESHEET BY WEEK
// =======================
router.get("/by-week/:weekStart", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("employeeId", req.user.employeeId)
      .input("weekStart", req.params.weekStart)
      .query(`
        SELECT *
        FROM Timesheets
        WHERE EmployeeID=@employeeId AND WeekStartDate=@weekStart
      `);

    res.json(result.recordset[0] || null);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch timesheet" });
  }
});

// =======================
// GET TIMESHEET ENTRIES
// =======================
router.get("/:timesheetId/entries", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("timesheetId", req.params.timesheetId)
      .query(`
        SELECT te.*,
               a.ProjectID,
               COALESCE(p.ProjectCode, 'Non-Billable') AS ProjectCode,
               COALESCE(p.BillingAction, te.BillingAction) AS BillingAction,
               COALESCE(a.Role, te.Activity) AS Activity,
               te.IsNonBillable
        FROM TimesheetEntries te
        LEFT JOIN Allocations a ON te.AllocationID = a.AllocationID
        LEFT JOIN Projects p ON a.ProjectID = p.ProjectID
        WHERE te.TimesheetID = @timesheetId
        ORDER BY te.EntryDate, te.EntryID
      `);

    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch timesheet entries" });
  }
});

// =======================
// SUBMIT TIMESHEET (TRANSACTION)
// =======================
router.post("/submit", authenticateToken, async (req, res) => {
  const pool = await getPool();
  const transaction = pool.transaction();

  try {
    await transaction.begin();

    const { weekStartDate, weekEndDate, entries } = req.body;
    const employeeId = req.user.employeeId;

    if (!weekStartDate || !weekEndDate || !entries || entries.length === 0) {
      await transaction.rollback();
      return res.status(400).json({ error: "Invalid timesheet data" });
    }

    // Check existing timesheet
    const checkReq = transaction.request()
      .input("employeeId", employeeId)
      .input("weekStart", weekStartDate);

    const existing = await checkReq.query(`
      SELECT TimesheetID, Status
      FROM Timesheets
      WHERE EmployeeID=@employeeId AND WeekStartDate=@weekStart
    `);

    if (
      existing.recordset.length > 0 &&
      existing.recordset[0].Status === "submitted"
    ) {
      await transaction.rollback();
      return res.status(400).json({ error: "Timesheet already submitted" });
    }

    let timesheetId;

    // Insert or update timesheet
    if (existing.recordset.length === 0) {
      const insertTs = await transaction.request()
        .input("employeeId", employeeId)
        .input("weekStart", weekStartDate)
        .input("weekEnd", weekEndDate)
        .query(`
          INSERT INTO Timesheets (EmployeeID, WeekStartDate, WeekEndDate, Status)
          OUTPUT INSERTED.TimesheetID
          VALUES (@employeeId, @weekStart, @weekEnd, 'submitted')
        `);

      timesheetId = insertTs.recordset[0].TimesheetID;
    } else {
      timesheetId = existing.recordset[0].TimesheetID;

      await transaction.request()
        .input("timesheetId", timesheetId)
        .query(`
          DELETE FROM TimesheetEntries WHERE TimesheetID=@timesheetId
        `);
    }

    // Insert entries
    for (const e of entries) {
      await transaction.request()
        .input("timesheetId", timesheetId)
        .input("allocationId", e.allocationId || null)
        .input("entryDate", e.entryDate)
        .input("hours", e.hours)
        .input("billingAction", e.billingAction)
        .input("activity", e.activity)
        .input("isNonBillable", e.isNonBillable || false)
        .query(`
          INSERT INTO TimesheetEntries
          (TimesheetID, AllocationID, EntryDate, Hours, BillingAction, Activity, IsNonBillable)
          VALUES
          (@timesheetId, @allocationId, @entryDate, @hours, @billingAction, @activity, @isNonBillable)
        `);
    }

    await transaction.commit();
    res.json({ message: "Timesheet submitted successfully" });

  } catch (err) {
    await transaction.rollback();
    console.error(err);
    res.status(500).json({ error: "Failed to submit timesheet" });
  }
});

export default router;
