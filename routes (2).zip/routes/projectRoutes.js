import express from "express";
import { getPool } from "../config/azure_db.js";
import { authenticateToken, authorizeAdminOrPM } from "../middleware/auth.js";

const router = express.Router();

// =======================
// GET ALL PROJECTS
// =======================
router.get("/", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(
      "SELECT * FROM Projects ORDER BY ProjectID"
    );
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

// =======================
// GET ACTIVE PROJECTS
// =======================
router.get("/active", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool
      .request()
      .query("SELECT * FROM Projects WHERE Status='active' ORDER BY ProjectID");
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch active projects" });
  }
});

// =======================
// GET PROJECT BY ID
// =======================
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.params.id);

    const result = await request.query(
      "SELECT * FROM Projects WHERE ProjectID=@id"
    );

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Project not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch project" });
  }
});

// =======================
// CREATE PROJECT
// =======================
router.post("/", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { projectCode, entity, billingAction, startDate, endDate, status, tribe } = req.body;

    const pool = await getPool();
    const request = pool.request();

    request
      .input("projectCode", projectCode)
      .input("entity", entity)
      .input("billingAction", billingAction)
      .input("startDate", startDate)
      .input("endDate", endDate)
      .input("status", status || "active")
      .input("tribe", tribe || null);

    const result = await request.query(`
      INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status, Tribe)
      OUTPUT INSERTED.*
      VALUES (@projectCode, @entity, @billingAction, @startDate, @endDate, @status, @tribe)
    `);

    res.status(201).json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create project" });
  }
});

// =======================
// UPDATE PROJECT
// =======================
router.put("/:id", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();

    request
      .input("id", req.params.id)
      .input("projectCode", req.body.projectCode)
      .input("entity", req.body.entity)
      .input("billingAction", req.body.billingAction)
      .input("startDate", req.body.startDate)
      .input("endDate", req.body.endDate)
      .input("status", req.body.status)
      .input("tribe", req.body.tribe || null);

    const result = await request.query(`
      UPDATE Projects
      SET ProjectCode=@projectCode, Entity=@entity, BillingAction=@billingAction,
          StartDate=@startDate, EndDate=@endDate, Status=@status, Tribe=@tribe
      OUTPUT INSERTED.*
      WHERE ProjectID=@id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Project not found" });

    res.json(result.recordset[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update project" });
  }
});

// =======================
// DELETE PROJECT
// =======================
router.delete("/:id", authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const pool = await getPool();
    const request = pool.request();
    request.input("id", req.params.id);

    const result = await request.query(`
      DELETE FROM Projects
      OUTPUT DELETED.ProjectID
      WHERE ProjectID=@id
    `);

    if (result.recordset.length === 0)
      return res.status(404).json({ error: "Project not found" });

    res.json({ message: "Project deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete project" });
  }
});

export default router;
