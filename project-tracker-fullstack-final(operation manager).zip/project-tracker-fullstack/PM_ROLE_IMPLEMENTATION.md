# Project Manager Role Implementation - Setup Complete ✅

## Overview
The Project Manager (PM) role has been successfully implemented across the entire stack with the following capabilities:

### PM Permissions
- ✅ Manage employees (view all employees)
- ✅ Manage projects (view all projects)  
- ✅ Manage allocations (view all allocations)
- ✅ View employee utilization (employee-level only, NOT tribe-level)

---

## Backend Changes

### 1. Database Schema Update
**Files Updated:**
- `backend/database/schema.sql` - Updated Role constraint to include 'pm'
- `backend/database/migrations/role_pm_20251120.sql` - Migration to add PM role support

**Change:**
```sql
Role VARCHAR(20) NOT NULL CHECK (Role IN ('admin', 'employee', 'pm'))
```

### 2. Authorization Middleware
**File:** `backend/middleware/auth.js`

**New Exports:**
```javascript
export const authorizePM = (req, res, next) => {
  if (req.user.role !== 'pm') return res.status(403).json({ error: 'Project Manager access required' });
  next();
};

export const authorizeAdminOrPM = (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.role !== 'pm') 
    return res.status(403).json({ error: 'Admin or Project Manager access required' });
  next();
};
```

### 3. PM Routes
**File:** `backend/routes/pmRoutes.js` (NEW)

**Endpoints:**
- `GET /api/pm/employees` - Get all employees (role='employee' only)
- `GET /api/pm/employees/:id` - Get single employee by ID
- `GET /api/pm/projects` - Get all projects
- `GET /api/pm/allocations` - Get all allocations with employee/project details
- `GET /api/pm/utilization/employee/:empId` - Get monthly utilization for specific employee

**Authorization:** All endpoints require `authenticateToken` + `authorizePM` middleware

### 4. Server Configuration
**File:** `backend/server.js`

**Changes:**
- Imported pmRoutes: `import pmRoutes from './routes/pmRoutes.js';`
- Registered routes: `app.use('/api/pm', pmRoutes);`

---

## Frontend Changes

### 1. Component Structure
**PM Pages Created:**
- `frontend/src/pages/pm/PMDashboard.jsx` - Dashboard with stat cards (Employees, Projects, Allocations)
- `frontend/src/pages/pm/PMEmployees.jsx` - Employee list (read-only)
- `frontend/src/pages/pm/PMProjects.jsx` - Project list
- `frontend/src/pages/pm/PMAllocations.jsx` - Allocation assignments
- `frontend/src/pages/pm/PMUtilization.jsx` - Employee utilization selector + monthly series

### 2. Routing Configuration
**File:** `frontend/src/App.jsx`

**Routes Added:**
```jsx
<Route path="/pm" element={<ProtectedRoute pmOnly><PMDashboard /></ProtectedRoute>} />
<Route path="/pm/employees" element={<ProtectedRoute pmOnly><PMEmployees /></ProtectedRoute>} />
<Route path="/pm/projects" element={<ProtectedRoute pmOnly><PMProjects /></ProtectedRoute>} />
<Route path="/pm/allocations" element={<ProtectedRoute pmOnly><PMAllocations /></ProtectedRoute>} />
<Route path="/pm/utilization" element={<ProtectedRoute pmOnly><PMUtilization /></ProtectedRoute>} />
```

**ProtectedRoute Enhancement:**
- Added `pmOnly` prop to restrict routes to PM users only
- Routes protected with `ProtectedRoute pmOnly` automatically redirect non-PM users

**Navigation Logic Updated:**
- Login/Signup now redirect PM users to `/pm` dashboard
- Root route (`/`) correctly routes based on user role: admin → `/admin`, pm → `/pm`, employee → `/employee`

### 3. Navigation Bar
**File:** `frontend/src/components/Navbar.jsx`

**PM Navigation Links Added:**
- Dashboard
- Employees
- Projects
- Allocations
- Utilization

Displays conditionally when `user.role === 'pm'`

### 4. File Corrections
**Resolved:**
- Fixed `PMUtilization.jsx` to contain correct employee utilization view
- Created separate `PMAllocations.jsx` for allocations management
- Updated `App.jsx` imports to reference correct files

---

## Testing Checklist

### Before Testing
1. Run database migration: `role_pm_20251120.sql` to update existing databases
2. (Or if fresh DB setup, schema.sql already includes 'pm' role support)

### Manual Testing Steps

#### 1. Create PM User
**Option A: Via Database**
```sql
UPDATE Employees SET Role = 'pm' WHERE EmpID = '<emp_id>';
-- Or insert new PM user
INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status)
VALUES ('PM001', 'Project Manager', 'pm@example.com', '<hashed_pwd>', 'pm', CURRENT_DATE, 'active');
```

**Option B: Via UI Signup**
- Signup normally, then update role in database

#### 2. Test PM Login
1. Login with PM credentials
2. Verify redirect to `/pm` dashboard
3. Confirm navbar shows PM navigation links

#### 3. Test PM Pages
- **Dashboard**: Stat cards should display employee/project/allocation counts
- **Employees**: Should show employees table (read-only, no edit buttons)
- **Projects**: Should show projects table
- **Allocations**: Should show allocations with employee, project, hours, dates
- **Utilization**: 
  - Dropdown to select employee
  - On selection, should display monthly utilization table
  - NO tribe-level data visible (unlike admin)

#### 4. Test Authorization
- Try accessing `/admin/*` as PM → should redirect to `/pm`
- Try accessing `/pm/*` as employee → should redirect to `/employee`
- Try accessing `/pm/*` without auth → should redirect to `/login`

#### 5. API Testing
```bash
# Get PM token from login
TOKEN="<jwt_token>"

# Test endpoints
curl -H "Authorization: Bearer $TOKEN" http://localhost:5000/api/pm/employees
curl -H "Authorization: Bearer $TOKEN" http://localhost:5000/api/pm/projects
curl -H "Authorization: Bearer $TOKEN" http://localhost:5000/api/pm/allocations
curl -H "Authorization: Bearer $TOKEN" http://localhost:5000/api/pm/utilization/employee/1
```

---

## Key Differences from Admin View

| Feature | Admin | PM |
|---------|-------|-----|
| Employee Management | ✅ Full (edit, delete) | ✅ View only |
| Project Management | ✅ Full | ✅ View only |
| Allocation Management | ✅ Full | ✅ View only |
| View Utilization | ✅ By employee + tribe | ✅ By employee only |
| Access to Tribe Data | ✅ Yes | ❌ No |
| Timesheet Submission | ✅ Can submit own | ✅ Cannot access timesheet pages |

---

## Data Flow Architecture

```
PM Login
  ↓
JWT Token with role='pm'
  ↓
PMDashboard
  ├─ /api/pm/employees (count)
  ├─ /api/pm/projects (count)
  └─ /api/pm/allocations (count)
  ↓
Navigation Links
  ├─ PMEmployees → /api/pm/employees
  ├─ PMProjects → /api/pm/projects
  ├─ PMAllocations → /api/pm/allocations
  └─ PMUtilization → /api/pm/employees + /api/pm/utilization/employee/:id
```

---

## Next Steps

1. **Apply Migration**: Run `role_pm_20251120.sql` on your database if upgrading
2. **Test PM Workflow**: Follow testing checklist above
3. **Create PM User**: Set role='pm' for a test employee
4. **Verify Permissions**: Ensure PM cannot access admin routes and can only view employee (not tribe) data
5. **Optional**: Add PM user creation in admin UI if desired

---

## Files Modified/Created

### Backend
- ✅ `backend/database/schema.sql` - Updated Role constraint
- ✅ `backend/database/migrations/role_pm_20251120.sql` - Migration file (NEW)
- ✅ `backend/routes/pmRoutes.js` - PM API endpoints
- ✅ `backend/middleware/auth.js` - Added authorizePM middleware
- ✅ `backend/server.js` - Registered PM routes

### Frontend
- ✅ `frontend/src/App.jsx` - Added PM routes and imports
- ✅ `frontend/src/components/Navbar.jsx` - Added PM navigation links
- ✅ `frontend/src/pages/pm/PMDashboard.jsx` - Dashboard (NEW)
- ✅ `frontend/src/pages/pm/PMEmployees.jsx` - Employees view (NEW)
- ✅ `frontend/src/pages/pm/PMProjects.jsx` - Projects view (NEW)
- ✅ `frontend/src/pages/pm/PMAllocations.jsx` - Allocations view (NEW)
- ✅ `frontend/src/pages/pm/PMUtilization.jsx` - Utilization view (CORRECTED)

---

## Troubleshooting

### Issue: "Project Manager access required" error
**Solution**: Verify user has `role='pm'` in database and token was reissued after role change

### Issue: PM pages show blank/404
**Solution**: Check browser console for API errors, verify `/api/pm/*` endpoints are accessible

### Issue: PM can see tribe data
**Solution**: Verify PMUtilization component uses `/api/pm/utilization/employee/:id` (not `/api/pm/utilization` tribe endpoint)

### Issue: Migration fails - "constraint does not exist"
**Solution**: May not be needed for fresh database. Check if constraint name differs, adjust migration SQL accordingly.

---

## Support

For questions or issues, check:
1. Backend logs for API errors
2. Browser DevTools → Network tab for failed requests
3. Verify JWT token contains `role: 'pm'`
4. Confirm database migration was applied
