-- Migration: Add support for non-billable timesheet entries
-- Date: 2025-11-25

-- 1. Make AllocationID nullable in TimesheetEntries
ALTER TABLE TimesheetEntries ALTER COLUMN AllocationID DROP NOT NULL;

-- 2. Add new columns for non-billable details
ALTER TABLE TimesheetEntries ADD COLUMN IsNonBillable BOOLEAN DEFAULT FALSE;
ALTER TABLE TimesheetEntries ADD COLUMN Activity VARCHAR(255);
ALTER TABLE TimesheetEntries ADD COLUMN BillingAction VARCHAR(255);

-- 3. Add check constraint to ensure either AllocationID is present OR it's a non-billable entry
ALTER TABLE TimesheetEntries ADD CONSTRAINT check_allocation_or_nonbillable 
    CHECK (
        (AllocationID IS NOT NULL) OR 
        (IsNonBillable = TRUE AND Activity IS NOT NULL AND BillingAction IS NOT NULL)
    );
