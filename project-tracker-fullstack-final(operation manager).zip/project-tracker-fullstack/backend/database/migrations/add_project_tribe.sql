-- Add Tribe column to Projects table
-- This allows projects to be directly classified as UKI or Non-UKI

BEGIN;

-- Step 1: Add Tribe column to Projects table
ALTER TABLE Projects
  ADD COLUMN IF NOT EXISTS Tribe VARCHAR(64);

-- Step 2: Add constraint to ensure Tribe is either UKI or Non-UKI (or NULL)
DO $$ BEGIN
  ALTER TABLE Projects ADD CONSTRAINT projects_tribe_chk CHECK (Tribe IS NULL OR Tribe IN ('UKI','Non-UKI'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

COMMIT;

-- After this migration:
-- 1. Projects can have Tribe = 'UKI', 'Non-UKI', or NULL
-- 2. When Tribe is set, it takes precedence over employee-based classification
-- 3. When Tribe is NULL, the system falls back to employee-based classification



