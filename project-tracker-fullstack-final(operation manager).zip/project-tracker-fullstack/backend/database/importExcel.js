import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';
import pkg from 'xlsx';
import pool from '../config/db.js';

const { readFile, utils } = pkg;

const DEFAULT_PASSWORD = 'test123';
const DEFAULT_STATUS = 'active';
const DEFAULT_ROLE = 'employee';
const DEFAULT_WORK_HOURS = 42.5;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const log = (...args) => console.log('[IMPORT]', ...args);

function normalizeRows(rows) {
  return rows.map((row) => {
    const normalized = {};
    Object.entries(row).forEach(([key, value]) => {
      if (!key) return;
      normalized[key.toString().trim().toLowerCase()] = value;
    });
    return normalized;
  });
}

function pick(row, ...candidates) {
  for (const candidate of candidates) {
    const val = row[candidate.toLowerCase()];
    if (val !== undefined && val !== null && val !== '') {
      return typeof val === 'string' ? val.trim() : val;
    }
  }
  return '';
}

function toDateString(value) {
  if (!value) return null;
  if (value instanceof Date && !isNaN(value)) {
    return value.toISOString().slice(0, 10);
  }
  const parsed = new Date(value);
  if (!isNaN(parsed)) {
    return parsed.toISOString().slice(0, 10);
  }
  return null;
}

function toNumber(value, fallback = 0) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

async function importEmployees(sheet) {
  log('Importing employees...');
  const rows = normalizeRows(utils.sheet_to_json(sheet, { defval: '' }));
  let count = 0;

  for (const row of rows) {
    const name = pick(row, 'name', 'emp name', 'employee name');
    if (!name) continue;

    const empId =
      pick(row, 'empid', 'emp id', 'employee id') ||
      `AUTO-${name.replace(/\s+/g, '-').toUpperCase()}`;
    const email =
      pick(row, 'email') ||
      `${empId.toLowerCase().replace(/[^a-z0-9]/g, '')}@example.com`;
    const role = (pick(row, 'role') || DEFAULT_ROLE).toLowerCase();
    const status = (pick(row, 'status') || DEFAULT_STATUS).toLowerCase();
    const passwordRaw = pick(row, 'password') || DEFAULT_PASSWORD;
    const hashedPassword = await bcrypt.hash(passwordRaw, 10);
    const doj = toDateString(pick(row, 'doj', 'date of joining')) || toDateString(new Date());
    const team = pick(row, 'team') || null;
    const tribe = pick(row, 'tribe') || null;
    const workHours = toNumber(pick(row, 'workhoursperweek', 'work hours per week'), DEFAULT_WORK_HOURS);

    await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status, Team, Tribe, WorkHoursPerWeek)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (EmpID) DO UPDATE SET
         Name = EXCLUDED.Name,
         Email = EXCLUDED.Email,
         Role = EXCLUDED.Role,
         DOJ = EXCLUDED.DOJ,
         Status = EXCLUDED.Status,
         Team = EXCLUDED.Team,
         Tribe = EXCLUDED.Tribe,
         WorkHoursPerWeek = EXCLUDED.WorkHoursPerWeek`,
      [empId, name, email, hashedPassword, role, doj, status, team, tribe, workHours]
    );
    count += 1;
  }

  log(`Employees imported: ${count}`);
}

async function importProjects(sheet) {
  log('Importing projects...');
  const rows = normalizeRows(utils.sheet_to_json(sheet, { defval: '' }));
  let count = 0;

  for (const row of rows) {
    const projectCode = pick(row, 'projectcode', 'project code', 'project id', 'project');
    if (!projectCode) continue;

    const entity = pick(row, 'entity') || 'Unknown Entity';
    const billingAction = pick(row, 'billingaction', 'billing action') || 'Time & Material';
    const startDate = toDateString(pick(row, 'startdate', 'start date')) || toDateString(new Date());
    const endDate = toDateString(pick(row, 'enddate', 'end date')) || startDate;
    const status = (pick(row, 'status') || DEFAULT_STATUS).toLowerCase();
    const tribe = pick(row, 'tribe') || null;

    await pool.query(
      `INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status, Tribe)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (ProjectCode) DO UPDATE SET
         Entity = EXCLUDED.Entity,
         BillingAction = EXCLUDED.BillingAction,
         StartDate = EXCLUDED.StartDate,
         EndDate = EXCLUDED.EndDate,
         Status = EXCLUDED.Status,
         Tribe = EXCLUDED.Tribe`,
      [projectCode, entity, billingAction, startDate, endDate, status, tribe]
    );
    count += 1;
  }

  log(`Projects imported: ${count}`);
}

function findSheet(workbook, keywords = []) {
  return workbook.SheetNames.find((name) =>
    keywords.some((keyword) => name.toLowerCase().includes(keyword.toLowerCase()))
  );
}

async function main() {
  try {
    const filePathArg = process.argv[2];
    if (!filePathArg) {
      console.error('Usage: node database/importExcel.js <path-to-excel-or-csv>');
      process.exit(1);
    }

    const absolutePath = path.isAbsolute(filePathArg)
      ? filePathArg
      : path.join(process.cwd(), filePathArg);

    log(`Reading file: ${absolutePath}`);
    const workbook = readFile(absolutePath, { cellDates: true });

    const employeeSheetName =
      findSheet(workbook, ['employees', 'employee', 'staff']) || workbook.SheetNames[0];
    const projectSheetName = findSheet(workbook, ['projects', 'project']);

    if (!employeeSheetName && !projectSheetName) {
      console.error('Could not find Employees or Projects sheet in the workbook.');
      process.exit(1);
    }

    if (employeeSheetName) {
      await importEmployees(workbook.Sheets[employeeSheetName]);
    } else {
      log('Employees sheet not found, skipping employee import.');
    }

    if (projectSheetName) {
      await importProjects(workbook.Sheets[projectSheetName]);
    } else {
      log('Projects sheet not found, skipping project import.');
    }

    log('Import complete!');
    process.exit(0);
  } catch (error) {
    console.error('Import failed:', error);
    process.exit(1);
  } finally {
    pool.end();
  }
}

main();



