const BASE_URL = 'http://localhost:5000/api';
const PM_EMAIL = 'peter.pm@demo.local'; // From seed data
const PASSWORD = 'test123';

async function verify() {
    try {
        // 1. Login as PM
        console.log('Logging in as PM...');
        const loginRes = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: PM_EMAIL, password: PASSWORD })
        });

        if (!loginRes.ok) {
            throw new Error(`Login failed: ${loginRes.status} ${loginRes.statusText}`);
        }

        const loginData = await loginRes.json();
        const token = loginData.token;
        console.log('Login successful. Token obtained.');
        console.log('Role:', loginData.user.role);

        if (loginData.user.role !== 'pm') {
            console.warn('Warning: Logged in user is not a PM');
        }

        // 2. Fetch All Timesheets
        console.log('Fetching all timesheets...');
        const timesheetsRes = await fetch(`${BASE_URL}/timesheets/all`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (timesheetsRes.ok) {
            const timesheets = await timesheetsRes.json();
            console.log('Success! Fetched timesheets count:', timesheets.length);
            if (timesheets.length > 0) {
                console.log('Sample timesheet ID:', timesheets[0].timesheetid);
            }
        } else {
            console.error('Failed to fetch timesheets:');
            console.error('Status:', timesheetsRes.status);
            const errorData = await timesheetsRes.json();
            console.error('Error:', errorData);
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

verify();
