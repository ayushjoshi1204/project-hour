const BASE_URL = 'http://localhost:5000/api';
const PM_EMAIL = 'peter.pm@demo.local';
const PASSWORD = 'test123';

async function verifyDashboardData() {
    try {
        // 1. Login as PM
        console.log('Logging in as PM...');
        const loginRes = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: PM_EMAIL, password: PASSWORD })
        });

        if (!loginRes.ok) {
            throw new Error(`Login failed: ${loginRes.status} ${loginRes.statusText}`);
        }

        const loginData = await loginRes.json();
        const token = loginData.token;
        console.log('Login successful. Token obtained.');

        // 2. Simulate Dashboard Fetch (Fetch All Timesheets)
        console.log('Fetching all timesheets (simulating dashboard)...');
        const timesheetsRes = await fetch(`${BASE_URL}/timesheets/all`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (timesheetsRes.ok) {
            const timesheets = await timesheetsRes.json();
            console.log('Success! Dashboard would receive timesheets count:', timesheets.length);
            // We expect more than 0 if there are submissions
            if (timesheets.length > 0) {
                console.log('Verification Passed: PM can access global timesheet data.');
            } else {
                console.warn('Warning: 0 timesheets returned. Verify if any exist.');
            }
        } else {
            console.error('Failed to fetch timesheets:');
            console.error('Status:', timesheetsRes.status);
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

verifyDashboardData();
