const BASE_URL = 'http://localhost:5000/api';
const PM_EMAIL = 'peter.pm@demo.local';
const PASSWORD = 'test123';

async function inspectResponse() {
    try {
        // 1. Login as PM
        const loginRes = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: PM_EMAIL, password: PASSWORD })
        });

        if (!loginRes.ok) throw new Error('Login failed');
        const { token } = await loginRes.json();

        // 2. Fetch All Timesheets
        const res = await fetch(`${BASE_URL}/timesheets/all`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (res.ok) {
            const data = await res.json();
            if (data.length > 0) {
                console.log('First item keys:', Object.keys(data[0]));
                console.log('First item sample:', JSON.stringify(data[0], null, 2));
            } else {
                console.log('No timesheets found.');
            }
        } else {
            console.error('Fetch failed:', res.status);
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

inspectResponse();
