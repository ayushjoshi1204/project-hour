const BASE_URL = 'http://localhost:5000/api';
const EMAIL = 'devon.dev1@demo.local';
const PASSWORD = 'test123';

async function reproduce() {
    try {
        // 1. Login
        console.log('Logging in...');
        const loginRes = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: EMAIL, password: PASSWORD })
        });

        if (!loginRes.ok) {
            throw new Error(`Login failed: ${loginRes.status} ${loginRes.statusText}`);
        }

        const loginData = await loginRes.json();
        const token = loginData.token;
        console.log('Login successful. Token obtained.');

        // 2. Submit Timesheet with Non-Billable Entry
        console.log('Submitting timesheet with non-billable entry...');

        const today = new Date();
        const weekStart = new Date(today);
        // Adjust to Monday
        const day = weekStart.getDay();
        const diff = weekStart.getDate() - day + (day === 0 ? -6 : 1);
        weekStart.setDate(diff);
        weekStart.setHours(0, 0, 0, 0);

        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);

        const formatDate = (d) => d.toISOString().split('T')[0];

        const payload = {
            weekStartDate: formatDate(weekStart),
            weekEndDate: formatDate(weekEnd),
            entries: [
                {
                    projectId: null,
                    projectType: 'non-billable',
                    billingAction: 'Non-Billable',
                    activity: 'Sick Leave',
                    hours: {
                        [formatDate(weekStart)]: 8.5,
                        [formatDate(new Date(weekStart.getTime() + 86400000))]: 8.5,
                        [formatDate(new Date(weekStart.getTime() + 86400000 * 2))]: 8.5,
                        [formatDate(new Date(weekStart.getTime() + 86400000 * 3))]: 8.5,
                        [formatDate(new Date(weekStart.getTime() + 86400000 * 4))]: 8.5,
                    },
                    notes: 'Feeling unwell',
                    nonBillableType: 'sick_leave'
                }
            ]
        };

        const submitRes = await fetch(`${BASE_URL}/timesheets/submit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(payload)
        });

        const submitData = await submitRes.json();

        if (submitRes.ok) {
            console.log('Submission successful:', submitData);
        } else {
            console.error('Submission failed as expected (or unexpected):');
            console.error('Status:', submitRes.status);
            console.error('Data:', submitData);
        }

    } catch (error) {
        console.error('Error:', error.message);
    }
}

reproduce();
