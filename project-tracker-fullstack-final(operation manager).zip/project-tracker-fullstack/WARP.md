# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Development Commands

### Initial Setup
```pwsh
# Database setup (PostgreSQL must be running)
createdb project_tracker

# Backend setup
cd backend
npm install
cp .env.example .env
# Edit .env with database credentials
npm run init-db  # Creates schema and seeds data

# Frontend setup  
cd frontend
npm install
```

### Running the Application
```pwsh
# Backend (from backend/)
npm run dev      # Development with nodemon auto-reload
npm start        # Production mode

# Frontend (from frontend/)
npm run dev      # Vite dev server on port 3000
npm run build    # Production build
npm run preview  # Preview production build
```

### Database Operations
```pwsh
# From backend/
npm run init-db  # Initialize/reset database schema and seed data
```

## Architecture Overview

### Monorepo Structure
This is a fullstack application split into two independent directories:
- **backend/**: Express.js REST API with PostgreSQL
- **frontend/**: React SPA with Vite

### Backend Architecture

**Entry Point**: `server.js` sets up Express with CORS, JSON parsing, and route mounting.

**Authentication Flow**:
- JWT-based authentication with tokens stored in localStorage
- Two middleware layers: `authenticateToken` (all protected routes) and `authorizeAdmin` (admin-only routes)
- JWT token includes `employeeId`, `email`, and `role` claims
- Tokens expire after 24 hours

**Database Layer**:
- Direct PostgreSQL pool connection (`config/db.js`)
- No ORM - raw SQL queries throughout
- ES modules (`type: "module"` in package.json)
- Connection pool with error handling that exits process on idle client errors

**Data Model Relationships**:
```
Employees ─┬─> Allocations <─┬─ Projects
           │                 │
           └─> Timesheets ───┼─> TimesheetEntries
                             └──> (via AllocationID)
```

**Key Business Logic**:
- **Timesheet Validation** (in `timesheetRoutes.js`):
  - Weekly hours must equal 42.5 ±2 hours
  - No duplicate (ProjectID, Activity) combinations per week
  - Entry dates must fall within project StartDate/EndDate
  - Hours per project cannot exceed AllocatedHours
  - Cannot resubmit an already submitted week
  - Transaction-based submissions with rollback on validation failure
  
- **Role-Based Access**:
  - Admin: Full CRUD on Employees, Projects, Allocations, view all Timesheets
  - Employee: View own Allocations, submit/view own Timesheets

**Database Schema Features**:
- Automatic `UpdatedAt` timestamp triggers on all tables
- Unique constraints: `EmpID`, `Email`, `ProjectCode`, `(EmployeeID, ProjectID)`, `(EmployeeID, WeekStartDate)`
- Cascading deletes through foreign keys
- CHECK constraints for status enums, date ranges, and hour limits (0-24)

### Frontend Architecture

**Routing Structure**:
- React Router v6 with role-based route protection
- `ProtectedRoute` component wraps all authenticated routes
- Auto-redirect based on user role: admin → `/admin`, employee → `/employee`

**State Management**:
- **Global Auth State**: `AuthContext` provides `user`, `login`, `logout`, `loading`
- **Component-Level State**: React hooks for form data and API responses
- **Token Persistence**: localStorage for JWT and user object
- Axios default headers set globally on login

**API Communication**:
- Axios with Vite proxy: `/api` requests proxy to `http://localhost:5000`
- Authorization header automatically attached via `axios.defaults.headers.common`
- No API client abstraction layer - direct axios calls in components

**Component Organization**:
- **Pages**: Feature-complete views split by role (`admin/`, `employee/`)
- **Context**: Global state providers (`AuthContext`)
- **Components**: Reusable UI elements (`Navbar`)

**Timesheet UI Logic**:
- Week navigation calculates Monday start dates using `date-fns`
- Dynamic row management for multiple project entries
- Auto-fill: selecting a project populates billing action from allocations
- Real-time total hours calculation per row and weekly total
- Validation feedback before submission

## Important Patterns

### Error Handling
- Backend: Try-catch blocks with generic 500 errors logged to console
- Frontend: Error responses extracted from `error.response?.data?.error`
- No centralized error handling or logging system

### Database Transactions
When modifying Timesheets, always use transactions:
```javascript
const client = await pool.connect();
await client.query('BEGIN');
try {
  // operations
  await client.query('COMMIT');
} catch (error) {
  await client.query('ROLLBACK');
  throw error;
} finally {
  client.release();
}
```

### Route Protection Pattern
All protected routes follow this pattern:
```javascript
router.get('/endpoint', authenticateToken, async (req, res) => {
  const employeeId = req.user.employeeId; // Available from JWT decode
  // ...
});

router.post('/admin-endpoint', authenticateToken, authorizeAdmin, async (req, res) => {
  // Admin-only logic
});
```

### Frontend API Calls
Typical pattern in components:
```javascript
const response = await axios.get('/api/resource');
// or with error handling:
try {
  const response = await axios.post('/api/resource', data);
} catch (error) {
  console.error(error.response?.data?.error || 'Operation failed');
}
```

## Environment Configuration

### Backend (.env)
Required variables:
- `PORT`: Server port (default: 5000)
- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`: PostgreSQL connection
- `JWT_SECRET`: Secret for signing JWT tokens (change in production)

### Frontend
No environment variables required. API proxy configured in `vite.config.js`.

## Testing & Validation

**No test suite exists**. To validate changes:
1. Test backend routes using the frontend UI
2. Check PostgreSQL logs for query errors
3. Verify constraint violations through submission flows
4. Test with both admin and employee accounts

## Default Credentials
- Admin: `admin@projecttracker.com` / `admin123`
- Employee: `john@projecttracker.com` / `emp123`

## Common Pitfalls

1. **Windows Environment**: Use PowerShell commands (not bash). Example: `Get-ChildItem` instead of `ls`
2. **Database State**: `npm run init-db` drops and recreates all tables - all data is lost
3. **Port Conflicts**: Backend (5000) and Frontend (3000) must both be available
4. **CORS**: Currently open for development - restrict in production
5. **Password Hashing**: bcrypt with 10 rounds - happens in `authRoutes.js` during employee creation
6. **Date Handling**: Frontend uses `date-fns`, backend uses PostgreSQL DATE/TIMESTAMP types
7. **Case Sensitivity**: PostgreSQL identifiers are lowercase in queries but schema uses PascalCase
