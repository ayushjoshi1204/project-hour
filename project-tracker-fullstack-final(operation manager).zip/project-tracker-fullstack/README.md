# Project Tracker - Full Stack Application

A comprehensive project tracking system with employee timesheet management, built with React, Node.js, Express, and PostgreSQL.

## Features

### Admin Features
- **Employee Management**: Create, update, delete, and view employees
- **Project Management**: Manage projects with billing actions and date ranges
- **Allocation Management**: Assign employees to projects with allocated hours
- **Dashboard**: Overview of all employees, projects, allocations, and timesheets

### Employee Features
- **Timesheet Submission**: Dynamic weekly timesheet with Monday-Sunday grid
- **Auto-fill**: Project selection automatically fills billing action and activity
- **Week Navigation**: Navigate between weeks using previous/next buttons
- **Validation**: 
  - Total weekly hours must equal 42.5 (±2 hours tolerance)
  - No duplicate project-activity combinations
  - Cannot submit same week twice
  - Hours cannot exceed allocated hours per project
  - Entry dates must be within project date range
- **Dashboard**: View allocations and submitted timesheets

## Tech Stack

**Frontend:**
- React 18
- React Router v6
- Axios
- date-fns
- Vite

**Backend:**
- Node.js
- Express
- PostgreSQL
- JWT Authentication
- bcrypt for password hashing

## Database Schema

### Tables
1. **Employees**: EmployeeID (PK), EmpID (unique), Name, Email (unique), Password, Role, DOJ, Status, CreatedAt, UpdatedAt
2. **Projects**: ProjectID (PK), ProjectCode (unique), Entity, BillingAction, StartDate, EndDate, Status, CreatedAt, UpdatedAt
3. **Allocations**: AllocationID (PK), EmployeeID (FK), ProjectID (FK), EmpName, Role, AllocatedHours, CreatedAt, UpdatedAt
4. **Timesheets**: TimesheetID (PK), EmployeeID (FK), WeekStartDate, WeekEndDate, Status, SubmittedAt, CreatedAt, UpdatedAt
5. **TimesheetEntries**: EntryID (PK), TimesheetID (FK), AllocationID (FK), EntryDate, Hours, Notes, CreatedAt, UpdatedAt

## Prerequisites

- Node.js (v16 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

## Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd project-tracker-fullstack
```

### 2. Database Setup

**Create PostgreSQL Database:**
```bash
createdb project_tracker
```

Or using psql:
```sql
CREATE DATABASE project_tracker;
```

### 3. Backend Setup

```bash
cd backend
npm install
```

**Configure Environment Variables:**
```bash
cp .env.example .env
```

Edit `.env` with your database credentials:
```env
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=project_tracker
DB_USER=postgres
DB_PASSWORD=your_password
JWT_SECRET=your_secure_jwt_secret_here
```

**Initialize Database:**
```bash
npm run init-db
```

This will create all tables and seed sample data:
- Admin user: admin@projecttracker.com / admin123
- Employee user: john@projecttracker.com / emp123

**Start Backend Server:**
```bash
npm run dev
```

Server will run on http://localhost:5000

### 4. Frontend Setup

```bash
cd frontend
npm install
```

**Start Frontend Development Server:**
```bash
npm run dev
```

Frontend will run on http://localhost:3000

## Usage

### Login Credentials

**Admin Account:**
- Email: admin@projecttracker.com
- Password: admin123

**Employee Account:**
- Email: john@projecttracker.com
- Password: emp123

### Admin Workflow
1. Login with admin credentials
2. Navigate to "Employees" to add/manage employees
3. Navigate to "Projects" to add/manage projects
4. Navigate to "Allocations" to assign employees to projects
5. View submitted timesheets on the dashboard

### Employee Workflow
1. Login with employee credentials
2. View your allocations on the dashboard
3. Click "Submit Timesheet" or navigate to "Timesheet"
4. Select week using navigation buttons
5. Add rows for different projects
6. Select project from dropdown (auto-fills billing action)
7. Enter hours for each day (Mon-Sun)
8. Ensure total weekly hours = 42.5 (±2 hours)
9. Add notes if needed
10. Click "Submit Timesheet"

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login

### Employees (Admin only)
- `GET /api/employees` - Get all employees
- `GET /api/employees/:id` - Get employee by ID
- `GET /api/employees/empid/:empid` - Get employee by EmpID
- `POST /api/employees` - Create employee
- `PUT /api/employees/:id` - Update employee
- `DELETE /api/employees/:id` - Delete employee

### Projects
- `GET /api/projects` - Get all projects
- `GET /api/projects/active` - Get active projects
- `GET /api/projects/:id` - Get project by ID
- `POST /api/projects` - Create project (Admin)
- `PUT /api/projects/:id` - Update project (Admin)
- `DELETE /api/projects/:id` - Delete project (Admin)

### Allocations
- `GET /api/allocations` - Get all allocations
- `GET /api/allocations/employee/:employeeId` - Get employee allocations
- `GET /api/allocations/:id` - Get allocation by ID
- `POST /api/allocations` - Create allocation (Admin)
- `PUT /api/allocations/:id` - Update allocation (Admin)
- `DELETE /api/allocations/:id` - Delete allocation (Admin)

### Timesheets
- `GET /api/timesheets/my-timesheets` - Get logged-in employee timesheets
- `GET /api/timesheets/by-week/:weekStart` - Get timesheet by week
- `GET /api/timesheets/:timesheetId/entries` - Get timesheet entries
- `POST /api/timesheets/submit` - Submit timesheet
- `GET /api/timesheets/all` - Get all timesheets (Admin)

## Validation Rules

### Timesheet Submission
1. **Total Hours**: Must equal 42.5 hours per week (±2 hours tolerance)
2. **Duplicate Prevention**: No duplicate (ProjectID, Activity) combinations
3. **Week Uniqueness**: Cannot submit timesheet for same week twice
4. **Allocated Hours**: Cannot exceed allocated hours per project
5. **Date Range**: Entry dates must fall within project StartDate and EndDate
6. **Daily Limit**: Maximum 24 hours per day

## Project Structure

```
project-tracker-fullstack/
├── backend/
│   ├── config/
│   │   └── db.js
│   ├── database/
│   │   ├── schema.sql
│   │   └── init.js
│   ├── middleware/
│   │   └── auth.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── employeeRoutes.js
│   │   ├── projectRoutes.js
│   │   ├── allocationRoutes.js
│   │   └── timesheetRoutes.js
│   ├── .env.example
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   └── Navbar.jsx
│   │   ├── context/
│   │   │   └── AuthContext.jsx
│   │   ├── pages/
│   │   │   ├── admin/
│   │   │   │   ├── AdminDashboard.jsx
│   │   │   │   ├── Employees.jsx
│   │   │   │   ├── Projects.jsx
│   │   │   │   └── Allocations.jsx
│   │   │   ├── employee/
│   │   │   │   ├── EmployeeDashboard.jsx
│   │   │   │   ├── Timesheet.jsx
│   │   │   │   └── Timesheet.css
│   │   │   └── Login.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── .gitignore
└── README.md
```

## Development

### Backend Development
```bash
cd backend
npm run dev  # Uses nodemon for auto-restart
```

### Frontend Development
```bash
cd frontend
npm run dev  # Uses Vite dev server with HMR
```

### Production Build
```bash
# Frontend
cd frontend
npm run build

# Backend (no build needed, runs directly)
cd backend
npm start
```

## Security Notes

- JWT tokens expire after 24 hours
- Passwords are hashed using bcrypt (10 salt rounds)
- Admin routes are protected with role-based middleware
- CORS is enabled for development (configure for production)
- Always use HTTPS in production
- Change JWT_SECRET to a strong random string in production

## Future Enhancements

- Timesheet approval workflow
- Email notifications
- Export timesheets to Excel/PDF
- Advanced reporting and analytics
- Project budget tracking
- Mobile responsive improvements
- Unit and integration tests

## License

MIT

## Support

For issues or questions, please open an issue on the GitHub repository.
