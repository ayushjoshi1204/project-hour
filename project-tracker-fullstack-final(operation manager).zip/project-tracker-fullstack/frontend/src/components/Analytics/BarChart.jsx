import React from 'react';

const palette = [
  '#2563eb','#f59e0b','#10b981','#ef4444','#8b5cf6','#ec4899','#22c55e','#fbbf24','#06b6d4','#a3e635',
  '#eab308','#3b82f6','#f97316','#84cc16','#14b8a6','#d946ef','#f43f5e','#64748b','#38bdf8','#c084fc'
];
function hashLabel(label) {
  let h = 0; const s = String(label||'');
  for (let i=0;i<s.length;i++) h = (h*31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}
function colorFor(label, fallback) {
  return fallback || palette[hashLabel(label) % palette.length];
}

function BarChart({ rows = [], width = 640, height = 220, color, maxValue }) {
  const pad = 36;
  const rawMax = Math.max(1, ...rows.map(r => Number(r.value) || 0));
  const baseMax = maxValue != null ? Math.max(rawMax, Number(maxValue) || 1) : rawMax;
  const isPct = maxValue == null && baseMax <= 100; // assume percentages only if no explicit max provided
  const yMax = maxValue != null ? Number(maxValue) || 1 : (isPct ? 100 : Math.ceil(baseMax / 10) * 10);
  const ticks = 5;
  const barW = (width - pad * 2) / Math.max(1, rows.length);
  const scaleY = (v) => (v / yMax) * (height - pad * 2);
  const [tip, setTip] = React.useState({ show:false, x:0, y:0, text:'' });

  return (
    <div style={{ position: 'relative' }}>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        <rect x={0} y={0} width={width} height={height} fill="#ffffff" />
        {/* axes */}
        <line x1={pad} y1={height - pad} x2={width - pad} y2={height - pad} stroke="#e5e7eb" />
        <line x1={pad} y1={pad} x2={pad} y2={height - pad} stroke="#e5e7eb" />

        {/* grid + tick labels */}
        {Array.from({ length: ticks + 1 }, (_, i) => {
          const v = (yMax / ticks) * i;
          const y = (height - pad) - scaleY(v);
          return (
            <g key={i}>
              <line x1={pad} y1={y} x2={width - pad} y2={y} stroke="#f3f4f6" />
              <text x={pad - 6} y={y + 4} fontSize={10} textAnchor="end" fill="#6b7280">{Math.round(v)}</text>
            </g>
          );
        })}

        {rows.map((r, i) => {
          const val = Number(r.value) || 0;
          const h = scaleY(val);
          const x = pad + i * barW;
          const y = height - pad - h;
          const c = r.color || colorFor(r.label, color);
          const onEnter = (evt) => {
            const rect = evt.currentTarget.ownerSVGElement.getBoundingClientRect();
            setTip({ show:true, x: evt.clientX - rect.left + 8, y: evt.clientY - rect.top + 8, text: `${r.label}: ${val}${isPct ? '%' : ''}` });
          };
          const onMove = (evt) => {
            const rect = evt.currentTarget.ownerSVGElement.getBoundingClientRect();
            setTip(t => ({ ...t, x: evt.clientX - rect.left + 8, y: evt.clientY - rect.top + 8 }));
          };
          const onLeave = () => setTip({ show:false, x:0, y:0, text:'' });
          return (
            <g key={i}>
              <rect x={x + 6} y={y} width={Math.max(8, barW - 12)} height={h} fill={c} rx={4}
                onMouseEnter={onEnter} onMouseMove={onMove} onMouseLeave={onLeave} />
              <text x={x + barW / 2} y={height - 8} fontSize={10} textAnchor="middle" fill="#374151">{r.label}</text>
            </g>
          );
        })}
      </svg>

      {tip.show && (
        <div style={{ position:'absolute', left: tip.x, top: tip.y, background:'#111827', color:'#fff', fontSize:12, padding:'4px 6px', borderRadius:4, pointerEvents:'none', whiteSpace:'nowrap' }}>{tip.text}</div>
      )}
    </div>
  );
}

export default React.memo(BarChart);
