import React from 'react';

const palette = [
  '#2563eb','#f59e0b','#10b981','#ef4444','#8b5cf6','#ec4899','#22c55e','#fbbf24','#06b6d4','#a3e635',
  '#eab308','#3b82f6','#f97316','#84cc16','#14b8a6','#d946ef','#f43f5e','#64748b','#38bdf8','#c084fc'
];

function hashLabel(label) {
  let h = 0;
  const s = String(label || '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function colorFor(label) {
  const idx = hashLabel(label) % palette.length;
  return palette[idx];
}

function polarToCartesian(cx, cy, r, angle) {
  const a = (angle - 90) * Math.PI / 180.0;
  return { x: cx + (r * Math.cos(a)), y: cy + (r * Math.sin(a)) };
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
  return ['M', start.x, start.y, 'A', r, r, 0, largeArcFlag, 1, end.x, end.y].join(' ');
}

function describeWedge(cx, cy, r, startAngle, endAngle) {
  // Build a single closed path: center -> start -> arc -> end -> close
  const start = polarToCartesian(cx, cy, r, startAngle);
  const end = polarToCartesian(cx, cy, r, endAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
  return [
    'M', cx, cy,
    'L', start.x, start.y,
    'A', r, r, 0, largeArcFlag, 1, end.x, end.y,
    'Z'
  ].join(' ');
}

function PieChart({ slices = [], size = 300, innerRadius = 0, showCenter = false, centerText = '', showLegend = true }) {
  // sanitize and sort for consistent professional look
  const data = (slices || [])
    .map(s => ({ ...s, value: Number(s.value) || 0 }))
    .filter(s => s.value > 0)
    .sort((a, b) => b.value - a.value);

  const total = data.reduce((s, x) => s + x.value, 0) || 1;
  const cx = size / 2, cy = size / 2, r = size / 2 - 8;

  // compute wedges
  let angle = 0;
  const minSweep = 0.5; // avoid hairline gaps
  const arcs = data.map((s, i) => {
    const frac = s.value / total;
    let sweep = Math.max(minSweep, frac * 360);
    const start = angle;
    let end = angle + sweep;
    if (i === data.length - 1) end = 360; // close pie fully
    angle = end;
    const color = s.color || colorFor(s.label || s.name);
    const path = describeWedge(cx, cy, r, start, end);
    const pct = Math.round((s.value / total) * 1000) / 10;
    return { path, color, ...s, pct };
  });

  const [tip, setTip] = React.useState({ show: false, x: 0, y: 0, text: '' });
  const onEnter = (evt, a) => {
    const rect = evt.currentTarget.ownerSVGElement.getBoundingClientRect();
    setTip({ show: true, x: evt.clientX - rect.left + 8, y: evt.clientY - rect.top + 8, text: a.name ? `${a.name} • ${a.role || ''} • ${a.pct}%` : `${a.label} • ${a.pct}%` });
  };
  const onMove = (evt) => {
    const rect = evt.currentTarget.ownerSVGElement.getBoundingClientRect();
    setTip(t => ({ ...t, x: evt.clientX - rect.left + 8, y: evt.clientY - rect.top + 8 }));
  };
  const onLeave = () => setTip({ show: false, x: 0, y: 0, text: '' });

  return (
    <div style={{ display:'flex', gap: 16, alignItems:'center', flexWrap:'wrap' }}>
      <div style={{ position:'relative', width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <defs>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#00000033" />
            </filter>
          </defs>
          <g filter="url(#shadow)">
            <circle cx={cx} cy={cy} r={r} fill="#f8fafc" />
            {arcs.map((a, idx) => (
              <path key={idx} d={a.path} fill={a.color} stroke="#ffffff" strokeWidth={1}
                onMouseEnter={(e)=>onEnter(e,a)} onMouseMove={onMove} onMouseLeave={onLeave} />
            ))}
          </g>
          {innerRadius > 0 && <circle cx={cx} cy={cy} r={innerRadius} fill="#fff" />}
          {showCenter && (
            <text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle" fontSize={14} fill="#111827">{centerText}</text>
          )}
        </svg>
        {tip.show && (
          <div style={{ position:'absolute', left: tip.x, top: tip.y, background:'#111827', color:'#fff', fontSize:12, padding:'4px 6px', borderRadius:4, pointerEvents:'none', whiteSpace:'nowrap' }}>
            {tip.text}
          </div>
        )}
      </div>
      {showLegend && (
        <div style={{ fontSize: 12 }}>
          {data.map((s, i) => (
            <div key={i} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
              <span style={{ width:10, height:10, background: s.color || colorFor(s.label || s.name), display:'inline-block' }} />
              <span>{s.label || `${s.name} (${s.role||''})`}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default React.memo(PieChart);
