import React from 'react';

function colorByPct(pct) {
  if (pct >= 80) return '#22c55e';
  if (pct >= 50) return '#f59e0b';
  return '#ef4444';
}

function UtilizationBar({ rows }) {
  // Simple horizontal bars without external chart libs
  return (
    <div>
      {rows.map((r) => {
        const pct = Number(r.utilizationPercent || 0);
        return (
          <div key={r.label} style={{ marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>{r.label}</span>
              <span>{pct.toFixed(1)}%</span>
            </div>
            <div style={{ background: '#e5e7eb', height: 10, borderRadius: 6 }}>
              <div style={{ width: `${Math.max(0, Math.min(100, pct))}%`, height: 10, background: colorByPct(pct), borderRadius: 6 }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default React.memo(UtilizationBar);