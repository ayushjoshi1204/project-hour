import React from 'react';

function band(pct) {
  if (pct >= 80) return 'green';
  if (pct >= 50) return 'amber';
  return 'red';
}

function UtilizationSummaryCards({ availableHours, allocatedHours, timesheetHours, utilizationPercent }) {
  const color = band(utilizationPercent || 0);
  return (
    <div className="util-summary" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
      <div className="card">
        <div className="title">Available</div>
        <div className="value">{Number(availableHours || 0).toFixed(1)} hrs</div>
      </div>
      <div className="card">
        <div className="title">Allocated</div>
        <div className="value">{Number(allocatedHours || 0).toFixed(1)} hrs</div>
      </div>
      <div className="card">
        <div className="title">Logged</div>
        <div className="value">{Number(timesheetHours || 0).toFixed(1)} hrs</div>
      </div>
      <div className={`card ${color}`}>
        <div className="title">Utilization</div>
        <div className="value">{Number(utilizationPercent || 0).toFixed(1)}%</div>
      </div>
    </div>
  );
}

export default React.memo(UtilizationSummaryCards);