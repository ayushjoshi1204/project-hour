import React, { useMemo, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout, updateUser } = useAuth();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileSubmitting, setProfileSubmitting] = useState(false);
  const [profileData, setProfileData] = useState({ name: user?.name || '', email: user?.email || '' });
  const [originalProfile, setOriginalProfile] = useState({ name: user?.name || '', email: user?.email || '' });
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');

  const roleLabels = {
    admin: 'Administrator',
    pm: 'Project Manager',
    employee: 'Employee',
  };

  const initials = useMemo(() => {
    const name = profileData.name || user?.name || '';
    const parts = name.trim().split(' ').filter(Boolean);
    if (parts.length === 0) return 'PT';
    const first = parts[0][0] || '';
    const second = (parts[1] && parts[1][0]) || '';
    return (first + second).toUpperCase();
  }, [profileData.name, user?.name]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const openProfile = async () => {
    setProfileError('');
    setProfileSuccess('');
    setProfileOpen(true);
    setProfileLoading(true);
    try {
      const { data } = await axios.get('/api/auth/me');
      setProfileData({ name: data.name || '', email: data.email || '' });
      setOriginalProfile({ name: data.name || '', email: data.email || '' });
    } catch (error) {
      setProfileError(error.response?.data?.error || 'Failed to load profile');
      setProfileData({ name: user?.name || '', email: user?.email || '' });
      setOriginalProfile({ name: user?.name || '', email: user?.email || '' });
    } finally {
      setProfileLoading(false);
    }
  };

  const closeProfile = () => {
    setProfileOpen(false);
    setProfileError('');
    setProfileSuccess('');
    setPasswords({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setProfileError('');
    setProfileSuccess('');

    const payload = {};

    if (profileData.name && profileData.name !== originalProfile.name) {
      payload.name = profileData.name;
    }

    if (profileData.email && profileData.email !== originalProfile.email) {
      payload.email = profileData.email;
    }

    if (passwords.newPassword) {
      if (passwords.newPassword !== passwords.confirmPassword) {
        setProfileError('New password and confirm password do not match');
        return;
      }
      if (!passwords.currentPassword) {
        setProfileError('Current password is required to change password');
        return;
      }
      payload.newPassword = passwords.newPassword;
      payload.currentPassword = passwords.currentPassword;
    }

    if (Object.keys(payload).length === 0) {
      setProfileError('No changes to save');
      return;
    }

    setProfileSubmitting(true);
    try {
      const { data } = await axios.put('/api/auth/me', payload);
      setProfileSuccess('Profile updated successfully');
      setOriginalProfile({ name: data.user.name, email: data.user.email });
      setProfileData({ name: data.user.name, email: data.user.email });
      setPasswords({ currentPassword: '', newPassword: '', confirmPassword: '' });
      updateUser({ name: data.user.name, email: data.user.email });
    } catch (error) {
      setProfileError(error.response?.data?.error || 'Failed to update profile');
    } finally {
      setProfileSubmitting(false);
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar-title">
        <Link to={user.role === 'admin' ? '/admin' : user.role === 'pm' ? '/pm' : '/employee'} style={{ color: 'white', textDecoration: 'none' }}>
          Project Tracker
        </Link>
      </div>
      <div className="navbar-user">
        {user.role === 'admin' && (
          <>
            <Link to="/admin" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Dashboard</Link>
            <Link to="/admin/employees" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Employees</Link>
            <Link to="/admin/projects" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Projects</Link>
            <Link to="/admin/allocations" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Allocations</Link>
            <Link to="/admin/timesheets" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Timesheets</Link>
            <Link to="/admin/utilization" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Utilization</Link>
          </>
        )}
        {user.role === 'pm' && (
          <>
            <Link to="/pm" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Dashboard</Link>
            <Link to="/pm/employees" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Employees</Link>
            <Link to="/pm/projects" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Projects</Link>
            <Link to="/pm/allocations" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Allocations</Link>
            <Link to="/pm/utilization" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Utilization</Link>
          </>
        )}
        {user.role === 'employee' && (
          <>
            <Link to="/employee" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Dashboard</Link>
            <Link to="/employee/timesheet" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Timesheet</Link>
            <Link to="/employee/utilization" style={{ color: 'white', textDecoration: 'none', marginRight: 12 }}>Utilization</Link>
          </>
        )}
        <span
          style={{ cursor: 'pointer', marginRight: 12 }}
          onClick={openProfile}
        >
          Hello, {user.name}
        </span>
        <button onClick={handleLogout} className="btn-secondary">Logout</button>
      </div>

      {profileOpen && (
        <div className="modal">
          <div className="modal-content profile-modal">
            <div className="modal-header">
              <h2>My Profile</h2>
              <button onClick={closeProfile} className="modal-close">&times;</button>
            </div>

            <div className="profile-modal__hero">
              <div className="profile-modal__avatar">{initials}</div>
              <div className="profile-modal__meta">
                <h3>{profileData.name || user?.name}</h3>
                <p>{profileData.email || user?.email}</p>
                <div className="profile-modal__badges">
                  <span className={`role-badge role-badge--${user.role}`}>
                    {roleLabels[user.role] || user.role}
                  </span>
                  {user.empId && (
                    <span className="role-badge role-badge--muted">EmpID: {user.empId}</span>
                  )}
                </div>
              </div>
            </div>

            <form onSubmit={handleProfileSubmit}>
              <div className="profile-modal__section">
                <div className="profile-modal__sectionHeader">
                  <h4>Personal Details</h4>
                  <p>Make sure your name and email match official records.</p>
                </div>
                <div className="profile-modal__grid">
                  <div className="form-group">
                    <label>Full Name</label>
                    <input
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                      disabled={profileLoading}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>Email Address</label>
                    <input
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                      disabled={profileLoading}
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="profile-modal__section">
                <div className="profile-modal__sectionHeader">
                  <h4>Security</h4>
                  <p>Update your password regularly to keep your account safe.</p>
                </div>
                <div className="profile-modal__grid">
                  <div className="form-group">
                    <label>Current Password</label>
                    <input
                      type="password"
                      value={passwords.currentPassword}
                      onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })}
                      placeholder="Required only when changing password"
                      disabled={profileLoading}
                    />
                  </div>
                  <div className="form-group">
                    <label>New Password</label>
                    <input
                      type="password"
                      value={passwords.newPassword}
                      onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
                      disabled={profileLoading}
                    />
                  </div>
                  <div className="form-group" style={{ gridColumn: 'span 2' }}>
                    <label>Confirm New Password</label>
                    <input
                      type="password"
                      value={passwords.confirmPassword}
                      onChange={(e) => setPasswords({ ...passwords, confirmPassword: e.target.value })}
                      disabled={profileLoading}
                    />
                  </div>
                </div>
              </div>

              {profileLoading && !profileSubmitting && <div className="info">Loading profile...</div>}
              {profileError && <div className="error">{profileError}</div>}
              {profileSuccess && <div className="success">{profileSuccess}</div>}

              <div className="profile-modal__actions">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={closeProfile}
                  disabled={profileSubmitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn-success" disabled={profileSubmitting || profileLoading}>
                  {profileSubmitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
