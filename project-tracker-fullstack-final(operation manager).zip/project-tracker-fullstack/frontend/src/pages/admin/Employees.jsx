import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Employees = () => {
  const [employees, setEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState({
    empId: '', name: '', email: '', password: '', role: 'employee', doj: '', status: 'active'
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await axios.get('/api/employees');
      setEmployees(response.data);
    } catch (error) {
      setError('Failed to fetch employees');
    }
  };

  const openAddModal = () => {
    setCurrentEmployee({ empId: '', name: '', email: '', password: '', role: 'employee', doj: '', status: 'active' });
    setEditMode(false);
    setShowModal(true);
    setError('');
    setSuccess('');
  };

  const openEditModal = (employee) => {
    setCurrentEmployee({
      ...employee,
      empId: employee.empid,
      password: ''
    });
    setEditMode(true);
    setShowModal(true);
    setError('');
    setSuccess('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      if (editMode) {
        await axios.put(`/api/employees/${currentEmployee.employeeid}`, currentEmployee);
        setSuccess('Employee updated successfully');
      } else {
        await axios.post('/api/employees', currentEmployee);
        setSuccess('Employee created successfully');
      }
      fetchEmployees();
      setTimeout(() => setShowModal(false), 1500);
    } catch (error) {
      setError(error.response?.data?.error || 'Operation failed');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      try {
        await axios.delete(`/api/employees/${id}`);
        setSuccess('Employee deleted successfully');
        fetchEmployees();
      } catch (error) {
        setError('Failed to delete employee');
      }
    }
  };

  return (
    <div className="container">
      <h1>Employees Management</h1>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h2>Employees</h2>
          <button onClick={openAddModal} className="btn-primary">Add Employee</button>
        </div>

        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}

        <table>
          <thead>
            <tr>
              <th>EmpID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>DOJ</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp.employeeid}>
                <td>{emp.empid}</td>
                <td>{emp.name}</td>
                <td>{emp.email}</td>
                <td>{emp.role}</td>
                <td>{new Date(emp.doj).toLocaleDateString()}</td>
                <td>{emp.status}</td>
                <td>
                  <button onClick={() => openEditModal(emp)} className="btn-primary" style={{ marginRight: '5px' }}>Edit</button>
                  <button onClick={() => handleDelete(emp.employeeid)} className="btn-danger">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editMode ? 'Edit Employee' : 'Add Employee'}</h2>
              <button onClick={() => setShowModal(false)} className="modal-close">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>EmpID*</label>
                <input value={currentEmployee.empId} onChange={(e) => setCurrentEmployee({...currentEmployee, empId: e.target.value})} required disabled={editMode} />
              </div>
              <div className="form-group">
                <label>Name*</label>
                <input value={currentEmployee.name} onChange={(e) => setCurrentEmployee({...currentEmployee, name: e.target.value})} required />
              </div>
              <div className="form-group">
                <label>Email*</label>
                <input type="email" value={currentEmployee.email} onChange={(e) => setCurrentEmployee({...currentEmployee, email: e.target.value})} required />
              </div>
              {!editMode && (
                <div className="form-group">
                  <label>Password*</label>
                  <input type="password" value={currentEmployee.password} onChange={(e) => setCurrentEmployee({...currentEmployee, password: e.target.value})} required />
                </div>
              )}
              <div className="form-group">
                <label>Role*</label>
                <select value={currentEmployee.role} onChange={(e) => setCurrentEmployee({...currentEmployee, role: e.target.value})} required>
                  <option value="employee">Employee</option>
                  <option value="admin">Admin</option>
                  <option value="pm">Project Manager</option>
                </select>
              </div>
              <div className="form-group">
                <label>Date of Joining*</label>
                <input type="date" value={currentEmployee.doj} onChange={(e) => setCurrentEmployee({...currentEmployee, doj: e.target.value})} required />
              </div>
              {editMode && (
                <div className="form-group">
                  <label>Status*</label>
                  <select value={currentEmployee.status} onChange={(e) => setCurrentEmployee({...currentEmployee, status: e.target.value})} required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              )}
              {error && <div className="error">{error}</div>}
              {success && <div className="success">{success}</div>}
              <button type="submit" className="btn-success" style={{ marginTop: '10px' }}>{editMode ? 'Update' : 'Create'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Employees;
