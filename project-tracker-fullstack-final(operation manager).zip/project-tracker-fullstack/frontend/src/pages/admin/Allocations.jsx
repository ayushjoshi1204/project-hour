import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BarChart from '../../components/Analytics/BarChart';

const HOURS_PER_DAY = 8.5;
const MONTH_LABELS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

const toUTCDate = (year, monthIndex, day) => new Date(Date.UTC(year, monthIndex, day));

const countWeekdays = (startDate, endDate) => {
  if (!startDate || !endDate) return 0;
  const start = toUTCDate(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate());
  const end = toUTCDate(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate());
  if (start > end) return 0;
  let count = 0;
  for (let current = new Date(start); current <= end; current.setUTCDate(current.getUTCDate() + 1)) {
    const day = current.getUTCDay();
    if (day !== 0 && day !== 6) {
      count += 1;
    }
  }
  return count;
};

const calculateMonthlyAvailableHours = (employee, year, month) => {
  if (!employee) return 0;

  const startOfMonth = toUTCDate(year, month - 1, 1);
  const endOfMonth = toUTCDate(year, month, 0);
  const doj = employee.doj ? new Date(employee.doj) : null;
  const effectiveStart = doj && doj > startOfMonth ? doj : startOfMonth;

  if (effectiveStart > endOfMonth) return 0;

  const workingDays = countWeekdays(effectiveStart, endOfMonth);
  return Number((workingDays * HOURS_PER_DAY).toFixed(2));
};

const Allocations = () => {
  const [allocations, setAllocations] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [projects, setProjects] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentAllocation, setCurrentAllocation] = useState({
    employeeId: '',
    projectId: '',
    empName: '',
    role: '',
    allocatedHours: '',
    allocatedDays: '',
    // NEW: Specific month for allocation
    allocationYear: new Date().getUTCFullYear(),
    allocationMonth: new Date().getUTCMonth() + 1,
    selectedProject: null
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [availability, setAvailability] = useState(null);
  const [availabilityError, setAvailabilityError] = useState('');
  const [availabilityLoading, setAvailabilityLoading] = useState(false);
  const [employeeYearlySeries, setEmployeeYearlySeries] = useState([]);
  const [employeeYearLoading, setEmployeeYearLoading] = useState(false);
  const [employeeYearError, setEmployeeYearError] = useState('');
  const [employeeYearMaxAvailable, setEmployeeYearMaxAvailable] = useState(0);

  // Monthly summary state for selected employee
  const [summaryYear, setSummaryYear] = useState(new Date().getUTCFullYear());
  const [summaryMonth, setSummaryMonth] = useState(new Date().getUTCMonth() + 1);
  const [monthSummary, setMonthSummary] = useState(null);
  const [monthSummaryError, setMonthSummaryError] = useState('');
  const [monthSummaryLoading, setMonthSummaryLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [allocRes, empRes, projRes] = await Promise.all([
        axios.get('/api/allocations'),
        axios.get('/api/employees'),
        axios.get('/api/projects')
      ]);
      setAllocations(allocRes.data);
      setEmployees(empRes.data);
      setProjects(projRes.data);
    } catch (error) {
      setError('Failed to fetch data');
    }
  };

  // NEW: Check if selected allocation month is within project dates
  const isAllocationMonthValid = () => {
    if (!currentAllocation.selectedProject || 
        !currentAllocation.selectedProject.startdate || 
        !currentAllocation.selectedProject.enddate) {
      return true; // Can't validate without project dates
    }

    const allocationDate = new Date(currentAllocation.allocationYear, currentAllocation.allocationMonth - 1, 1);
    const projectStart = new Date(currentAllocation.selectedProject.startdate);
    const projectEnd = new Date(currentAllocation.selectedProject.enddate);
    
    // Set to first day of month for comparison
    projectStart.setUTCDate(1);
    projectEnd.setUTCDate(1);
    allocationDate.setUTCDate(1);
    
    return allocationDate >= projectStart && allocationDate <= projectEnd;
  };

  const resetModalState = () => {
    setError('');
    setSuccess('');
    setAvailability(null);
    setAvailabilityError('');
    setAvailabilityLoading(false);
    setEmployeeYearlySeries([]);
    setEmployeeYearError('');
    setEmployeeYearLoading(false);
  };

  const openAddModal = () => {
    setCurrentAllocation({
      employeeId: '',
      projectId: '',
      empName: '',
      role: '',
      allocatedHours: '',
      allocatedDays: '',
      allocationYear: new Date().getUTCFullYear(),
      allocationMonth: new Date().getUTCMonth() + 1,
      selectedProject: null
    });
    setEditMode(false);
    setShowModal(true);
    resetModalState();
  };

  const openEditModal = (allocation) => {
    const allocatedHours = allocation.allocatedhours || 0;
    const allocatedDays = allocatedHours ? (Number(allocatedHours) / HOURS_PER_DAY).toFixed(2) : '';

    setCurrentAllocation({
      ...allocation,
      employeeId: allocation.employeeid,
      projectId: allocation.projectid,
      empName: allocation.empname,
      allocatedHours,
      allocatedDays,
      // NEW: Set allocation month/year from existing data or default to current
      allocationYear: allocation.allocationyear || new Date().getUTCFullYear(),
      allocationMonth: allocation.allocationmonth || new Date().getUTCMonth() + 1,
      selectedProject: projects.find(p => p.projectid === allocation.projectid) || null
    });
    
    setEditMode(true);
    setShowModal(true);
    resetModalState();
    
    if (allocation.employeeid) {
      loadEmployeeYearlySeries(allocation.employeeid);
    }
  };

  const fetchAvailability = async (nextAllocationState, isEdit) => {
    const { employeeId, projectId, allocationid, allocationYear, allocationMonth } = nextAllocationState;
    
    if (!employeeId || !projectId || !allocationYear || !allocationMonth) {
      setAvailability(null);
      setAvailabilityError('');
      return;
    }

    try {
      setAvailabilityLoading(true);
      setAvailabilityError('');

      const params = {
        employeeId,
        projectId,
        year: allocationYear,    // NEW: Specific year
        month: allocationMonth   // NEW: Specific month
      };
      
      if (isEdit && allocationid) {
        params.excludeAllocationId = allocationid;
      }

      const res = await axios.get('/api/allocations/availability', { params });
      setAvailability(res.data);
    } catch (err) {
      setAvailability(null);
      setAvailabilityError(err.response?.data?.error || 'Failed to calculate availability');
    } finally {
      setAvailabilityLoading(false);
    }
  };

  const loadMonthlySummary = async (employeeIdToLoad, yearToLoad, monthToLoad) => {
    if (!employeeIdToLoad) {
      setMonthSummary(null);
      setMonthSummaryError('');
      return;
    }

    try {
      setMonthSummaryLoading(true);
      setMonthSummaryError('');
      const res = await axios.get(`/api/dashboard/employee/${employeeIdToLoad}`, {
        params: { year: yearToLoad, month: monthToLoad },
      });
      const employeeRecord = employees.find(
        (emp) => emp.employeeid === Number(employeeIdToLoad)
      );
      const calendarAvailable = calculateMonthlyAvailableHours(
        employeeRecord,
        yearToLoad,
        monthToLoad
      );
      setMonthSummary({
        ...res.data,
        availableHours: calendarAvailable || Number(res.data?.availableHours || 0),
      });
    } catch (err) {
      setMonthSummary(null);
      setMonthSummaryError(err.response?.data?.error || 'Failed to load monthly summary');
    } finally {
      setMonthSummaryLoading(false);
    }
  };

  const loadEmployeeYearlySeries = async (employeeId) => {
    if (!employeeId) {
      setEmployeeYearlySeries([]);
      setEmployeeYearError('');
      return;
    }
    try {
      setEmployeeYearLoading(true);
      setEmployeeYearError('');
      const year = new Date().getUTCFullYear();
      const months = Array.from({ length: 12 }, (_, i) => i + 1);
      const results = await Promise.all(
        months.map(m =>
          axios
            .get(`/api/dashboard/employee/${employeeId}`, { params: { year, month: m } })
            .then(res => res.data)
            .catch(() => null)
        )
      );
      const series = months.map((m, idx) => {
        const json = results[idx];
        return {
          label: MONTH_LABELS[m - 1],
          value: json ? Number(json.allocatedHours || 0) : 0,
          available: json ? Number(json.availableHours || 0) : 0,
        };
      });
      const maxAvailable = series.reduce((max, s) => Math.max(max, s.available || 0), 0);
      setEmployeeYearlySeries(series);
      setEmployeeYearMaxAvailable(maxAvailable);
    } catch (err) {
      setEmployeeYearError('Failed to load yearly utilization');
      setEmployeeYearlySeries([]);
    } finally {
      setEmployeeYearLoading(false);
    }
  };

  const handleEmployeeChange = async (empId) => {
    const emp = employees.find(e => e.employeeid === parseInt(empId));
    const next = {
      ...currentAllocation,
      employeeId: empId ? parseInt(empId) : '',
      empName: emp ? emp.name : '',
      projectId: '', // reset project when employee changes
      selectedProject: null // reset project when employee changes
    };
    setCurrentAllocation(next);
    await fetchAvailability(next, editMode);
    if (empId) {
      const numericId = parseInt(empId);
      loadEmployeeYearlySeries(numericId);
      await loadMonthlySummary(numericId, summaryYear, summaryMonth);
    } else {
      setEmployeeYearlySeries([]);
      setEmployeeYearError('');
      setMonthSummary(null);
      setMonthSummaryError('');
    }
  };

  const handleProjectChange = async (projectId) => {
    const selectedProject = projects.find(p => p.projectid === parseInt(projectId));
    
    const next = {
      ...currentAllocation,
      projectId: projectId ? parseInt(projectId) : '',
      selectedProject: selectedProject || null
    };
    
    setCurrentAllocation(next);
    await fetchAvailability(next, editMode);
  };

  const handleDaysChange = (value) => {
    const days = value === '' ? '' : Number(value);
    if (days === '') {
      setCurrentAllocation({
        ...currentAllocation,
        allocatedDays: '',
        allocatedHours: '',
      });
      return;
    }

    if (Number.isNaN(days)) return;

    const hours = days * HOURS_PER_DAY;
    setCurrentAllocation({
      ...currentAllocation,
      allocatedDays: value,
      allocatedHours: Number(hours.toFixed(2)),
    });
  };

  const handleHoursChange = (value) => {
    if (value === '') {
      setCurrentAllocation({
        ...currentAllocation,
        allocatedHours: '',
        allocatedDays: '',
      });
      return;
    }

    const hours = Number(value);
    if (Number.isNaN(hours)) return;

    const days = hours / HOURS_PER_DAY;
    setCurrentAllocation({
      ...currentAllocation,
      allocatedHours: hours,
      allocatedDays: Number(days.toFixed(2)),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // NEW: Validate allocation month is within project dates
    if (currentAllocation.selectedProject && !isAllocationMonthValid()) {
      setError('Allocation month must be within the project start and end dates');
      return;
    }

    // Client-side capacity guard - NOW CHECKING SPECIFIC MONTH
    if (availability && currentAllocation.allocatedHours !== '' && currentAllocation.allocatedHours != null) {
      const remainingBefore = availability.remainingHours ?? 0;
      const remainingAfter = remainingBefore - Number(currentAllocation.allocatedHours);
      
      if (remainingAfter < -0.0001) {
        setError(
          `Employee over-allocated for ${MONTH_LABELS[currentAllocation.allocationMonth - 1]} ${currentAllocation.allocationYear}. Remaining capacity is ${remainingBefore.toFixed(2)} hours, requested ${Number(currentAllocation.allocatedHours).toFixed(2)} hours.`
        );
        return;
      }
    }

    try {
      const payload = {
        ...currentAllocation,
        allocatedHours: currentAllocation.allocatedHours === '' ? 0 : currentAllocation.allocatedHours,
        // NEW: Include allocation month/year in payload
        allocationYear: currentAllocation.allocationYear,
        allocationMonth: currentAllocation.allocationMonth
      };

      // Remove selectedProject from payload before sending to API
      delete payload.selectedProject;

      if (editMode) {
        await axios.put(`/api/allocations/${currentAllocation.allocationid}`, payload);
        setSuccess('Allocation updated successfully');
      } else {
        await axios.post('/api/allocations', payload);
        setSuccess(`Allocation created for ${MONTH_LABELS[currentAllocation.allocationMonth - 1]} ${currentAllocation.allocationYear}`);
      }
      fetchData();
      setTimeout(() => setShowModal(false), 1500);
    } catch (error) {
      setError(error.response?.data?.error || 'Operation failed');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this allocation?')) {
      try {
        await axios.delete(`/api/allocations/${id}`);
        setSuccess('Allocation deleted successfully');
        fetchData();
      } catch (error) {
        setError('Failed to delete allocation');
      }
    }
  };

  // Determine which projects are available for the currently selected employee
  const assignedProjectIdsForEmployee = new Set(
    allocations
      .filter(a => a.employeeid === currentAllocation.employeeId)
      .map(a => a.projectid)
  );

  const availableProjects = projects.filter(proj => {
    if (!currentAllocation.employeeId) return true;
    // In edit mode, always include the current project even if already assigned
    if (editMode && currentAllocation.projectId === proj.projectid) return true;
    return !assignedProjectIdsForEmployee.has(proj.projectid);
  });

  const plannedHours =
    currentAllocation.allocatedHours !== '' && currentAllocation.allocatedHours != null
      ? Number(currentAllocation.allocatedHours)
      : null;
  const monthAvailableHours =
    monthSummary && monthSummary.availableHours != null
      ? Number(monthSummary.availableHours)
      : null;
  const monthAllocatedHours =
    monthSummary && monthSummary.allocatedHours != null
      ? Number(monthSummary.allocatedHours)
      : null;
  const monthBalanceBefore =
    monthAvailableHours != null && monthAllocatedHours != null
      ? monthAvailableHours - monthAllocatedHours
      : null;
  const monthBalanceAfter =
    monthBalanceBefore != null && plannedHours != null
      ? monthBalanceBefore - plannedHours
      : null;
  const showMonthBalance =
    monthBalanceAfter != null && Number.isFinite(monthBalanceAfter);

  return (
    <div className="container">
      <h1>Allocations Management</h1>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <h2>Allocations</h2>
          <button onClick={openAddModal} className="btn-primary">Add Allocation</button>
        </div>

        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}

        <table>
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Project Code</th>
              <th>Entity</th>
              <th>Role</th>
              <th>Allocated Hours</th>
              <th>Allocation Month</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {allocations.map((alloc) => {
              const allocationMonth = alloc.allocationmonth || new Date().getUTCMonth() + 1;
              const allocationYear = alloc.allocationyear || new Date().getUTCFullYear();
              
              return (
                <tr key={alloc.allocationid}>
                  <td>{alloc.employeename}</td>
                  <td>{alloc.projectcode}</td>
                  <td>{alloc.entity}</td>
                  <td>{alloc.role}</td>
                  <td>{alloc.allocatedhours}</td>
                  <td>{MONTH_LABELS[allocationMonth - 1]} {allocationYear}</td>
                  <td>
                    <button onClick={() => openEditModal(alloc)} className="btn-primary" style={{ marginRight: '5px' }}>Edit</button>
                    <button onClick={() => handleDelete(alloc.allocationid)} className="btn-danger">Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editMode ? 'Edit Allocation' : 'Add Allocation'}</h2>
              <button onClick={() => setShowModal(false)} className="modal-close">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Employee*</label>
                <select 
                  value={currentAllocation.employeeId} 
                  onChange={(e) => handleEmployeeChange(e.target.value)} 
                  required
                  disabled={editMode}
                >
                  <option value="">Select Employee</option>
                  {employees.map(emp => (
                    <option key={emp.employeeid} value={emp.employeeid}>
                      {emp.name} ({emp.empid})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Project*</label>
                <select 
                  value={currentAllocation.projectId} 
                  onChange={(e) => handleProjectChange(e.target.value)} 
                  required
                  disabled={editMode}
                >
                  <option value="">Select Project</option>
                  {availableProjects.map(proj => (
                    <option key={proj.projectid} value={proj.projectid}>
                      {proj.projectcode} - {proj.entity} 
                      {proj.startdate && proj.enddate && 
                        ` (${new Date(proj.startdate).toLocaleDateString()} - ${new Date(proj.enddate).toLocaleDateString()})`
                      }
                    </option>
                  ))}
                </select>
                
                {/* NEW: Show allocation period info */}
                {currentAllocation.selectedProject && (
                  <div style={{ fontSize: '12px', color: '#666', marginTop: '4px' }}>
                    Project Period: {new Date(currentAllocation.selectedProject.startdate).toLocaleDateString()} - {new Date(currentAllocation.selectedProject.enddate).toLocaleDateString()}
                  </div>
                )}
              </div>

              {/* NEW: Allocation Month Selection */}
              <div className="form-group">
                <label>Allocation Month*</label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <select 
                    value={currentAllocation.allocationMonth} 
                    onChange={(e) => setCurrentAllocation({
                      ...currentAllocation, 
                      allocationMonth: parseInt(e.target.value)
                    })} 
                    required
                  >
                    <option value="">Month</option>
                    {MONTH_LABELS.map((month, index) => (
                      <option key={index + 1} value={index + 1}>
                        {month}
                      </option>
                    ))}
                  </select>
                  
                  <input 
                    type="number" 
                    value={currentAllocation.allocationYear} 
                    onChange={(e) => setCurrentAllocation({
                      ...currentAllocation, 
                      allocationYear: parseInt(e.target.value)
                    })} 
                    min="2020"
                    max="2030"
                    style={{ width: '100px' }}
                    required
                  />
                </div>
                
                {/* NEW: Show validation if selected month is outside project dates */}
                {currentAllocation.selectedProject && 
                 currentAllocation.allocationMonth && 
                 currentAllocation.allocationYear && (
                  <div style={{ fontSize: '12px', marginTop: '4px' }}>
                    {isAllocationMonthValid() ? (
                      <span style={{ color: 'green' }}>✓ Allocation will be for {MONTH_LABELS[currentAllocation.allocationMonth - 1]} {currentAllocation.allocationYear} only</span>
                    ) : (
                      <span style={{ color: 'red' }}>⚠ Selected month is outside project dates</span>
                    )}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Role*</label>
                <select
                  value={currentAllocation.role}
                  onChange={(e) => setCurrentAllocation({ ...currentAllocation, role: e.target.value })}
                  required
                >
                  <option value="">Select Role</option>
                  <option value="Project Manager">Project Manager</option>
                  <option value="Tribe Lead">Tribe Lead</option>
                  <option value="Business Analyst">Business Analyst</option>
                  <option value="Solution Architect">Solution Architect</option>
                  <option value="Developer">Developer</option>
                  <option value="Operation Management">Operation Management</option>
                </select>
              </div>

              <div className="form-group">
                <label>Allocated Days*</label>
                <input 
                  type="number" 
                  value={currentAllocation.allocatedDays} 
                  onChange={(e) => handleDaysChange(e.target.value)} 
                  min="0" 
                  step="0.5" 
                  placeholder="e.g., 10 days = 85 hours" 
                  required
                />
                <small>
                  1 day = {HOURS_PER_DAY} hours | 
                  {currentAllocation.allocatedDays && 
                    ` ${currentAllocation.allocatedDays} days = ${(currentAllocation.allocatedDays * HOURS_PER_DAY).toFixed(1)} hours for ${currentAllocation.allocationMonth ? MONTH_LABELS[currentAllocation.allocationMonth - 1] : ''} only`
                  }
                </small>
              </div>

              <div className="form-group">
                <label>Allocated Hours*</label>
                <input 
                  type="number" 
                  value={currentAllocation.allocatedHours} 
                  onChange={(e) => handleHoursChange(e.target.value)} 
                  required 
                  min="0"
                  step="0.5"
                />
              </div>

              <div className="form-group">
                <label>Yearly Utilization Overview</label>
                {employeeYearLoading && <div className="info">Loading yearly utilization...</div>}
                {employeeYearError && <div className="error">{employeeYearError}</div>}
                {!employeeYearLoading && !employeeYearError && employeeYearlySeries.length > 0 && (
                  <div style={{ marginTop: '4px' }}>
                    <BarChart
                      rows={employeeYearlySeries}
                      width={320}
                      height={140}
                      color="#3b82f6"
                      maxValue={employeeYearMaxAvailable || undefined}
                    />
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Monthly Capacity Snapshot</label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                  <label style={{ fontSize: 12 }}>
                    Year
                    <input
                      type="number"
                      value={summaryYear}
                      onChange={(e) => setSummaryYear(Number(e.target.value))}
                      style={{ width: 90, marginLeft: 4 }}
                    />
                  </label>
                  <label style={{ fontSize: 12 }}>
                    Month
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={summaryMonth}
                      onChange={(e) => setSummaryMonth(Number(e.target.value))}
                      style={{ width: 70, marginLeft: 4 }}
                    />
                  </label>
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => currentAllocation.employeeId && loadMonthlySummary(currentAllocation.employeeId, summaryYear, summaryMonth)}
                    disabled={!currentAllocation.employeeId || monthSummaryLoading}
                  >
                    Refresh
                  </button>
                </div>
                {monthSummaryLoading && <div className="info">Loading monthly summary...</div>}
                {monthSummaryError && <div className="error">{monthSummaryError}</div>}
                {monthSummary && !monthSummaryLoading && !monthSummaryError && (
                  <div style={{ marginTop: 4 }}>
                    <table className="table" style={{ fontSize: 12 }}>
                      <thead>
                        <tr>
                          <th>Project</th>
                          <th>Allocated Hours</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><strong>Total available hours (month)</strong></td>
                          <td><strong>{Number(monthSummary.availableHours || 0).toFixed(2)}</strong></td>
                        </tr>
                        {Array.isArray(monthSummary.byProject) && monthSummary.byProject.length > 0 && (
                          monthSummary.byProject.map(p => (
                            <tr key={p.projectCode}>
                              <td>{p.projectCode}</td>
                              <td>{Number(p.allocated || 0).toFixed(2)}</td>
                            </tr>
                          ))
                        )}
                        <tr>
                          <td><strong>Remaining hours</strong></td>
                          <td>
                            <strong>
                              {Number((monthSummary.availableHours || 0) - (monthSummary.allocatedHours || 0)).toFixed(2)}
                            </strong>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {availabilityLoading && <div className="info">Checking availability...</div>}
              {showMonthBalance ? (
                <div className="info">
                  Balance after this allocation:{' '}
                    <strong>{monthBalanceAfter.toFixed(2)} hours</strong>
                </div>
              ) : (
                availability &&
                plannedHours != null && (
                  <div className="info">
                    Balance after this allocation:{' '}
                    <strong>
                      {(availability.remainingHours - plannedHours).toFixed(2)} hours
                    </strong>
                  </div>
                )
              )}
              {availabilityError && <div className="error">{availabilityError}</div>}
              {error && <div className="error">{error}</div>}
              {success && <div className="success">{success}</div>}
              <button type="submit" className="btn-success" style={{ marginTop: '10px' }}>{editMode ? 'Update' : 'Create'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Allocations;