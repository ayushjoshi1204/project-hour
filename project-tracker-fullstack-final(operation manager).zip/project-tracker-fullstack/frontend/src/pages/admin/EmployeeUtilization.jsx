import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import UtilizationSummaryCards from '../../components/Utilization/UtilizationSummaryCards';
import UtilizationBar from '../../components/Utilization/UtilizationBar';
import PieChart from '../../components/Analytics/PieChart';
import BarChart from '../../components/Analytics/BarChart';
import '../../components/Utilization/utilization.css';

const DEFAULT_WORK_HOURS = 42.5;

const toUTCDate = (year, monthIndex, day) => new Date(Date.UTC(year, monthIndex, day));

const countWeekdays = (startDate, endDate) => {
  if (!startDate || !endDate) return 0;
  const start = toUTCDate(startDate.getUTCFullYear(), startDate.getUTCMonth(), startDate.getUTCDate());
  const end = toUTCDate(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate());
  if (start > end) return 0;
  let count = 0;
  for (let current = new Date(start); current <= end; current.setUTCDate(current.getUTCDate() + 1)) {
    const day = current.getUTCDay();
    if (day !== 0 && day !== 6) {
      count += 1;
    }
  }
  return count;
};

const calculateMonthlyAvailableHours = (dojValue, workHoursPerWeek, year, month) => {
  const startOfMonth = toUTCDate(year, month - 1, 1);
  const endOfMonth = toUTCDate(year, month, 0);
  const doj = dojValue ? new Date(dojValue) : null;
  const effectiveStart = doj && doj > startOfMonth ? doj : startOfMonth;
  if (effectiveStart > endOfMonth) return 0;
  const adjustedStart = toUTCDate(effectiveStart.getUTCFullYear(), effectiveStart.getUTCMonth(), effectiveStart.getUTCDate());
  const workingDays = countWeekdays(adjustedStart, endOfMonth);
  const hoursPerDay = Number(workHoursPerWeek || DEFAULT_WORK_HOURS) / 5;
  return Number((workingDays * hoursPerDay).toFixed(2));
};

function useToken() {
  return localStorage.getItem('token');
}

async function apiGet(path, token) {
  const res = await fetch(path, { headers: { 'Authorization': `Bearer ${token}` }});
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export default function AdminEmployeeUtilization() {
  const token = useToken();
  const navigate = useNavigate();
  const { employeeId } = useParams();

  const [year, setYear] = useState(new Date().getUTCFullYear());
  const [month, setMonth] = useState(new Date().getUTCMonth() + 1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [monthlySeries, setMonthlySeries] = useState([]); // [{label, value}]
  const [yearTotals, setYearTotals] = useState(null); // {availableHours, allocatedHours, timesheetHours, utilizationPercent}
  const [employeeMeta, setEmployeeMeta] = useState(null); // holds EmpID etc. for header display

  const monthLabels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  async function loadMonthlySeries(empId, yr, employeeDetails) {
    if (!empId) return;
    const months = Array.from({ length: 12 }, (_, i) => i + 1);
    try {
      const results = await Promise.all(
        months.map(m => apiGet(`/api/dashboard/employee/${empId}?year=${yr}&month=${m}`, token).catch(() => null))
      );
      const series = months.map((m, idx) => {
        const json = results[idx];
        return {
          label: monthLabels[m - 1],
          value: json ? Number(json.timesheetHours || 0) : 0,
        };
      });
      setMonthlySeries(series);

      // Compute yearly totals based on monthly dashboard data
      let totalAvailable = 0;
      let totalAllocated = 0;
      let totalTimesheet = 0;
      results.forEach((json, idx) => {
        if (!json) return;
        const fallbackAvailable = calculateMonthlyAvailableHours(
          employeeDetails?.doj,
          employeeDetails?.workhoursperweek,
          yr,
          months[idx]
        );
        const availableHours =
          Number(json.availableHours) > 0 ? Number(json.availableHours) : fallbackAvailable || 0;
        totalAvailable += availableHours;
        totalAllocated += Number(json.allocatedHours || 0);
        totalTimesheet += Number(json.timesheetHours || 0);
      });
      const utilizationPercent = totalAvailable > 0
        ? Number(((totalTimesheet / totalAvailable) * 100).toFixed(2))
        : 0;
      setYearTotals({
        availableHours: totalAvailable,
        allocatedHours: totalAllocated,
        timesheetHours: totalTimesheet,
        utilizationPercent,
      });
    } catch {
      setMonthlySeries([]);
      setYearTotals(null);
    }
  }

  async function load() {
    if (!employeeId) return;
    try {
      setLoading(true); setError('');
      const url = `/api/dashboard/employee/${employeeId}?year=${year}&month=${month}`;
      let employeeDetails = null;
      try {
        employeeDetails = await apiGet(`/api/employees/${employeeId}`, token);
        setEmployeeMeta(employeeDetails);
      } catch {
        setEmployeeMeta(null);
      }
      const json = await apiGet(url, token);
      const fallbackAvailable = calculateMonthlyAvailableHours(
        employeeDetails?.doj,
        employeeDetails?.workhoursperweek,
        json.period?.year || year,
        json.period?.month || month
      );
      const enriched = {
        ...json,
        availableHours:
          Number(json.availableHours) > 0 ? Number(json.availableHours) : fallbackAvailable || 0,
      };
      setData(enriched);
      await loadMonthlySeries(employeeId, year, employeeDetails);
    } catch (e) { setError(String(e)); } finally { setLoading(false); }
  }

  useEffect(() => { if (token && employeeId) load(); }, [employeeId, year, month]);

  const monthlyAvailable = Number(data?.availableHours || 0);
  const monthlyAllocated = Number(data?.allocatedHours || 0);
  const monthlyTimesheet = Number(data?.timesheetHours || 0);

  const yearlyAvailable = Number(yearTotals?.availableHours || 0);
  const yearlyAllocated = Number(yearTotals?.allocatedHours || 0);
  const yearlyTimesheet = Number(yearTotals?.timesheetHours || 0);
  const yearlyUtilization = Number(yearTotals?.utilizationPercent || 0);

  const summaryAvailable = yearlyAvailable > 0 ? yearlyAvailable : monthlyAvailable;
  const summaryAllocated = yearlyAllocated > 0 ? yearlyAllocated : monthlyAllocated;
  const summaryTimesheet = yearlyTimesheet > 0 ? yearlyTimesheet : monthlyTimesheet;
  const summaryUtilization =
    yearlyAvailable > 0
      ? yearlyUtilization
      : monthlyAvailable > 0
      ? Number(((monthlyTimesheet / monthlyAvailable) * 100).toFixed(2))
      : 0;

  return (
    <div className="container">
      <div className="panel" style={{ display:'flex', alignItems:'center', gap:12 }}>
        <button onClick={() => navigate(-1)}>{'< Back'}</button>
        <h2 style={{ margin: 0 }}>
          Employee Utilization
          {data?.name && (
            employeeMeta?.empid
              ? ` - ${data.name} (ID ${employeeMeta.empid})`
              : ` - ${data.name} (ID ${data.employeeId})`
          )}
        </h2>
      </div>

      <div className="panel" style={{ marginBottom: 12 }}>
        <div className="filter-bar">
          <label>Year <input type="number" value={year} onChange={e=>setYear(Number(e.target.value))} style={{ width: 100 }} /></label>
          <label>Month <input type="number" value={month} onChange={e=>setMonth(Number(e.target.value))} min={1} max={12} style={{ width: 100 }} /></label>
          <button onClick={load}>Load</button>
        </div>
      </div>

      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}

      {data && (
        <>
          <div className="panel">
            <UtilizationSummaryCards
              availableHours={summaryAvailable}
              allocatedHours={summaryAllocated}
              timesheetHours={summaryTimesheet}
              utilizationPercent={summaryUtilization}
            />
          </div>

          {monthlySeries.length > 0 && (
            <div className="panel" style={{ marginTop: 16 }}>
              <h3>Monthly Hours ({year})</h3>
              <BarChart rows={monthlySeries} width={640} height={220} color="#3b82f6" />
            </div>
          )}

          <div className="panel" style={{ marginTop: 16 }}>
            <h3>Projects</h3>
            <div style={{ display:'flex', gap:16, alignItems:'flex-start', flexWrap:'wrap' }}>
              <div>
                <h5 style={{ marginTop: 0 }}>By Project (Pie)</h5>
                <PieChart
                  slices={(data.byProject||[]).map(b => ({ label: b.projectCode, value: Number(b.logged||0), name: b.projectCode }))}
                  size={320}
                  innerRadius={0}
                />
              </div>
              <div style={{ flex:1, minWidth: 300 }}>
                <h5 style={{ marginTop: 0 }}>By Project (Bar)</h5>
                <UtilizationBar rows={(data.byProject||[]).map(b => ({ label: b.projectCode, utilizationPercent: b.utilizationPercent }))} />

                <table className="table" style={{ marginTop: 12, fontSize: 12 }}>
                  <thead><tr><th>Project</th><th>Allocated</th><th>Logged</th><th>Util%</th></tr></thead>
                  <tbody>
                    {(data.byProject||[]).map(r => (
                      <tr key={r.projectCode}>
                        <td>{r.projectCode}</td>
                        <td>{Number(r.allocated).toFixed(1)}</td>
                        <td>{Number(r.logged).toFixed(1)}</td>
                        <td>{Number(r.utilizationPercent).toFixed(1)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
