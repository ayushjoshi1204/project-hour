import React, { useEffect, useState, useRef } from 'react';
import UtilizationSummaryCards from '../../components/Utilization/UtilizationSummaryCards';
import UtilizationBar from '../../components/Utilization/UtilizationBar';
import PieChart from '../../components/Analytics/PieChart';
import BarChart from '../../components/Analytics/BarChart';
import '../../components/Utilization/utilization.css';

function useAuth() {
  const raw = localStorage.getItem('user');
  let user = null; try { user = JSON.parse(raw || 'null'); } catch {}
  const token = localStorage.getItem('token');
  return { user, token };
}

async function apiGet(path, token) {
  const res = await fetch(path, { headers: { 'Authorization': `Bearer ${token}` }});
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export default function EmployeeUtilization() {
  const { user, token } = useAuth();
  const [year, setYear] = useState(new Date().getUTCFullYear());
  const [month, setMonth] = useState(new Date().getUTCMonth() + 1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [monthlySeries, setMonthlySeries] = useState([]); // [{label, value}]
  const [yearTotals, setYearTotals] = useState(null); // {availableHours, allocatedHours, timesheetHours, utilizationPercent}
  const yearlyCacheRef = useRef({}); // cache per year: { [year]: { series, totals } }

  const monthLabels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  async function loadMonthlySeries(empId, yr) {
    if (!empId) return;
    // Use cached data if available
    const cached = yearlyCacheRef.current[yr];
    if (cached) {
      setMonthlySeries(cached.series);
      setYearTotals(cached.totals);
      return;
    }
    const months = Array.from({ length: 12 }, (_, i) => i + 1);
    try {
      const results = await Promise.all(
        months.map(m => apiGet(`/api/dashboard/employee/${empId}?year=${yr}&month=${m}`, token).catch(() => null))
      );
      const series = months.map((m, idx) => {
        const json = results[idx];
        return {
          label: monthLabels[m - 1],
          value: json ? Number(json.timesheetHours || 0) : 0,
        };
      });
      setMonthlySeries(series);

      // Compute yearly totals based on calendar working days (backend provides availableHours per month)
      let totalAvailable = 0;
      let totalAllocated = 0;
      let totalTimesheet = 0;
      results.forEach(json => {
        if (!json) return;
        totalAvailable += Number(json.availableHours || 0);
        totalAllocated += Number(json.allocatedHours || 0);
        totalTimesheet += Number(json.timesheetHours || 0);
      });
      const utilizationPercent = totalAvailable > 0
        ? Number(((totalTimesheet / totalAvailable) * 100).toFixed(2))
        : 0;
      setYearTotals({
        availableHours: totalAvailable,
        allocatedHours: totalAllocated,
        timesheetHours: totalTimesheet,
        utilizationPercent,
      });
      // cache the results to avoid re-fetching when changing month
      yearlyCacheRef.current[yr] = { series, totals: { availableHours: totalAvailable, allocatedHours: totalAllocated, timesheetHours: totalTimesheet, utilizationPercent } };
    } catch {
      setMonthlySeries([]);
      setYearTotals(null);
    }
  }

  async function load() {
    if (!user) return;
    try {
      setLoading(true); setError('');
      const url = `/api/dashboard/employee/${user.employeeId}?year=${year}&month=${month}`;
      const json = await apiGet(url, token);
      setData(json);
      await loadMonthlySeries(user.employeeId, year);
    } catch (e) { setError(String(e)); } finally { setLoading(false); }
  }

  useEffect(() => { if (token && user) load(); }, [token, user, year]);

  const yearlyAvailable = yearTotals?.availableHours || 0;
  const yearlyAllocated = yearTotals?.allocatedHours || 0;
  const yearlyTimesheet = yearTotals?.timesheetHours || 0;
  const yearlyUtilization = yearTotals?.utilizationPercent || 0;

  return (
    <div className="container">
      <h2>
        My Utilization
        {user?.empId && ` - ${user.empId}`}
      </h2>
      <div className="panel" style={{ marginBottom: 12 }}>
        <div className="filter-bar">
          <label>Year <input type="number" value={year} onChange={e=>setYear(Number(e.target.value))} style={{ width: 100 }} /></label>
          <label>Month <input type="number" value={month} onChange={e=>setMonth(Number(e.target.value))} min={1} max={12} style={{ width: 100 }} /></label>
          <button onClick={load}>Load</button>
        </div>
      </div>

      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}

      {data && (
        <>
          <div className="panel">
            <UtilizationSummaryCards
              availableHours={yearlyAvailable}
              allocatedHours={yearlyAllocated}
              timesheetHours={yearlyTimesheet}
              utilizationPercent={yearlyUtilization}
            />
          </div>

          {monthlySeries.length > 0 && (
            <div className="panel" style={{ marginTop: 16 }}>
              <h3>Monthly Hours ({year})</h3>
              <BarChart rows={monthlySeries} width={640} height={220} color="#3b82f6" />
            </div>
          )}

          <div className="panel" style={{ marginTop: 16 }}>
            <h3>By Project</h3>
            <div style={{ display:'flex', gap:16, alignItems:'flex-start', flexWrap:'wrap' }}>
              <div>
                <h5 style={{ marginTop: 0 }}>Distribution (Pie)</h5>
                <PieChart
                  slices={(data.byProject||[]).map(b => ({ label: b.projectCode, value: Number(b.logged||0), name: b.projectCode }))}
                  size={320}
                  innerRadius={0}
                />
              </div>
              <div style={{ flex:1, minWidth: 300 }}>
                <h5 style={{ marginTop: 0 }}>Utilization (Bar)</h5>
                <UtilizationBar rows={(data.byProject||[]).map(b => ({ label: b.projectCode, utilizationPercent: b.utilizationPercent }))} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}