import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';
import { startOfWeek, endOfWeek, addWeeks, subWeeks, format, addDays } from 'date-fns';
import './Timesheet.css';

const Timesheet = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [allocations, setAllocations] = useState([]);
  const [entries, setEntries] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Non-billable options common for all employees
  const nonBillableOptions = [
    { id: 'sick_leave', name: 'Sick Leave', billingAction: 'Non-Billable', category: 'leave' },
    { id: 'casual_leave', name: 'Causal Leave', billingAction: 'Non-Billable', category: 'leave' },
    { id: 'optional_leave', name: 'Optional Leave', billingAction: 'Non-Billable', category: 'leave' },
    { id: 'maternity_leave', name: 'Maternity Leave', billingAction: 'Non-Billable', category: 'leave' },
    { id: 'adhoc', name: 'ADHOC', billingAction: 'Non-Billable', category: 'other' },
    { id: 'meetings', name: 'Meetings', billingAction: 'Non-Billable', category: 'other' },
    { id: 'interview', name: 'Interview', billingAction: 'Non-Billable', category: 'other' },
    { id: 'training', name: 'Training', billingAction: 'Non-Billable', category: 'other' },
    { id: 'demo', name: 'Demo', billingAction: 'Non-Billable', category: 'other' }
  ];

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 }); // Monday
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 }); // Sunday
  const daysOfWeek = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  useEffect(() => {
    fetchAllocations();
  }, []);

  const fetchAllocations = async () => {
    try {
      const response = await axios.get(`/api/allocations/employee/${user.employeeId}`);
      setAllocations(response.data);
      
      // Initialize with one empty row
      if (response.data.length > 0 || nonBillableOptions.length > 0) {
        addNewRow();
      }
    } catch (error) {
      setError('Failed to fetch allocations');
      console.error('Error fetching allocations:', error);
    } finally {
      setLoading(false);
    }
  };

  const addNewRow = () => {
    const newEntry = {
      id: Date.now(),
      projectId: '',
      projectType: '', // 'allocation' or 'non-billable'
      billingAction: '',
      activity: '',
      hours: {
        [format(daysOfWeek[0], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[1], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[2], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[3], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[4], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[5], 'yyyy-MM-dd')]: 0,
        [format(daysOfWeek[6], 'yyyy-MM-dd')]: 0,
      },
      notes: ''
    };
    setEntries([...entries, newEntry]);
  };

  const deleteRow = (id) => {
    setEntries(entries.filter(entry => entry.id !== id));
  };

  const handleProjectChange = (id, value) => {
    // Check if it's a non-billable option (starts with "nonbillable_")
    if (value.startsWith('nonbillable_')) {
      const nonBillableId = value.replace('nonbillable_', '');
      const nonBillableOption = nonBillableOptions.find(opt => opt.id === nonBillableId);
      
      setEntries(entries.map(entry => 
        entry.id === id 
          ? { 
              ...entry, 
              projectId: null, // Set to null for non-billable
              projectType: 'non-billable',
              billingAction: nonBillableOption.billingAction,
              activity: nonBillableOption.name,
              nonBillableType: nonBillableId // Store the specific non-billable type
            } 
          : entry
      ));
    } else {
      // It's a regular project allocation
      const allocation = allocations.find(a => a.projectid === parseInt(value));
      setEntries(entries.map(entry => 
        entry.id === id 
          ? { 
              ...entry, 
              projectId: parseInt(value), 
              projectType: 'allocation',
              billingAction: allocation ? allocation.billingaction : '',
              activity: allocation ? allocation.role : '',
              nonBillableType: null // Clear non-billable type for allocation projects
            } 
          : entry
      ));
    }
  };

  const handleHourChange = (id, day, value) => {
    const hours = parseFloat(value) || 0;
    if (hours < 0 || hours > 24) return;

    setError('');

    setEntries(entries.map(entry =>
      entry.id === id
        ? { ...entry, hours: { ...entry.hours, [day]: hours } }
        : entry
    ));
  };

  const handleActivityChange = (id, value) => {
    setEntries(entries.map(entry =>
      entry.id === id ? { ...entry, activity: value } : entry
    ));
  };

  const handleNotesChange = (id, value) => {
    setEntries(entries.map(entry =>
      entry.id === id ? { ...entry, notes: value } : entry
    ));
  };

  const calculateRowTotal = (entry) => {
    return Object.values(entry.hours).reduce((sum, h) => sum + parseFloat(h || 0), 0);
  };

  const calculateDayTotal = (day) => {
    return entries.reduce((sum, entry) => sum + parseFloat(entry.hours[day] || 0), 0);
  };

  const calculateGrandTotal = () => {
    return entries.reduce((sum, entry) => sum + calculateRowTotal(entry), 0);
  };

  const previousWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };

  const nextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };

  const validateAndSubmit = async () => {
    setError('');
    setSuccess('');

    // Filter out empty rows
    const validEntries = entries.filter(entry => 
      (entry.projectId || entry.projectType === 'non-billable') && calculateRowTotal(entry) > 0
    );

    if (validEntries.length === 0) {
      setError('Please add at least one timesheet entry');
      return;
    }

    // Validate total hours (42.5 ± 2)
    const totalHours = calculateGrandTotal();
    const EXPECTED_HOURS = 42.5;
    const THRESHOLD = 2;

    if (Math.abs(totalHours - EXPECTED_HOURS) > THRESHOLD) {
      setError(`Total weekly hours must be ${EXPECTED_HOURS} (±${THRESHOLD}). Current: ${totalHours}`);
      return;
    }

    // Check for duplicates (only for allocation projects, non-billable can have duplicates)
    const projectActivitySet = new Set();
    for (const entry of validEntries) {
      if (entry.projectType === 'allocation') {
        const key = `${entry.projectId}-${entry.activity}`;
        if (projectActivitySet.has(key)) {
          setError(`Duplicate entry found for Project and Activity combination`);
          return;
        }
        projectActivitySet.add(key);
      }
    }

    // Submit
    setSubmitting(true);
    try {
      await axios.post('/api/timesheets/submit', {
        weekStartDate: format(weekStart, 'yyyy-MM-dd'),
        weekEndDate: format(weekEnd, 'yyyy-MM-dd'),
        entries: validEntries.map(entry => ({
          projectId: entry.projectType === 'non-billable' ? null : entry.projectId,
          projectType: entry.projectType,
          billingAction: entry.billingAction,
          activity: entry.activity,
          hours: entry.hours,
          notes: entry.notes,
          nonBillableType: entry.nonBillableType
        }))
      });

      setSuccess('Timesheet submitted successfully!');
      setTimeout(() => {
        navigate('/employee');
      }, 2000);
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to submit timesheet');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  const hasAnyOptions = allocations.length > 0 || nonBillableOptions.length > 0;

  if (!hasAnyOptions) {
    return (
      <div className="container">
        <h1>Timesheet</h1>
        <div className="card">
          <p>You don't have any project allocations yet. Please contact your administrator.</p>
        </div>
      </div>
    );
  }

  const grandTotal = calculateGrandTotal();

  return (
    <div className="container">
      <h1>Timesheet</h1>

      <div className="card">
        <div className="week-navigator">
          <button onClick={previousWeek} className="btn-secondary">&lt; Previous</button>
          <h3>
            Week: {format(weekStart, 'MMM dd, yyyy')} - {format(weekEnd, 'MMM dd, yyyy')}
          </h3>
          <button onClick={nextWeek} className="btn-secondary">Next &gt;</button>
        </div>

        <div className="timesheet-grid">
          <table className="timesheet-table">
            <thead>
              <tr>
                <th>Project / Activity</th>
                <th>Billing Action</th>
                <th>Activity</th>
                {daysOfWeek.map(day => (
                  <th key={day.toString()}>
                    {format(day, 'EEE')}<br />
                    {format(day, 'MM/dd')}
                  </th>
                ))}
                <th>Total</th>
                <th>Notes</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <tr key={entry.id}>
                  <td>
                    <select
                      value={entry.projectType === 'non-billable' ? `nonbillable_${entry.nonBillableType}` : entry.projectId}
                      onChange={(e) => handleProjectChange(entry.id, e.target.value)}
                      style={{ marginBottom: 0 }}
                    >
                      <option value="">Select Project/Activity</option>
                      
                      {/* Project Allocations */}
                      {allocations.length > 0 && (
                        <optgroup label="Project Allocations">
                          {allocations.map(alloc => (
                            <option key={alloc.projectid} value={alloc.projectid}>
                              {alloc.projectcode} - {alloc.entity}
                            </option>
                          ))}
                        </optgroup>
                      )}
                      
                      {/* Non-Billable Activities */}
                      {nonBillableOptions.length > 0 && (
                        <optgroup label="Non-Billable Activities">
                          {nonBillableOptions.map(option => (
                            <option key={option.id} value={`nonbillable_${option.id}`}>
                              {option.name}
                            </option>
                          ))}
                        </optgroup>
                      )}
                    </select>
                  </td>
                  <td>{entry.billingAction}</td>
                  <td>
                    <select
                      value={entry.activity}
                      onChange={(e) => handleActivityChange(entry.id, e.target.value)}
                      style={{ marginBottom: 0, minWidth: '150px' }}
                      disabled={entry.projectType === 'non-billable'} // Auto-filled for non-billable
                    >
                      <option value="">Select Activity</option>
                      <option value="Meeting">Meeting</option>
                      <option value="Internal Discussion">Internal Discussion</option>
                      <option value="Discovery">Discovery</option>
                      <option value="PDD">PDD</option>
                      <option value="TDD">TDD</option>
                      <option value="Coding">Coding</option>
                      <option value="Code Review">Code Review</option>
                      <option value="Unit Testing">Unit Testing</option>
                      <option value="UAT">UAT</option>
                      <option value="Smoke testing">Smoke testing</option>
                      <option value="Go-Live">Go-Live</option>
                      <option value="Hyper Care">Hyper Care</option>
                      <option value="Project Kick-off">Project Kick-off</option>
                      <option value="Project Planning">Project Planning</option>
                      <option value="SOW">SOW</option>
                      <option value="RFP">RFP</option>
                      <option value="Weekly Decks">Weekly Decks</option>
                      <option value="Partner Visit">Partner Visit</option>
                      <option value="Training">Training</option>
                      <option value="DEMO">DEMO</option>
                      <option value="UAT Bug Fixing">UAT Bug Fixing</option>
                      <option value="HC Bug Fixing">HC Bug Fixing</option>
                      <option value="Integration Testing">Integration Testing</option>
                    </select>
                  </td>
                  {daysOfWeek.map(day => {
                    const dayKey = format(day, 'yyyy-MM-dd');
                    return (
                      <td key={dayKey}>
                        <input
                          type="number"
                          value={entry.hours[dayKey] || 0}
                          onChange={(e) => handleHourChange(entry.id, dayKey, e.target.value)}
                          min="0"
                          max="24"
                          step="0.5"
                          style={{ marginBottom: 0, width: '60px' }}
                        />
                      </td>
                    );
                  })}
                  <td><strong>{calculateRowTotal(entry).toFixed(2)}</strong></td>
                  <td>
                    <input
                      type="text"
                      value={entry.notes}
                      onChange={(e) => handleNotesChange(entry.id, e.target.value)}
                      placeholder="Notes"
                      style={{ marginBottom: 0, minWidth: '150px' }}
                    />
                  </td>
                  <td>
                    <button onClick={() => deleteRow(entry.id)} className="btn-danger">Delete</button>
                  </td>
                </tr>
              ))}
              <tr className="total-row">
                <td colSpan="3"><strong>Daily Totals</strong></td>
                {daysOfWeek.map(day => (
                  <td key={day.toString()}>
                    <strong>{calculateDayTotal(format(day, 'yyyy-MM-dd')).toFixed(2)}</strong>
                  </td>
                ))}
                <td>
                  <strong style={{ color: Math.abs(grandTotal - 42.5) > 2 ? 'red' : 'green' }}>
                    {grandTotal.toFixed(2)}
                  </strong>
                </td>
                <td colSpan="2"></td>
              </tr>
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: '20px', display: 'flex', gap: '10px' }}>
          <button onClick={addNewRow} className="btn-secondary">Add Row</button>
          <button onClick={validateAndSubmit} className="btn-success" disabled={submitting}>
            {submitting ? 'Submitting...' : 'Submit Timesheet'}
          </button>
        </div>

        {error && <div className="error" style={{ marginTop: '15px' }}>{error}</div>}
        {success && <div className="success" style={{ marginTop: '15px' }}>{success}</div>}
      </div>
    </div>
  );
};

export default Timesheet;