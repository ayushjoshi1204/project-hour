import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const EmployeeDashboard = () => {
  const { user } = useAuth();
  const [allocations, setAllocations] = useState([]);
  const [timesheets, setTimesheets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [allocRes, timesheetRes] = await Promise.all([
        axios.get(`/api/allocations/employee/${user.employeeId}`),
        axios.get('/api/timesheets/my-timesheets')
      ]);

      setAllocations(allocRes.data);
      setTimesheets(timesheetRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="container">
      <h1>Employee Dashboard</h1>
      
      <div className="card">
        <h2>My Allocations</h2>
        {allocations.length === 0 ? (
          <p>No allocations found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Project Code</th>
                <th>Entity</th>
                <th>Role</th>
                <th>Allocated Hours</th>
                <th>Billing Action</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {allocations.map((allocation) => (
                <tr key={allocation.allocationid}>
                  <td>{allocation.projectcode}</td>
                  <td>{allocation.entity}</td>
                  <td>{allocation.role}</td>
                  <td>{allocation.allocatedhours}</td>
                  <td>{allocation.billingaction}</td>
                  <td>{allocation.projectstatus}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2>My Timesheets</h2>
          <Link to="/employee/timesheet">
            <button className="btn-primary">Submit Timesheet</button>
          </Link>
        </div>
        {timesheets.length === 0 ? (
          <p>No timesheets submitted yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Week Start</th>
                <th>Week End</th>
                <th>Status</th>
                <th>Submitted At</th>
              </tr>
            </thead>
            <tbody>
              {timesheets.map((timesheet) => (
                <tr key={timesheet.timesheetid}>
                  <td>{new Date(timesheet.weekstartdate).toLocaleDateString()}</td>
                  <td>{new Date(timesheet.weekenddate).toLocaleDateString()}</td>
                  <td>
                    <span style={{ 
                      padding: '4px 8px', 
                      borderRadius: '4px',
                      backgroundColor: timesheet.status === 'submitted' ? '#d4edda' : '#fff3cd',
                      color: timesheet.status === 'submitted' ? '#155724' : '#856404'
                    }}>
                      {timesheet.status}
                    </span>
                  </td>
                  <td>{timesheet.submittedat ? new Date(timesheet.submittedat).toLocaleString() : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default EmployeeDashboard;
