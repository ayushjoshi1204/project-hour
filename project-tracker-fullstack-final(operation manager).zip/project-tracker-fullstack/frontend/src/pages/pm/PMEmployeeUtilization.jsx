import EmployeeUtilization from '../admin/EmployeeUtilization';

const PMEmployeeUtilization = () => <EmployeeUtilization />;

export default PMEmployeeUtilization;



