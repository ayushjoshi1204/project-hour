import Projects from '../admin/Projects';

const PMProjects = () => <Projects />;

export default PMProjects;
