import React, { useEffect, useState } from 'react';
import axios from 'axios';

const PMUtilization = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [empData, setEmpData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await axios.get('/api/pm/employees');
      setEmployees(res.data || []);
    } catch (err) {
      console.error('Failed to fetch employees', err);
      setError(err.response?.data?.error || 'Failed to fetch employees');
    } finally {
      setLoading(false);
    }
  };

  const handleEmployeeSelect = async (empId) => {
    setSelectedEmp(empId);
    try {
      setLoading(true);
      setError('');
      const res = await axios.get(`/api/pm/utilization/employee/${empId}`);
      setEmpData(res.data);
    } catch (err) {
      console.error('Failed to fetch utilization', err);
      setError(err.response?.data?.error || 'Failed to fetch utilization');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Employee Utilization</h1>

      <div className="card">
        <h2>Select Employee</h2>
        <div style={{ marginBottom: 16 }}>
          <select
            value={selectedEmp || ''}
            onChange={(e) => handleEmployeeSelect(e.target.value)}
            style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc', minWidth: '200px' }}
          >
            <option value="">-- Select an employee --</option>
            {employees.map(emp => (
              <option key={emp.employeeid} value={emp.employeeid}>
                {emp.name} ({emp.empid})
              </option>
            ))}
          </select>
        </div>

        {error && <div className="error">{error}</div>}

        {empData && (
          <div style={{ marginTop: 24 }}>
            <h3>{empData.name} - Utilization</h3>
            <div style={{ overflowX: 'auto', marginTop: 16 }}>
              <table>
                <thead>
                  <tr>
                    <th>Month</th>
                    <th>Logged Hours</th>
                    <th>Allocated Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.values(empData.monthlySeries || {}).map(month => (
                    <tr key={month.month}>
                      <td>{month.month}</td>
                      <td>{month.timesheetHours.toFixed(2)}</td>
                      <td>{month.allocatedHours.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PMUtilization;
