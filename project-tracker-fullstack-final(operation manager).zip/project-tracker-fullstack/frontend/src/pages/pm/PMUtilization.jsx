import Utilization from '../admin/Utilization';

const PMUtilization = () => (
  <Utilization
    allowedTabs={['employee']}
    title="Employee Utilization"
    employeeUtilizationBasePath="/pm"
  />
);

export default PMUtilization;
