import Employees from '../admin/Employees';

const PMEmployees = () => <Employees />;

export default PMEmployees;
