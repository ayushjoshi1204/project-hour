import Allocations from '../admin/Allocations';

const PMAllocations = () => <Allocations />;

export default PMAllocations;
