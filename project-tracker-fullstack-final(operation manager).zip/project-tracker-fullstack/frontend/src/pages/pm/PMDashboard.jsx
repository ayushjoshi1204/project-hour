import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const PMDashboard = () => {
  const [stats, setStats] = useState({
    employees: 0,
    projects: 0,
    allocations: 0,
    timesheets: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError('');

      // Use endpoints that PM can access
      const [empRes, projRes, allocRes, timesheetRes] = await Promise.all([
        axios.get('/api/employees'),
        axios.get('/api/projects'),
        axios.get('/api/allocations'),
        axios.get('/api/allocations'),
        // Fetch all timesheets for PM view
        axios.get('/api/timesheets/all')
      ]);

      setStats({
        employees: empRes.data?.length || 0,
        projects: projRes.data?.length || 0,
        allocations: allocRes.data?.length || 0,
        timesheets: timesheetRes.data?.length || 0,
      });

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const statCardStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    padding: '16px 18px',
    borderRadius: '16px',
    boxShadow: '0 6px 16px rgba(15, 23, 42, 0.08)',
    border: '1px solid rgba(148, 163, 184, 0.25)',
    background: 'linear-gradient(135deg, #ffffff 0%, #f9fafb 100%)',
  };

  const statLabelStyle = {
    fontSize: 12,
    fontWeight: 400,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    color: '#6b7280',
  };

  const statValueStyle = {
    fontSize: 28,
    fontWeight: 400,
    color: '#0f172a',
  };

  const statFooterStyle = {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 8,
  };

  return (
    <div className="container" style={{ paddingTop: 24, paddingBottom: 24 }}>
      {/* Hero */}
      <div style={{ marginBottom: 24 }}>
        <h1
          style={{
            fontSize: 26,
            fontWeight: 400,
            color: '#0f172a',
          }}
        >
          Project Manager Dashboard
        </h1>
      </div>

      {/* Timesheet Action Button */}
      <div style={{ marginBottom: 24 }}>
        <Link to="/employee/timesheet">
          <button className="btn-primary" style={{ marginRight: '12px' }}>
            Submit Your Timesheet
          </button>
        </Link>
        <Link to="/pm/timesheets">
          <button className="btn-secondary">
            View All Timesheets
          </button>
        </Link>

        {/* Refresh button */}
        <button
          onClick={fetchDashboardData}
          className="btn-secondary"
          style={{ marginLeft: '12px' }}
          disabled={loading}
        >
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      {error && (
        <div className="error" style={{ marginBottom: 16 }}>
          {error}
        </div>
      )}

      {loading && <div className="loading">Loading dashboard data...</div>}

      {/* Stat cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: 24,
          marginBottom: 32,
        }}
      >
        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Employees</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.employees}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#eff6ff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                👤
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total employees in system.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/pm/employees">
              <button className="btn-primary">View employees</button>
            </Link>
          </div>
        </div>

        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Projects</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.projects}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#ecfeff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                📁
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total projects in system.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/pm/projects">
              <button className="btn-secondary">View projects</button>
            </Link>
          </div>
        </div>

        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Allocations</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.allocations}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#fefce8',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                📊
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total employee allocations.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/pm/allocations">
              <button className="btn-secondary">View allocations</button>
            </Link>
          </div>
        </div>

        {/* Timesheets Card */}
        <div style={statCardStyle}>
          <div>
            <div style={statLabelStyle}>Timesheets</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 }}>
              <span style={statValueStyle}>{stats.timesheets}</span>
              <div
                style={{
                  height: 36,
                  width: 36,
                  borderRadius: 12,
                  background: '#f0fdf4',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                }}
              >
                📝
              </div>
            </div>
          </div>
          <div style={statFooterStyle}>Total submitted weekly timesheets.</div>
          <div style={{ marginTop: 12 }}>
            <Link to="/pm/timesheets">
              <button className="btn-primary">View timesheets</button>
            </Link>
          </div>
        </div>
      </div>

      {/* Debug info */}
      <div style={{
        marginTop: '20px',
        padding: '10px',
        backgroundColor: '#f8f9fa',
        borderRadius: '4px',
        fontSize: '12px',
        color: '#6c757d'
      }}>
        <strong>Current Stats:</strong> Employees: {stats.employees} | Projects: {stats.projects} | Allocations: {stats.allocations} | Timesheets: {stats.timesheets}
      </div>
    </div>
  );
};

export default PMDashboard;