import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const PMTimesheets = () => {
  const [timesheets, setTimesheets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchTimesheets = async () => {
      try {
        setLoading(true);
        setError('');
        const res = await axios.get('/api/timesheets/all');
        setTimesheets(res.data || []);
      } catch (err) {
        console.error('Failed to fetch timesheets', err);
        setError(err.response?.data?.error || 'Failed to fetch timesheets');
      } finally {
        setLoading(false);
      }
    };

    fetchTimesheets();
  }, []);

  return (
    <div className="container">
      <h1>Manage Timesheets</h1>

      <div style={{ marginBottom: 12 }}>
        <button
          onClick={() => navigate('/employee/timesheet')}
          className="btn-primary"
          title="Open your employee timesheet form"
        >
          Submit Your Timesheet
        </button>
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <h2>All Timesheets</h2>
            <p style={{ fontSize: 12, color: '#6b7280' }}>All submitted timesheets across employees.</p>
          </div>
        </div>

        {loading && <div className="loading">Loading timesheets...</div>}
        {error && <div className="error">{error}</div>}

        {!loading && !error && (
          timesheets.length === 0 ? (
            <p>No timesheets submitted yet.</p>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table>
                <thead>
                  <tr>
                    <th>Employee</th>
                    <th>EmpID</th>
                    <th>Week Start</th>
                    <th>Week End</th>
                    <th>Status</th>
                    <th>Submitted At</th>
                  </tr>
                </thead>
                <tbody>
                  {timesheets.map(ts => (
                    <tr key={ts.timesheetid}>
                      <td>{ts.employeename}</td>
                      <td>{ts.empid}</td>
                      <td>{ts.weekstartdate ? new Date(ts.weekstartdate).toLocaleDateString() : '-'}</td>
                      <td>{ts.weekenddate ? new Date(ts.weekenddate).toLocaleDateString() : '-'}</td>
                      <td>
                        <span style={{ 
                          padding: '4px 8px', 
                          borderRadius: '4px',
                          backgroundColor: ts.status === 'submitted' ? '#d4edda' : 
                                        ts.status === 'approved' ? '#d1ecf1' : 
                                        ts.status === 'rejected' ? '#f8d7da' : '#fff3cd',
                          color: ts.status === 'submitted' ? '#155724' : 
                                ts.status === 'approved' ? '#0c5460' : 
                                ts.status === 'rejected' ? '#721c24' : '#856404'
                        }}>
                          {ts.status}
                        </span>
                      </td>
                      <td>{ts.submittedat ? new Date(ts.submittedat).toLocaleString() : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </div>
  );
};

export default PMTimesheets;