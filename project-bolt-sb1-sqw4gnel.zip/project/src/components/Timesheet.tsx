import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Plus, Trash2, AlertCircle } from 'lucide-react';
import { api, Project, TimesheetEntry, ValidationError } from '../services/api';
import { getMonday, getSunday, formatDate, formatDisplayDate, getDayOfWeek, getWeekDates, addWeeks } from '../utils/dateUtils';

interface TimesheetRow {
  id: string;
  projectId: string;
  billingAction: string;
  activity: string;
  hours: number[];
  comments: string;
}

export default function Timesheet() {
  const [empId, setEmpId] = useState('');
  const [empName, setEmpName] = useState('');
  const [currentWeek, setCurrentWeek] = useState(getMonday(new Date()));
  const [projects, setProjects] = useState<Project[]>([]);
  const [rows, setRows] = useState<TimesheetRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationError[]>([]);
  const [successMessage, setSuccessMessage] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const weekDates = getWeekDates(currentWeek);
  const weekEnd = getSunday(currentWeek);

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    if (empId && empName) {
      loadTimesheetData();
    }
  }, [currentWeek, empId, empName]);

  const loadProjects = async () => {
    try {
      const data = await api.getProjects();
      setProjects(data);
    } catch (error) {
      console.error('Error loading projects:', error);
    }
  };

  const loadTimesheetData = async () => {
    try {
      const weekStart = formatDate(currentWeek);
      const weekEndDate = formatDate(weekEnd);
      const data = await api.getTimesheet(empId, weekStart, weekEndDate);

      if (data.length > 0) {
        setHasSubmitted(true);
        const groupedRows = new Map<string, TimesheetRow>();

        data.forEach(entry => {
          const key = `${entry.project_id}-${entry.activity}`;
          if (!groupedRows.has(key)) {
            const project = projects.find(p => p.project_id === entry.project_id);
            groupedRows.set(key, {
              id: key,
              projectId: entry.project_id,
              billingAction: project?.billing_action || '',
              activity: entry.activity,
              hours: [0, 0, 0, 0, 0, 0, 0],
              comments: entry.comments
            });
          }

          const row = groupedRows.get(key)!;
          const entryDate = new Date(entry.date);
          const dayIndex = weekDates.findIndex(d => formatDate(d) === formatDate(entryDate));
          if (dayIndex !== -1) {
            row.hours[dayIndex] = entry.hours;
          }
        });

        setRows(Array.from(groupedRows.values()));
      } else {
        setHasSubmitted(false);
        if (rows.length === 0) {
          addNewRow();
        }
      }
    } catch (error) {
      console.error('Error loading timesheet:', error);
      setHasSubmitted(false);
      if (rows.length === 0) {
        addNewRow();
      }
    }
  };

  const handleEmpIdBlur = async () => {
    if (!empId.trim()) return;

    try {
      setLoading(true);
      const employee = await api.getEmployee(empId.trim());
      if (employee) {
        setEmpName(employee.emp_name);
        setErrors([]);
      } else {
        setErrors([{ field: 'empId', message: 'Employee not found' }]);
        setEmpName('');
      }
    } catch (error) {
      console.error('Error fetching employee:', error);
      setErrors([{ field: 'empId', message: 'Error fetching employee data' }]);
    } finally {
      setLoading(false);
    }
  };

  const addNewRow = () => {
    const newRow: TimesheetRow = {
      id: `row-${Date.now()}`,
      projectId: '',
      billingAction: '',
      activity: '',
      hours: [0, 0, 0, 0, 0, 0, 0],
      comments: ''
    };
    setRows([...rows, newRow]);
  };

  const deleteRow = (rowId: string) => {
    setRows(rows.filter(row => row.id !== rowId));
  };

  const updateRow = (rowId: string, field: keyof TimesheetRow, value: any) => {
    setRows(rows.map(row => {
      if (row.id === rowId) {
        if (field === 'projectId') {
          const project = projects.find(p => p.project_id === value);
          return {
            ...row,
            projectId: value,
            billingAction: project?.billing_action || '',
            activity: project?.activity_default || ''
          };
        }
        return { ...row, [field]: value };
      }
      return row;
    }));
  };

  const updateHours = (rowId: string, dayIndex: number, value: string) => {
    const numValue = parseFloat(value) || 0;
    setRows(rows.map(row => {
      if (row.id === rowId) {
        const newHours = [...row.hours];
        newHours[dayIndex] = numValue;
        return { ...row, hours: newHours };
      }
      return row;
    }));
  };

  const calculateTotalHours = (): number => {
    return rows.reduce((total, row) => {
      return total + row.hours.reduce((sum, h) => sum + h, 0);
    }, 0);
  };

  const navigateWeek = (direction: number) => {
    setCurrentWeek(addWeeks(currentWeek, direction));
    setSuccessMessage('');
    setErrors([]);
  };

  const handleSubmit = async () => {
    if (!empId || !empName) {
      setErrors([{ field: 'general', message: 'Please enter a valid Employee ID' }]);
      return;
    }

    if (rows.length === 0 || rows.every(row => !row.projectId)) {
      setErrors([{ field: 'general', message: 'Please add at least one project entry' }]);
      return;
    }

    setLoading(true);
    setErrors([]);
    setSuccessMessage('');

    const entries: TimesheetEntry[] = [];
    const weekStart = formatDate(currentWeek);
    const weekEndDate = formatDate(weekEnd);

    rows.forEach(row => {
      if (row.projectId) {
        row.hours.forEach((hours, dayIndex) => {
          if (hours > 0) {
            entries.push({
              emp_id: empId,
              project_id: row.projectId,
              activity: row.activity,
              date: formatDate(weekDates[dayIndex]),
              hours: hours,
              comments: row.comments,
              week_start: weekStart,
              week_end: weekEndDate
            });
          }
        });
      }
    });

    try {
      const result = await api.validateAndSubmitTimesheet(entries);
      if (result.success) {
        setSuccessMessage('Timesheet submitted successfully!');
        setHasSubmitted(true);
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        setErrors(result.errors);
      }
    } catch (error) {
      console.error('Error submitting timesheet:', error);
      setErrors([{ field: 'general', message: 'Error submitting timesheet' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this timesheet? This action cannot be undone.')) {
      return;
    }

    setLoading(true);
    try {
      const weekStart = formatDate(currentWeek);
      const weekEndDate = formatDate(weekEnd);
      await api.deleteTimesheet(empId, weekStart, weekEndDate);
      setRows([]);
      addNewRow();
      setHasSubmitted(false);
      setSuccessMessage('Timesheet deleted successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      console.error('Error deleting timesheet:', error);
      setErrors([{ field: 'general', message: 'Error deleting timesheet' }]);
    } finally {
      setLoading(false);
    }
  };

  const totalHours = calculateTotalHours();
  const totalHoursColor = Math.abs(totalHours - 42.5) < 0.01 ? 'text-green-600' : 'text-red-600';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Timesheet Tracker</h1>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Employee ID
              </label>
              <input
                type="text"
                value={empId}
                onChange={(e) => setEmpId(e.target.value.toUpperCase())}
                onBlur={handleEmpIdBlur}
                disabled={loading || hasSubmitted}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 disabled:bg-gray-200"
                placeholder="Enter Employee ID"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Employee Name
              </label>
              <input
                type="text"
                value={empName}
                readOnly
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-700"
                placeholder="Auto-populated"
              />
            </div>
          </div>

          <div className="flex items-center justify-between border-t pt-6">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigateWeek(-1)}
                disabled={loading}
                className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition disabled:opacity-50"
              >
                <ChevronLeft size={20} />
              </button>

              <div className="text-center">
                <div className="text-sm text-gray-600">Week Of</div>
                <div className="font-semibold text-gray-800">
                  {formatDisplayDate(currentWeek)} → {formatDisplayDate(weekEnd)}
                </div>
              </div>

              <button
                onClick={() => navigateWeek(1)}
                disabled={loading}
                className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition disabled:opacity-50"
              >
                <ChevronRight size={20} />
              </button>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm text-gray-600">Total Hours</div>
                <div className={`text-2xl font-bold ${totalHoursColor}`}>
                  {totalHours.toFixed(2)}
                </div>
              </div>

              {hasSubmitted ? (
                <button
                  onClick={handleDelete}
                  disabled={loading}
                  className="px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition font-medium disabled:opacity-50"
                >
                  Delete Timesheet
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={loading || !empName}
                  className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition font-medium disabled:opacity-50"
                >
                  {loading ? 'Submitting...' : 'Submit'}
                </button>
              )}
            </div>
          </div>
        </div>

        {errors.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-start">
              <AlertCircle className="text-red-500 mr-3 mt-0.5" size={20} />
              <div className="flex-1">
                <h3 className="font-semibold text-red-800 mb-2">Validation Errors</h3>
                <ul className="list-disc list-inside space-y-1">
                  {errors.map((error, index) => (
                    <li key={index} className="text-red-700 text-sm">{error.message}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {successMessage && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <div className="text-green-800 font-medium">{successMessage}</div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-md overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-green-100">
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 w-12"></th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 min-w-[150px]">Project ID</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 min-w-[150px]">Billing Action</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 min-w-[150px]">Activity</th>
                {weekDates.map((date, index) => (
                  <th key={index} className="px-4 py-3 text-center text-sm font-semibold text-gray-700 w-24">
                    <div>{getDayOfWeek(date)}</div>
                    <div className="text-xs font-normal">{date.getDate()}</div>
                  </th>
                ))}
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 min-w-[200px]">Comments</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, rowIndex) => (
                <tr key={row.id} className={rowIndex % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  <td className="px-4 py-2">
                    <button
                      onClick={() => deleteRow(row.id)}
                      disabled={hasSubmitted}
                      className="text-red-500 hover:text-red-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                  <td className="px-4 py-2">
                    <select
                      value={row.projectId}
                      onChange={(e) => updateRow(row.id, 'projectId', e.target.value)}
                      disabled={hasSubmitted}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm disabled:bg-gray-200"
                    >
                      <option value="">Select Project</option>
                      {projects.map(project => (
                        <option key={project.project_id} value={project.project_id}>
                          {project.project_id}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={row.billingAction}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-sm text-gray-700"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={row.activity}
                      onChange={(e) => updateRow(row.id, 'activity', e.target.value)}
                      disabled={hasSubmitted}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm disabled:bg-gray-200"
                      placeholder="Enter activity"
                    />
                  </td>
                  {row.hours.map((hours, dayIndex) => (
                    <td key={dayIndex} className="px-4 py-2">
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        value={hours || ''}
                        onChange={(e) => updateHours(row.id, dayIndex, e.target.value)}
                        disabled={hasSubmitted}
                        className="w-full px-2 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-center disabled:bg-gray-200"
                      />
                    </td>
                  ))}
                  <td className="px-4 py-2">
                    <input
                      type="text"
                      value={row.comments}
                      onChange={(e) => updateRow(row.id, 'comments', e.target.value)}
                      disabled={hasSubmitted}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm disabled:bg-gray-200"
                      placeholder="Add comments"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {!hasSubmitted && (
            <div className="p-4 border-t">
              <button
                onClick={addNewRow}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition font-medium"
              >
                <Plus size={18} />
                <span>Add Row</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
