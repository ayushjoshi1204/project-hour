import { supabase } from '../lib/supabase';

export interface Employee {
  emp_id: string;
  emp_name: string;
}

export interface Project {
  project_id: string;
  billing_action: string;
  activity_default: string;
  start_date: string;
  end_date: string;
  allocated_hours: number;
}

export interface TimesheetEntry {
  id?: string;
  emp_id: string;
  project_id: string;
  activity: string;
  date: string;
  hours: number;
  comments: string;
  week_start: string;
  week_end: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export const api = {
  async getEmployee(empId: string): Promise<Employee | null> {
    const { data, error } = await supabase
      .from('employees')
      .select('emp_id, emp_name')
      .eq('emp_id', empId)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getProjects(): Promise<Project[]> {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('project_id');

    if (error) throw error;
    return data || [];
  },

  async getTimesheet(empId: string, weekStart: string, weekEnd: string): Promise<TimesheetEntry[]> {
    const { data, error } = await supabase
      .from('timesheet')
      .select('*')
      .eq('emp_id', empId)
      .eq('week_start', weekStart)
      .eq('week_end', weekEnd)
      .order('created_at');

    if (error) throw error;
    return data || [];
  },

  async validateAndSubmitTimesheet(entries: TimesheetEntry[]): Promise<{ success: boolean; errors: ValidationError[] }> {
    const errors: ValidationError[] = [];

    if (entries.length === 0) {
      errors.push({ field: 'general', message: 'No timesheet entries to submit' });
      return { success: false, errors };
    }

    const empId = entries[0].emp_id;
    const weekStart = entries[0].week_start;
    const weekEnd = entries[0].week_end;

    const projectsData = await this.getProjects();
    const projects = new Map(projectsData.map(p => [p.project_id, p]));

    const duplicateCheck = new Map<string, boolean>();
    for (const entry of entries) {
      const key = `${entry.project_id}-${entry.activity}`;
      if (duplicateCheck.has(key)) {
        errors.push({
          field: 'duplicate',
          message: `Duplicate Project-Activity combination found: ${entry.project_id} - ${entry.activity}`
        });
      }
      duplicateCheck.set(key, true);
    }

    let totalHours = 0;
    const projectHours = new Map<string, number>();

    for (const entry of entries) {
      totalHours += entry.hours;
      projectHours.set(
        entry.project_id,
        (projectHours.get(entry.project_id) || 0) + entry.hours
      );
    }

    if (Math.abs(totalHours - 42.5) > 0.01) {
      errors.push({
        field: 'totalHours',
        message: `Total weekly hours must be exactly 42.5. Current total: ${totalHours.toFixed(2)}`
      });
    }

    for (const [projectId, hours] of projectHours.entries()) {
      const project = projects.get(projectId);
      if (project && hours > project.allocated_hours) {
        errors.push({
          field: 'allocatedHours',
          message: `Exceeded allocated hours for Project ${projectId}. Allocated: ${project.allocated_hours}, Used: ${hours}`
        });
      }
    }

    for (const entry of entries) {
      const project = projects.get(entry.project_id);
      if (project) {
        const entryDate = new Date(entry.date);
        const projectStart = new Date(project.start_date);
        const projectEnd = new Date(project.end_date);

        if (entryDate < projectStart || entryDate > projectEnd) {
          errors.push({
            field: 'dateWindow',
            message: `Project ${entry.project_id} date ${entry.date} is outside valid window (${project.start_date} to ${project.end_date})`
          });
        }
      }
    }

    const existingData = await this.getTimesheet(empId, weekStart, weekEnd);
    if (existingData.length > 0) {
      errors.push({
        field: 'duplicate',
        message: 'You have already submitted a timesheet for this week. Please delete existing entries first.'
      });
    }

    if (errors.length > 0) {
      return { success: false, errors };
    }

    const { error } = await supabase
      .from('timesheet')
      .insert(entries);

    if (error) {
      return {
        success: false,
        errors: [{ field: 'general', message: error.message }]
      };
    }

    return { success: true, errors: [] };
  },

  async deleteTimesheet(empId: string, weekStart: string, weekEnd: string): Promise<void> {
    const { error } = await supabase
      .from('timesheet')
      .delete()
      .eq('emp_id', empId)
      .eq('week_start', weekStart)
      .eq('week_end', weekEnd);

    if (error) throw error;
  }
};
