/*
  # Timesheet Tracker Database Schema

  1. New Tables
    - `employees`
      - `emp_id` (text, primary key) - Employee ID
      - `emp_name` (text, not null) - Employee name
      - `created_at` (timestamp) - Record creation time
    
    - `projects`
      - `project_id` (text, primary key) - Project ID
      - `billing_action` (text, not null) - Billing action type
      - `activity_default` (text) - Default activity name
      - `start_date` (date, not null) - Project start date
      - `end_date` (date, not null) - Project end date
      - `allocated_hours` (numeric, not null) - Total allocated hours for project
      - `created_at` (timestamp) - Record creation time
    
    - `timesheet`
      - `id` (uuid, primary key) - Unique record ID
      - `emp_id` (text, foreign key) - Employee ID reference
      - `project_id` (text, foreign key) - Project ID reference
      - `activity` (text, not null) - Activity/task description
      - `date` (date, not null) - Date of work
      - `hours` (numeric, not null) - Hours worked
      - `comments` (text) - Additional comments
      - `week_start` (date, not null) - Week start date (Monday)
      - `week_end` (date, not null) - Week end date (Sunday)
      - `created_at` (timestamp) - Record creation time
      - `updated_at` (timestamp) - Last update time

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own timesheet data
    - Add policies for reading employee and project data

  3. Indexes
    - Index on emp_id for faster employee lookups
    - Composite index on (emp_id, week_start, week_end) for timesheet queries
    - Index on project_id for project lookups
*/

CREATE TABLE IF NOT EXISTS employees (
  emp_id text PRIMARY KEY,
  emp_name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS projects (
  project_id text PRIMARY KEY,
  billing_action text NOT NULL,
  activity_default text DEFAULT '',
  start_date date NOT NULL,
  end_date date NOT NULL,
  allocated_hours numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS timesheet (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  emp_id text NOT NULL REFERENCES employees(emp_id),
  project_id text NOT NULL REFERENCES projects(project_id),
  activity text NOT NULL,
  date date NOT NULL,
  hours numeric NOT NULL DEFAULT 0,
  comments text DEFAULT '',
  week_start date NOT NULL,
  week_end date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE timesheet ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read employees"
  ON employees FOR SELECT
  USING (true);

CREATE POLICY "Anyone can read projects"
  ON projects FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view all timesheets"
  ON timesheet FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert timesheets"
  ON timesheet FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update timesheets"
  ON timesheet FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete timesheets"
  ON timesheet FOR DELETE
  USING (true);

CREATE INDEX IF NOT EXISTS idx_timesheet_emp_id ON timesheet(emp_id);
CREATE INDEX IF NOT EXISTS idx_timesheet_week ON timesheet(emp_id, week_start, week_end);
CREATE INDEX IF NOT EXISTS idx_timesheet_project ON timesheet(project_id);

INSERT INTO employees (emp_id, emp_name) VALUES
  ('EMP001', 'John Smith'),
  ('EMP002', 'Sarah Johnson'),
  ('EMP003', 'Michael Brown')
ON CONFLICT (emp_id) DO NOTHING;

INSERT INTO projects (project_id, billing_action, activity_default, start_date, end_date, allocated_hours) VALUES
  ('PRJ001', 'Billable', 'Development', '2025-01-01', '2025-12-31', 1000),
  ('PRJ002', 'Non-Billable', 'Internal Tool Development', '2025-01-01', '2025-06-30', 500),
  ('PRJ003', 'Billable', 'Client Support', '2025-02-01', '2025-11-30', 800),
  ('PRJ004', 'Billable', 'Feature Implementation', '2025-03-01', '2025-09-30', 600)
ON CONFLICT (project_id) DO NOTHING;
