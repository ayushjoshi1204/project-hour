-- Add PM role support to existing database while preserving all data
-- This migration updates the Role column constraint to include 'pm'

BEGIN;

-- Step 1: Drop the old constraint (if it exists)
-- Try the inline constraint first
ALTER TABLE Employees
  DROP CONSTRAINT IF EXISTS employees_role_check;

-- Step 2: Create a new constraint that includes 'pm' role
ALTER TABLE Employees
  ADD CONSTRAINT employees_role_check CHECK (Role IN ('admin', 'employee', 'pm'));

-- Step 3: Verify the constraint was added
-- SELECT * FROM information_schema.table_constraints 
-- WHERE table_name = 'employees' AND constraint_type = 'CHECK';

COMMIT;

-- After this migration, all existing data is preserved and you can now:
-- 1. Create new employees with role='pm'
-- 2. Update existing employees to role='pm'
-- 3. The PM role will work in the application
