import pool from '../config/db.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function initializeDatabase() {
  try {
    console.log('Initializing database...');

    // Read and execute schema
    const schemaPath = path.join(__dirname, 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    await pool.query(schema);
    console.log('Schema created successfully');

    // Seed data
    console.log('Seeding data...');

    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      ['EMP001', 'Admin User', 'admin@projecttracker.com', hashedPassword, 'admin', '2024-01-01', 'active']
    );

    // Create sample employee
    const empPassword = await bcrypt.hash('emp123', 10);
    await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      ['EMP002', 'John Doe', 'john@projecttracker.com', empPassword, 'employee', '2024-02-01', 'active']
    );

    // Create sample PM user
    const pmPassword = await bcrypt.hash('pm123', 10);
    await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      ['EMP003', 'Peter PM', 'peter@projecttracker.com', pmPassword, 'pm', '2024-03-01', 'active']
    );

    console.log('Sample users created:');
    console.log('  Admin - Email: admin@projecttracker.com, Password: admin123');
    console.log('  Employee - Email: john@projecttracker.com, Password: emp123');
    console.log('  PM - Email: peter@projecttracker.com, Password: pm123');

    // Create sample projects
    await pool.query(
      `INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      ['PROJ001', 'Client A', 'Time & Material', '2024-01-01', '2024-12-31', 'active']
    );

    await pool.query(
      `INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      ['PROJ002', 'Client B', 'Fixed Price', '2024-03-01', '2024-09-30', 'active']
    );

    console.log('Sample projects created');

    // Create sample allocation
    await pool.query(
      `INSERT INTO Allocations (EmployeeID, ProjectID, EmpName, Role, AllocatedHours) 
       VALUES ($1, $2, $3, $4, $5)`,
      [2, 1, 'John Doe', 'Developer', 160]
    );

    console.log('Sample allocation created');

    console.log('Database initialization completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

initializeDatabase();
