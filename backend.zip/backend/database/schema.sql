-- Project Tracker Database Schema

-- Drop tables if they exist (in reverse order of dependencies)
DROP TABLE IF EXISTS TimesheetEntries CASCADE;
DROP TABLE IF EXISTS Timesheets CASCADE;
DROP TABLE IF EXISTS Allocations CASCADE;
DROP TABLE IF EXISTS Projects CASCADE;
DROP TABLE IF EXISTS Employees CASCADE;

-- Employees Table
CREATE TABLE Employees (
    EmployeeID SERIAL PRIMARY KEY,
    EmpID VARCHAR(50) UNIQUE NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('admin', 'employee', 'pm')),
    DOJ DATE NOT NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (Status IN ('active', 'inactive')),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Projects Table
CREATE TABLE Projects (
    ProjectID SERIAL PRIMARY KEY,
    ProjectCode VARCHAR(50) UNIQUE NOT NULL,
    Entity VARCHAR(255) NOT NULL,
    BillingAction VARCHAR(255) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (Status IN ('active', 'inactive', 'completed')),
    Tribe VARCHAR(64) CHECK (Tribe IN ('UKI','Non-UKI')),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_dates CHECK (EndDate >= StartDate)
);

-- Allocations Table
CREATE TABLE Allocations (
    AllocationID SERIAL PRIMARY KEY,
    EmployeeID INTEGER NOT NULL REFERENCES Employees(EmployeeID) ON DELETE CASCADE,
    ProjectID INTEGER NOT NULL REFERENCES Projects(ProjectID) ON DELETE CASCADE,
    EmpName VARCHAR(255) NOT NULL,
    Role VARCHAR(255) NOT NULL,
    AllocatedHours DECIMAL(10, 2) NOT NULL CHECK (AllocatedHours >= 0),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(EmployeeID, ProjectID)
);

-- Timesheets Table
CREATE TABLE Timesheets (
    TimesheetID SERIAL PRIMARY KEY,
    EmployeeID INTEGER NOT NULL REFERENCES Employees(EmployeeID) ON DELETE CASCADE,
    WeekStartDate DATE NOT NULL,
    WeekEndDate DATE NOT NULL,
    Status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (Status IN ('draft', 'submitted')),
    SubmittedAt TIMESTAMP,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_week_dates CHECK (WeekEndDate >= WeekStartDate),
    UNIQUE(EmployeeID, WeekStartDate)
);

-- TimesheetEntries Table
CREATE TABLE TimesheetEntries (
    EntryID SERIAL PRIMARY KEY,
    TimesheetID INTEGER NOT NULL REFERENCES Timesheets(TimesheetID) ON DELETE CASCADE,
    AllocationID INTEGER NOT NULL REFERENCES Allocations(AllocationID) ON DELETE CASCADE,
    EntryDate DATE NOT NULL,
    Hours DECIMAL(10, 2) NOT NULL CHECK (Hours >= 0 AND Hours <= 24),
    Notes TEXT,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_employees_empid ON Employees(EmpID);
CREATE INDEX idx_employees_email ON Employees(Email);
CREATE INDEX idx_projects_code ON Projects(ProjectCode);
CREATE INDEX idx_allocations_employee ON Allocations(EmployeeID);
CREATE INDEX idx_allocations_project ON Allocations(ProjectID);
CREATE INDEX idx_timesheets_employee ON Timesheets(EmployeeID);
CREATE INDEX idx_timesheets_dates ON Timesheets(WeekStartDate, WeekEndDate);
CREATE INDEX idx_timesheet_entries_timesheet ON TimesheetEntries(TimesheetID);
CREATE INDEX idx_timesheet_entries_allocation ON TimesheetEntries(AllocationID);

-- Function to update UpdatedAt timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.UpdatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for UpdatedAt
CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON Employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON Projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_allocations_updated_at BEFORE UPDATE ON Allocations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_timesheets_updated_at BEFORE UPDATE ON Timesheets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_timesheet_entries_updated_at BEFORE UPDATE ON TimesheetEntries
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
