import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from '../config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runFile(filePath) {
  const abs = path.isAbsolute(filePath) ? filePath : path.join(__dirname, '..', filePath);
  const sql = fs.readFileSync(abs, 'utf-8');
  console.log('Executing SQL file:', abs);
  await pool.query(sql);
  console.log('Done');
}

const file = process.argv[2];
if (!file) {
  console.error('Usage: node database/runSql.js <relative-or-absolute-sql-file-path>');
  process.exit(1);
}

runFile(file).then(() => process.exit(0)).catch(err => { console.error(err); process.exit(1); });