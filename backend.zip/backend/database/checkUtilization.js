import pool from '../config/db.js';

async function main() {
  try {
    const q = `
      SELECT a.AllocationID, e.Name, p.ProjectCode,
             a.AllocatedHours, COALESCE(SUM(te.Hours),0) AS logged
      FROM Allocations a
      JOIN Employees e ON e.EmployeeID = a.EmployeeID
      JOIN Projects p ON p.ProjectID = a.ProjectID
      LEFT JOIN TimesheetEntries te ON te.AllocationID = a.AllocationID
      GROUP BY a.AllocationID, e.Name, p.ProjectCode, a.AllocatedHours
      HAVING COALESCE(SUM(te.Hours),0) > a.AllocatedHours
    `;
    const { rows } = await pool.query(q);
    if (rows.length === 0) {
      console.log('OK: All allocations have logged <= allocated hours');
    } else {
      console.log('VIOLATIONS:');
      for (const r of rows) {
        console.log(`${r.projectcode} ${r.name} alloc=${r.allocatedhours} logged=${r.logged}`);
      }
    }
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

main();
