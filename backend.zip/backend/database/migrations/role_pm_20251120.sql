-- Add Project Manager role support
-- This migration updates the Role column constraint to include 'pm'

-- Drop existing constraint
ALTER TABLE Employees
  DROP CONSTRAINT employees_role_check;

-- Add new constraint with 'pm' role included
ALTER TABLE Employees
  ADD CONSTRAINT employees_role_check CHECK (Role IN ('admin', 'employee', 'pm'));
