-- Utilization Dashboard migration - add columns and indexes
ALTER TABLE Employees
  ADD COLUMN IF NOT EXISTS Tribe VARCHAR(64),
  ADD COLUMN IF NOT EXISTS Team VARCHAR(64),
  ADD COLUMN IF NOT EXISTS WorkHoursPerWeek NUMERIC(5,2) DEFAULT 42.5;

-- Optional enums
DO $$ BEGIN
  ALTER TABLE Employees ADD CONSTRAINT employees_tribe_chk CHECK (Tribe IN ('UKI','Non-UKI'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE Employees ADD CONSTRAINT employees_team_chk CHECK (Team IN ('PM','SA','BA','Developer','Tribe Lead'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Composite indexes to support queries
CREATE INDEX IF NOT EXISTS idx_allocations_emp_proj ON Allocations(EmployeeID, ProjectID);
CREATE INDEX IF NOT EXISTS idx_tse_alloc_date ON TimesheetEntries(AllocationID, EntryDate);
-- Unique already exists on Timesheets(EmployeeID, WeekStartDate)

-- Helper function for working days (optional if computed app-side)
CREATE OR REPLACE FUNCTION working_days(start_date date, end_date date)
RETURNS integer LANGUAGE sql IMMUTABLE AS $$
  SELECT COUNT(*)::int
  FROM generate_series(start_date, end_date, interval '1 day') d(day)
  WHERE EXTRACT(ISODOW FROM d.day) < 6;
$$;