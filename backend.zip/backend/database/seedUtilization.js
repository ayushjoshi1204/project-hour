import pool from '../config/db.js';
import bcrypt from 'bcrypt';

function firstDayOfMonth(year, month) { // month 1-12
  return new Date(Date.UTC(year, month - 1, 1));
}
function lastDayOfMonth(year, month) {
  const d = new Date(Date.UTC(year, month, 0));
  return d; // end of month
}
function toISO(d) { return new Date(d).toISOString().slice(0,10); }
function addDays(d, n) { const x = new Date(d); x.setUTCDate(x.getUTCDate()+n); return x; }
function startOfWeekMonday(d) {
  const day = d.getUTCDay(); // 0 Sun .. 6 Sat
  const diff = (day === 0 ? -6 : 1 - day);
  return addDays(d, diff);
}

async function getOrCreateEmployee({ EmpID, Name, Email, Team, Tribe, WorkHoursPerWeek = 42.5 }) {
  const hashed = await bcrypt.hash('test123', 10);
  const { rows } = await pool.query(
    `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status, Team, Tribe, WorkHoursPerWeek)
     VALUES ($1,$2,$3,$4,'employee','2024-01-01','active',$5,$6,$7)
     ON CONFLICT (EmpID) DO UPDATE SET Team = EXCLUDED.Team, Tribe = EXCLUDED.Tribe, WorkHoursPerWeek = EXCLUDED.WorkHoursPerWeek
     RETURNING EmployeeID`,
    [EmpID, Name, Email, hashed, Team, Tribe, WorkHoursPerWeek]
  );
  return rows[0].employeeid;
}

async function getOrCreateProject({ ProjectCode, Entity, BillingAction, StartDate, EndDate }) {
  const { rows } = await pool.query(
    `INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status)
     VALUES ($1,$2,$3,$4,$5,'active')
     ON CONFLICT (ProjectCode) DO UPDATE SET StartDate = EXCLUDED.StartDate, EndDate = EXCLUDED.EndDate
     RETURNING ProjectID`,
    [ProjectCode, Entity, BillingAction, StartDate, EndDate]
  );
  return rows[0].projectid;
}

async function getOrCreateAllocation({ EmployeeID, ProjectID, EmpName, Role, AllocatedHours }) {
  const { rows } = await pool.query(
    `INSERT INTO Allocations (EmployeeID, ProjectID, EmpName, Role, AllocatedHours)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (EmployeeID, ProjectID) DO UPDATE SET AllocatedHours = EXCLUDED.AllocatedHours
     RETURNING AllocationID`,
    [EmployeeID, ProjectID, EmpName, Role, AllocatedHours]
  );
  return rows[0].allocationid;
}

async function getOrCreateTimesheet({ EmployeeID, WeekStartDate, WeekEndDate }) {
  const { rows } = await pool.query(
    `INSERT INTO Timesheets (EmployeeID, WeekStartDate, WeekEndDate, Status)
     VALUES ($1,$2,$3,'submitted')
     ON CONFLICT (EmployeeID, WeekStartDate) DO UPDATE SET WeekEndDate = EXCLUDED.WeekEndDate
     RETURNING TimesheetID`,
    [EmployeeID, WeekStartDate, WeekEndDate]
  );
  return rows[0].timesheetid;
}

async function addEntry({ TimesheetID, AllocationID, EntryDate, Hours, Notes = null }) {
  await pool.query(
    `INSERT INTO TimesheetEntries (TimesheetID, AllocationID, EntryDate, Hours, Notes)
     VALUES ($1,$2,$3,$4,$5)`,
    [TimesheetID, AllocationID, EntryDate, Hours, Notes]
  );
}

async function seed() {
  console.log('Seeding utilization sample data...');
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = now.getUTCMonth() + 1; // 1-12
  const mStart = firstDayOfMonth(year, month);
  const mEnd = lastDayOfMonth(year, month);
  const monthStartISO = toISO(mStart);
  const monthEndISO = toISO(mEnd);

  // Cleanup current-month seed data for demo projects to avoid accumulation
  await pool.query(`
    DELETE FROM timesheetentries te
    USING allocations a, projects p
    WHERE te.allocationid = a.allocationid
      AND a.projectid = p.projectid
      AND p.projectcode IN ('PROJ001','PROJ002','PROJ003','PROJ004')
      AND te.entrydate >= $1::date AND te.entrydate <= $2::date
  `, [monthStartISO, monthEndISO]);

  // Employees across teams for UKI
  const uki = [
    { EmpID: 'UKI-TL-001', Name: 'Uma TribeLead', Email: 'uma.tl@demo.local', Team: 'Tribe Lead', Tribe: 'UKI' },
    { EmpID: 'UKI-PM-001', Name: 'Peter PM', Email: 'peter.pm@demo.local', Team: 'PM', Tribe: 'UKI' },
    { EmpID: 'UKI-SA-001', Name: 'Sara SA', Email: 'sara.sa@demo.local', Team: 'SA', Tribe: 'UKI' },
    { EmpID: 'UKI-BA-001', Name: 'Bella BA', Email: 'bella.ba@demo.local', Team: 'BA', Tribe: 'UKI' },
    { EmpID: 'UKI-DEV-001', Name: 'Devon Dev1', Email: 'devon.dev1@demo.local', Team: 'Developer', Tribe: 'UKI' },
    { EmpID: 'UKI-DEV-002', Name: 'Diana Dev2', Email: 'diana.dev2@demo.local', Team: 'Developer', Tribe: 'UKI' },
  ];
  // Employees across teams for Non-UKI
  const nonUki = [
    { EmpID: 'NUKI-TL-001', Name: 'Nina TribeLead', Email: 'nina.tl@demo.local', Team: 'Tribe Lead', Tribe: 'Non-UKI' },
    { EmpID: 'NUKI-PM-001', Name: 'Noah PM', Email: 'noah.pm@demo.local', Team: 'PM', Tribe: 'Non-UKI' },
    { EmpID: 'NUKI-SA-001', Name: 'Neil SA', Email: 'neil.sa@demo.local', Team: 'SA', Tribe: 'Non-UKI' },
    { EmpID: 'NUKI-BA-001', Name: 'Nora BA', Email: 'nora.ba@demo.local', Team: 'BA', Tribe: 'Non-UKI' },
    { EmpID: 'NUKI-DEV-001', Name: 'Nate Dev', Email: 'nate.dev@demo.local', Team: 'Developer', Tribe: 'Non-UKI' },
  ];

  const all = [...uki, ...nonUki];
  const empMap = new Map();
  for (const e of all) {
    const id = await getOrCreateEmployee(e);
    empMap.set(e.EmpID, { ...e, EmployeeID: id });
  }

  // Projects that span the current month
  const projUKI = await getOrCreateProject({
    ProjectCode: 'PROJ001', Entity: 'Client A', BillingAction: 'Time & Material', StartDate: monthStartISO, EndDate: monthEndISO,
  });
  const projUKI2 = await getOrCreateProject({
    ProjectCode: 'PROJ003', Entity: 'Client C', BillingAction: 'Time & Material', StartDate: monthStartISO, EndDate: monthEndISO,
  });
  const projNUKI = await getOrCreateProject({
    ProjectCode: 'PROJ002', Entity: 'Client B', BillingAction: 'Fixed Price', StartDate: monthStartISO, EndDate: monthEndISO,
  });
  const projNUKI2 = await getOrCreateProject({
    ProjectCode: 'PROJ004', Entity: 'Client D', BillingAction: 'Fixed Price', StartDate: monthStartISO, EndDate: monthEndISO,
  });

  // Allocations (sum in hours for the month)
  const allocations = [];
  const allocByEmp = new Map();
  for (const e of uki) {
    const emp = empMap.get(e.EmpID);
    const a1 = await getOrCreateAllocation({
      EmployeeID: emp.EmployeeID,
      ProjectID: projUKI,
      EmpName: e.Name,
      Role: e.Team,
      AllocatedHours: e.Team === 'Developer' ? 80 : 60,
    });
    const a2 = await getOrCreateAllocation({
      EmployeeID: emp.EmployeeID,
      ProjectID: projUKI2,
      EmpName: e.Name,
      Role: e.Team,
      AllocatedHours: e.Team === 'Developer' ? 60 : 40,
    });
    allocations.push({ emp, AllocationID: a1, ProjectID: projUKI, AllocatedHours: (e.Team === 'Developer' ? 80 : 60) });
    allocations.push({ emp, AllocationID: a2, ProjectID: projUKI2, AllocatedHours: (e.Team === 'Developer' ? 60 : 40) });
    allocByEmp.set(emp.EmployeeID, (allocByEmp.get(emp.EmployeeID) || []).concat([a1, a2]));
  }
  for (const e of nonUki) {
    const emp = empMap.get(e.EmpID);
    const a1 = await getOrCreateAllocation({
      EmployeeID: emp.EmployeeID,
      ProjectID: projNUKI,
      EmpName: e.Name,
      Role: e.Team,
      AllocatedHours: e.Team === 'Developer' ? 70 : 50,
    });
    const a2 = await getOrCreateAllocation({
      EmployeeID: emp.EmployeeID,
      ProjectID: projNUKI2,
      EmpName: e.Name,
      Role: e.Team,
      AllocatedHours: e.Team === 'Developer' ? 40 : 30,
    });
    allocations.push({ emp, AllocationID: a1, ProjectID: projNUKI, AllocatedHours: (e.Team === 'Developer' ? 70 : 50) });
    allocations.push({ emp, AllocationID: a2, ProjectID: projNUKI2, AllocatedHours: (e.Team === 'Developer' ? 40 : 30) });
    allocByEmp.set(emp.EmployeeID, (allocByEmp.get(emp.EmployeeID) || []).concat([a1, a2]));
  }

  // Create 3 weeks of timesheets within the current month (Mon-Fri entries), split hours across allocations when 2 exist
  const firstMonday = startOfWeekMonday(mStart);
  const weeks = 2; // ensure totals remain under allocation caps
  for (const e of all) {
    const emp = empMap.get(e.EmpID);
    const empAllocs = allocations.filter(a => a.emp.EmployeeID === emp.EmployeeID);
    const dailyTotal = e.Team === 'Developer' ? 7.5 : 6.0;

    // Precompute safe split for 2 allocations to keep monthly totals < allocated
    let r = 0.5; // portion for first allocation
    if (empAllocs.length >= 2) {
      const a1 = empAllocs[0];
      const a2 = empAllocs[1];
      const workDays = 5 * weeks;
      const T = dailyTotal * workDays;
      const capFrac = 0.95; // 95% of allocation as safety margin
      const cap1 = (a1.AllocatedHours || 0) * capFrac;
      const cap2 = (a2.AllocatedHours || 0) * capFrac;
      const rLow = Math.max(0, 1 - (cap2 / (T || 1)));
      const rHigh = Math.min(1, (cap1 / (T || 1)));
      const rProp = (a1.AllocatedHours || 0) / Math.max(1, (a1.AllocatedHours || 0) + (a2.AllocatedHours || 0));
      r = Math.min(Math.max(rProp, rLow), rHigh);
      if (rLow > rHigh) {
        // fallback: center between bounds
        r = Math.min(Math.max(0.5, rLow), rHigh);
      }
    }

    let weekStart = firstMonday;
    for (let w = 0; w < weeks; w++) {
      const ws = toISO(weekStart);
      const we = toISO(addDays(weekStart, 6));
      const tsId = await getOrCreateTimesheet({ EmployeeID: emp.EmployeeID, WeekStartDate: ws, WeekEndDate: we });
      for (let d = 0; d < 5; d++) {
        const day = addDays(weekStart, d);
        if (day < mStart || day > mEnd) continue;
        if (empAllocs.length >= 2) {
          const a1 = empAllocs[0];
          const a2 = empAllocs[1];
          const h1 = Math.round((dailyTotal * r) * 10) / 10;
          const h2 = Math.round((dailyTotal - h1) * 10) / 10;
          await addEntry({ TimesheetID: tsId, AllocationID: a1.AllocationID, EntryDate: toISO(day), Hours: h1, Notes: `${e.Team} work` });
          await addEntry({ TimesheetID: tsId, AllocationID: a2.AllocationID, EntryDate: toISO(day), Hours: h2, Notes: `${e.Team} work` });
        } else if (empAllocs.length === 1) {
          // If only one allocation, still keep some buffer below allocation by reducing daily hours to 0.9x
          const h = Math.round((dailyTotal * 0.9) * 10) / 10;
          await addEntry({ TimesheetID: tsId, AllocationID: empAllocs[0].AllocationID, EntryDate: toISO(day), Hours: h, Notes: `${e.Team} work` });
        }
      }
      weekStart = addDays(weekStart, 7);
    }
  }

  console.log('Seeding complete.');
}

seed().then(() => process.exit(0)).catch(err => { console.error(err); process.exit(1); });
