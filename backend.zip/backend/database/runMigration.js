import pool from '../config/db.js';

async function applyPMMigration() {
  try {
    console.log('Starting PM role migration...');
    
    // Drop old constraint and add new one that includes 'pm'
    await pool.query(`
      ALTER TABLE Employees
      DROP CONSTRAINT IF EXISTS employees_role_check;
    `);
    console.log('✓ Dropped old role constraint');

    await pool.query(`
      ALTER TABLE Employees
      ADD CONSTRAINT employees_role_check CHECK (Role IN ('admin', 'employee', 'pm'));
    `);
    console.log('✓ Added new role constraint with pm support');

    // Verify by checking if we can insert a test (just check the constraint exists)
    const result = await pool.query(`
      SELECT con.conname as constraint_name
      FROM pg_constraint con
      WHERE con.conrelid = 'employees'::regclass
      AND con.conname = 'employees_role_check'
    `);

    if (result.rows.length > 0) {
      console.log('✓ Constraint verified:', result.rows[0].constraint_name);
      console.log('\n✅ Migration successful! PM role is now supported.');
      console.log('You can now create and edit employees with role="pm"');
    } else {
      console.log('✓ Constraint added (could not verify, but no errors occurred)');
      console.log('\n✅ Migration completed! PM role is now supported.');
    }

    process.exit(0);
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    process.exit(1);
  }
}

applyPMMigration();
