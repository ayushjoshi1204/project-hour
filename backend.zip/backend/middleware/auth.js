import jwt from 'jsonwebtoken';

export const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

export const authorizeAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

export const authorizePM = (req, res, next) => {
  if (req.user.role !== 'pm') {
    return res.status(403).json({ error: 'Project Manager access required' });
  }
  next();
};

export const authorizeAdminOrPM = (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.role !== 'pm') {
    return res.status(403).json({ error: 'Admin or Project Manager access required' });
  }
  next();
};
