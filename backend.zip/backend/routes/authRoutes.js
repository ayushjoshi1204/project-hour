import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import pool from '../config/db.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find employee by email
    const result = await pool.query(
      'SELECT * FROM Employees WHERE Email = $1',
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const employee = result.rows[0];

    // Check if employee is active
    if (employee.status !== 'active') {
      return res.status(403).json({ error: 'Account is inactive' });
    }

    // Verify password
    const validPassword = await bcrypt.compare(password, employee.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        employeeId: employee.employeeid,
        empId: employee.empid,
        name: employee.name,
        email: employee.email,
        role: employee.role
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        employeeId: employee.employeeid,
        empId: employee.empid,
        name: employee.name,
        email: employee.email,
        role: employee.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// Signup
router.post('/signup', async (req, res) => {
  try {
    const { empId, name, email, password } = req.body;

    if (!empId || !name || !email || !password) {
      return res.status(400).json({ error: 'EmpID, name, email and password are required' });
    }

    // Check if email or EmpID already exists
    const existing = await pool.query(
      'SELECT 1 FROM Employees WHERE Email = $1 OR EmpID = $2',
      [email, empId]
    );

    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Email or EmpID is already registered' });
    }

    const doj = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const insertResult = await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING EmployeeID, EmpID, Name, Email, Role, DOJ, Status`,
      [empId, name, email, hashedPassword, 'employee', doj, 'active']
    );

    const employee = insertResult.rows[0];

    const token = jwt.sign(
      {
        employeeId: employee.employeeid,
        empId: employee.empid,
        name: employee.name,
        email: employee.email,
        role: employee.role
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: {
        employeeId: employee.employeeid,
        empId: employee.empid,
        name: employee.name,
        email: employee.email,
        role: employee.role
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Employee with this email or EmpID already exists' });
    }
    res.status(500).json({ error: 'Server error during signup' });
  }
});

// Get current user profile
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT EmployeeID, EmpID, Name, Email, Role, DOJ, Status, CreatedAt, UpdatedAt
       FROM Employees
       WHERE EmployeeID = $1`,
      [req.user.employeeId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Update current user profile
router.put('/me', authenticateToken, async (req, res) => {
  try {
    const { name, email, currentPassword, newPassword } = req.body;
    const userId = req.user.employeeId;

    if (!name && !email && !newPassword) {
      return res.status(400).json({ error: 'No changes provided' });
    }

    const userResult = await pool.query(
      'SELECT EmployeeID, Name, Email, Password FROM Employees WHERE EmployeeID = $1',
      [userId]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = userResult.rows[0];
    const updates = [];
    const values = [];
    let paramIndex = 1;

    if (name && name !== user.name) {
      updates.push(`Name = $${paramIndex++}`);
      values.push(name);
    }

    if (email && email !== user.email) {
      const existing = await pool.query(
        'SELECT 1 FROM Employees WHERE Email = $1 AND EmployeeID <> $2',
        [email, userId]
      );

      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'Email is already in use' });
      }

      updates.push(`Email = $${paramIndex++}`);
      values.push(email);
    }

    if (newPassword) {
      if (!currentPassword) {
        return res.status(400).json({ error: 'Current password is required to set a new password' });
      }

      const validPassword = await bcrypt.compare(currentPassword, user.password);
      if (!validPassword) {
        return res.status(400).json({ error: 'Current password is incorrect' });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      updates.push(`Password = $${paramIndex++}`);
      values.push(hashedPassword);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No changes detected' });
    }

    values.push(userId);

    const updateQuery = `
      UPDATE Employees
      SET ${updates.join(', ')}, UpdatedAt = NOW()
      WHERE EmployeeID = $${paramIndex}
      RETURNING EmployeeID, EmpID, Name, Email, Role, DOJ, Status, UpdatedAt
    `;

    const updated = await pool.query(updateQuery, values);

    res.json({
      message: 'Profile updated successfully',
      user: updated.rows[0],
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Update user role (admin only - for development/testing)
router.put('/user/:empId/role', async (req, res) => {
  try {
    const { empId } = req.params;
    const { newRole } = req.body;

    if (!newRole || !['admin', 'employee', 'pm'].includes(newRole)) {
      return res.status(400).json({ error: 'Invalid role. Must be admin, employee, or pm' });
    }

    const result = await pool.query(
      'UPDATE Employees SET Role = $1 WHERE EmpID = $2 RETURNING EmployeeID, EmpID, Name, Email, Role',
      [newRole, empId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.json({
      message: `User role updated to ${newRole}`,
      user: result.rows[0]
    });
  } catch (error) {
    console.error('Update role error:', error);
    res.status(500).json({ error: 'Server error during role update' });
  }
});

export default router;
