import express from 'express';
import pool from '../config/db.js';
import { authenticateToken, authorizeAdminOrPM } from '../middleware/auth.js';

const router = express.Router();

// Helper: count working days (Mon-Fri) between two dates (inclusive)
const countWorkingDays = (startDate, endDate) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  if (isNaN(start) || isNaN(end) || start > end) return 0;

  let count = 0;
  const current = new Date(start);
  while (current <= end) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) {
      // Monday-Friday
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  return count;
};

// Core availability calculation used by API and validation
const calculateAvailabilityForEmployeeProject = async (employeeId, projectId, excludeAllocationId = null) => {
  // Fetch employee (for DOJ & status)
  const empRes = await pool.query(
    'SELECT EmployeeID, DOJ, Status FROM Employees WHERE EmployeeID = $1',
    [employeeId]
  );
  if (empRes.rows.length === 0) {
    throw new Error('Employee not found');
  }
  const employee = empRes.rows[0];

  if (employee.status !== 'active') {
    return {
      employeeId,
      projectId,
      doj: employee.doj,
      projectStartDate: null,
      projectEndDate: null,
      totalWorkingDays: 0,
      totalAvailableHours: 0,
      allocatedHoursInWindow: 0,
      remainingHours: 0,
      isAvailable: false,
    };
  }

  // Fetch project (for date range)
  const projRes = await pool.query(
    'SELECT ProjectID, ProjectCode, StartDate, EndDate FROM Projects WHERE ProjectID = $1',
    [projectId]
  );
  if (projRes.rows.length === 0) {
    throw new Error('Project not found');
  }
  const project = projRes.rows[0];

  const doj = new Date(employee.doj);
  const projStart = new Date(project.startdate);
  const projEnd = new Date(project.enddate);

  // Effective availability window for this project = from max(DOJ, project start) to project end
  const effectiveStart = doj > projStart ? doj : projStart;
  const effectiveEnd = projEnd;

  if (effectiveStart > effectiveEnd) {
    return {
      employeeId,
      projectId,
      doj: employee.doj,
      projectStartDate: project.startdate,
      projectEndDate: project.enddate,
      totalWorkingDays: 0,
      totalAvailableHours: 0,
      allocatedHoursInWindow: 0,
      remainingHours: 0,
      isAvailable: false,
    };
  }

  const totalWorkingDays = countWorkingDays(effectiveStart, effectiveEnd);
  const HOURS_PER_DAY = 8.5;
  const totalAvailableHours = totalWorkingDays * HOURS_PER_DAY;

  // Fetch existing allocations for this employee that overlap this project window
  const params = [employeeId, effectiveStart, effectiveEnd];
  let overlapQuery = `
    SELECT a.AllocationID, a.AllocatedHours, p.ProjectCode, p.StartDate, p.EndDate
    FROM Allocations a
    JOIN Projects p ON a.ProjectID = p.ProjectID
    WHERE a.EmployeeID = $1
      AND p.EndDate >= $2
      AND p.StartDate <= $3
  `;
  if (excludeAllocationId) {
    params.push(excludeAllocationId);
    overlapQuery += ' AND a.AllocationID <> $4';
  }

  const allocRes = await pool.query(overlapQuery, params);

  let allocatedHoursInWindow = 0;

  allocRes.rows.forEach((alloc) => {
    const aStart = new Date(alloc.startdate);
    const aEnd = new Date(alloc.enddate);

    // For this allocation, consider only from DOJ onwards
    const allocEffectiveStart = doj > aStart ? doj : aStart;
    const allocEffectiveEnd = aEnd;
    if (allocEffectiveStart > allocEffectiveEnd) return;

    const projectWorkingDays = countWorkingDays(allocEffectiveStart, allocEffectiveEnd);
    if (projectWorkingDays === 0) return;

    // Overlap window with the current project availability window
    const overlapStart = effectiveStart > allocEffectiveStart ? effectiveStart : allocEffectiveStart;
    const overlapEnd = effectiveEnd < allocEffectiveEnd ? effectiveEnd : allocEffectiveEnd;
    if (overlapStart > overlapEnd) return;

    const overlapDays = countWorkingDays(overlapStart, overlapEnd);
    if (overlapDays === 0) return;

    const allocationRatePerDay = Number(alloc.allocatedhours) / projectWorkingDays;
    const hoursInWindow = allocationRatePerDay * overlapDays;
    allocatedHoursInWindow += hoursInWindow;
  });

  const remainingHours = totalAvailableHours - allocatedHoursInWindow;

  return {
    employeeId,
    projectId,
    doj: employee.doj,
    projectStartDate: project.startdate,
    projectEndDate: project.enddate,
    totalWorkingDays,
    totalAvailableHours,
    allocatedHoursInWindow,
    remainingHours,
    isAvailable: remainingHours > 0,
  };
};

// Get all allocations
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT a.*, e.Name as EmployeeName, p.ProjectCode, p.Entity 
       FROM Allocations a
       JOIN Employees e ON a.EmployeeID = e.EmployeeID
       JOIN Projects p ON a.ProjectID = p.ProjectID
       ORDER BY a.AllocationID`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get allocations error:', error);
    res.status(500).json({ error: 'Failed to fetch allocations' });
  }
});

// Availability endpoint: check capacity for employee + project
router.get('/availability', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { employeeId, projectId, excludeAllocationId } = req.query;

    if (!employeeId || !projectId) {
      return res.status(400).json({ error: 'employeeId and projectId are required' });
    }

    const availability = await calculateAvailabilityForEmployeeProject(
      Number(employeeId),
      Number(projectId),
      excludeAllocationId ? Number(excludeAllocationId) : null
    );

    res.json(availability);
  } catch (error) {
    console.error('Availability calculation error:', error);
    if (error.message === 'Employee not found' || error.message === 'Project not found') {
      return res.status(404).json({ error: error.message });
    }
    res.status(500).json({ error: 'Failed to calculate availability' });
  }
});

// Get allocations by employee
router.get('/employee/:employeeId', authenticateToken, async (req, res) => {
  try {
    const { employeeId } = req.params;
    const result = await pool.query(
      `SELECT a.*, p.ProjectCode, p.Entity, p.BillingAction, p.StartDate, p.EndDate, p.Status as ProjectStatus
       FROM Allocations a
       JOIN Projects p ON a.ProjectID = p.ProjectID
       WHERE a.EmployeeID = $1
       ORDER BY a.AllocationID`,
      [employeeId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get employee allocations error:', error);
    res.status(500).json({ error: 'Failed to fetch employee allocations' });
  }
});

// Get allocation by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT a.*, e.Name as EmployeeName, p.ProjectCode, p.Entity 
       FROM Allocations a
       JOIN Employees e ON a.EmployeeID = e.EmployeeID
       JOIN Projects p ON a.ProjectID = p.ProjectID
       WHERE a.AllocationID = $1`,
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Allocation not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get allocation error:', error);
    res.status(500).json({ error: 'Failed to fetch allocation' });
  }
});

// Create allocation (Admin only)
router.post('/', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { employeeId, projectId, empName, role, allocatedHours } = req.body;

    // Validation
    if (!employeeId || !projectId || !empName || !role || allocatedHours === undefined) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (allocatedHours < 0) {
      return res.status(400).json({ error: 'Allocated hours must be non-negative' });
    }

    // Check if employee & project exist and compute availability
    const availability = await calculateAvailabilityForEmployeeProject(Number(employeeId), Number(projectId));

    if (availability.totalAvailableHours === 0) {
      return res.status(400).json({ error: 'Employee is not available for this project period (no working days in range)' });
    }

    const remainingBefore = availability.remainingHours;
    const remainingAfter = remainingBefore - Number(allocatedHours);

    if (remainingAfter < -0.0001) {
      return res.status(400).json({
        error: `Employee over-allocated for this period. Remaining capacity is ${remainingBefore.toFixed(2)} hours, requested ${Number(allocatedHours).toFixed(2)} hours.`,
      });
    }

    const result = await pool.query(
      `INSERT INTO Allocations (EmployeeID, ProjectID, EmpName, Role, AllocatedHours) 
       VALUES ($1, $2, $3, $4, $5) 
       RETURNING *`,
      [employeeId, projectId, empName, role, allocatedHours]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create allocation error:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'Employee already allocated to this project' });
    } else {
      res.status(500).json({ error: 'Failed to create allocation' });
    }
  }
});

// Update allocation (Admin only)
router.put('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const { employeeId, projectId, empName, role, allocatedHours } = req.body;

    // Validation
    if (!employeeId || !projectId || !empName || !role || allocatedHours === undefined) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (allocatedHours < 0) {
      return res.status(400).json({ error: 'Allocated hours must be non-negative' });
    }

    // Recalculate availability excluding this allocation so admin can adjust
    const availability = await calculateAvailabilityForEmployeeProject(
      Number(employeeId),
      Number(projectId),
      Number(id)
    );

    if (availability.totalAvailableHours === 0) {
      return res.status(400).json({ error: 'Employee is not available for this project period (no working days in range)' });
    }

    const remainingBefore = availability.remainingHours;
    const remainingAfter = remainingBefore - Number(allocatedHours);

    if (remainingAfter < -0.0001) {
      return res.status(400).json({
        error: `Employee over-allocated for this period. Remaining capacity is ${remainingBefore.toFixed(2)} hours, requested ${Number(allocatedHours).toFixed(2)} hours.`,
      });
    }

    const result = await pool.query(
      `UPDATE Allocations 
       SET EmployeeID = $1, ProjectID = $2, EmpName = $3, Role = $4, AllocatedHours = $5 
       WHERE AllocationID = $6 
       RETURNING *`,
      [employeeId, projectId, empName, role, allocatedHours, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Allocation not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update allocation error:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'Employee already allocated to this project' });
    } else {
      res.status(500).json({ error: 'Failed to update allocation' });
    }
  }
});

// Delete allocation (Admin only)
router.delete('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'DELETE FROM Allocations WHERE AllocationID = $1 RETURNING AllocationID',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Allocation not found' });
    }

    res.json({ message: 'Allocation deleted successfully' });
  } catch (error) {
    console.error('Delete allocation error:', error);
    res.status(500).json({ error: 'Failed to delete allocation' });
  }
});

export default router;
