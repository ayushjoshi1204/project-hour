import express from 'express';
import bcrypt from 'bcrypt';
import pool from '../config/db.js';
import { authenticateToken, authorizeAdmin, authorizeAdminOrPM } from '../middleware/auth.js';

const router = express.Router();

const VALID_ROLES = ['admin', 'employee', 'pm'];
const EMPLOYEE_SELECT = `
  EmployeeID, EmpID, Name, Email, Role, DOJ, Status,
  Team, Tribe, WorkHoursPerWeek,
  CreatedAt, UpdatedAt
`;

// Get all employees (Admin + PM)
router.get('/', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees ORDER BY EmployeeID`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get employees error:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});

// Get employee by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees WHERE EmployeeID = $1`,
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get employee error:', error);
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
});

// Get employee by EmpID
router.get('/empid/:empid', authenticateToken, async (req, res) => {
  try {
    const { empid } = req.params;
    const result = await pool.query(
      `SELECT ${EMPLOYEE_SELECT} FROM Employees WHERE EmpID = $1`,
      [empid]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get employee by EmpID error:', error);
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
});

// Create employee (Admin + PM)
router.post('/', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { empId, name, email, password, role, doj } = req.body;

    // Validation
    if (!empId || !name || !email || !password || !role || !doj) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (!VALID_ROLES.includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO Employees (EmpID, Name, Email, Password, Role, DOJ, Status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING ${EMPLOYEE_SELECT}`,
      [empId, name, email, hashedPassword, role, doj, 'active']
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create employee error:', error);
    if (error.code === '23505') { // Unique violation
      res.status(400).json({ error: 'EmpID or Email already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create employee' });
    }
  }
});

// Update employee (Admin + PM)
router.put('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const { empId, name, email, role, doj, status } = req.body;

    // Validation
    if (!empId || !name || !email || !role || !doj || !status) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (!VALID_ROLES.includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    if (!['active', 'inactive'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const result = await pool.query(
      `UPDATE Employees 
       SET EmpID = $1, Name = $2, Email = $3, Role = $4, DOJ = $5, Status = $6 
       WHERE EmployeeID = $7 
       RETURNING ${EMPLOYEE_SELECT}`,
      [empId, name, email, role, doj, status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update employee error:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'EmpID or Email already exists' });
    } else {
      res.status(500).json({ error: 'Failed to update employee' });
    }
  }
});

// Delete employee (Admin + PM)
router.delete('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'DELETE FROM Employees WHERE EmployeeID = $1 RETURNING EmployeeID',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Delete employee error:', error);
    res.status(500).json({ error: 'Failed to delete employee' });
  }
});

export default router;
