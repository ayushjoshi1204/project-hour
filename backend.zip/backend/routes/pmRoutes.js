import express from 'express';
import pool from '../config/db.js';
import { authenticateToken, authorizePM } from '../middleware/auth.js';

const router = express.Router();

// Get all employees (for PM to manage)
router.get('/employees', authenticateToken, authorizePM, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM Employees WHERE Role = $1 ORDER BY Name', ['employee']);
    res.json(result.rows);
  } catch (error) {
    console.error('Get employees error:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});

// Get employee by ID
router.get('/employees/:id', authenticateToken, authorizePM, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM Employees WHERE EmployeeID = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get employee error:', error);
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
});

// Get all projects (for PM to manage)
router.get('/projects', authenticateToken, authorizePM, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM Projects ORDER BY ProjectCode`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Get all allocations (for PM to manage)
router.get('/allocations', authenticateToken, authorizePM, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT a.*, e.Name as EmployeeName, e.EmpID, p.ProjectCode
       FROM Allocations a
       JOIN Employees e ON a.EmployeeID = e.EmployeeID
       JOIN Projects p ON a.ProjectID = p.ProjectID
       ORDER BY e.Name, p.ProjectCode`
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get allocations error:', error);
    res.status(500).json({ error: 'Failed to fetch allocations' });
  }
});

// Get employee utilization (PM can view employee utilization but not tribe)
router.get('/utilization/employee/:empId', authenticateToken, authorizePM, async (req, res) => {
  try {
    const { empId } = req.params;
    const year = new Date().getFullYear();

    // Get employee info
    const empResult = await pool.query(
      'SELECT * FROM Employees WHERE EmployeeID = $1',
      [empId]
    );

    if (empResult.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const emp = empResult.rows[0];

    // Get monthly utilization data
    const monthlySeries = {};
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    for (let month = 1; month <= 12; month++) {
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0);
      const startStr = startDate.toISOString().split('T')[0];
      const endStr = endDate.toISOString().split('T')[0];

      const result = await pool.query(
        `SELECT 
           COALESCE(SUM(te.Hours), 0) as TimesheetHours,
           COALESCE(SUM(a.AllocatedHours), 0) as AllocatedHours
         FROM TimesheetEntries te
         JOIN Timesheets t ON te.TimesheetID = t.TimesheetID
         JOIN Allocations a ON te.AllocationID = a.AllocationID
         WHERE t.EmployeeID = $1 AND te.EntryDate BETWEEN $2 AND $3
         GROUP BY t.EmployeeID`,
        [empId, startStr, endStr]
      );

      const monthData = result.rows[0] || { timesheetHours: 0, allocatedHours: 0 };
      monthlySeries[monthNames[month - 1]] = {
        month: monthNames[month - 1],
        timesheetHours: Number(monthData.timesheethours || 0),
        allocatedHours: Number(monthData.allocatedhours || 0),
      };
    }

    res.json({
      empId: emp.employeeid,
      name: emp.name,
      workHoursPerWeek: emp.work_hours_per_week || 42.5,
      monthlySeries,
    });
  } catch (error) {
    console.error('Get employee utilization error:', error);
    res.status(500).json({ error: 'Failed to fetch utilization' });
  }
});

export default router;
