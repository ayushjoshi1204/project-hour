import express from 'express';
import pool from '../config/db.js';
import { authenticateToken, authorizeAdmin, authorizeAdminOrPM } from '../middleware/auth.js';

const router = express.Router();

// Get all projects
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM Projects ORDER BY ProjectID'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Get active projects
router.get('/active', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM Projects WHERE Status = 'active' ORDER BY ProjectID"
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get active projects error:', error);
    res.status(500).json({ error: 'Failed to fetch active projects' });
  }
});

// Get project by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT * FROM Projects WHERE ProjectID = $1',
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get project error:', error);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Create project (Admin only)
router.post('/', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { projectCode, entity, billingAction, startDate, endDate, status, tribe } = req.body;

    // Validation
    if (!projectCode || !entity || !billingAction || !startDate || !endDate) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Validate dates
    if (new Date(endDate) < new Date(startDate)) {
      return res.status(400).json({ error: 'End date must be after start date' });
    }

    // Validate tribe if provided
    if (tribe && !['UKI', 'Non-UKI'].includes(tribe)) {
      return res.status(400).json({ error: 'Tribe must be either UKI or Non-UKI' });
    }

    const result = await pool.query(
      `INSERT INTO Projects (ProjectCode, Entity, BillingAction, StartDate, EndDate, Status, Tribe) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING *`,
      [projectCode, entity, billingAction, startDate, endDate, status || 'active', tribe || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create project error:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'Project code already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create project' });
    }
  }
});

// Update project (Admin only)
router.put('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const { projectCode, entity, billingAction, startDate, endDate, status, tribe } = req.body;

    // Validation
    if (!projectCode || !entity || !billingAction || !startDate || !endDate || !status) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Validate dates
    if (new Date(endDate) < new Date(startDate)) {
      return res.status(400).json({ error: 'End date must be after start date' });
    }

    // Validate tribe if provided
    if (tribe && !['UKI', 'Non-UKI'].includes(tribe)) {
      return res.status(400).json({ error: 'Tribe must be either UKI or Non-UKI' });
    }

    const result = await pool.query(
      `UPDATE Projects 
       SET ProjectCode = $1, Entity = $2, BillingAction = $3, StartDate = $4, EndDate = $5, Status = $6, Tribe = $7
       WHERE ProjectID = $8 
       RETURNING *`,
      [projectCode, entity, billingAction, startDate, endDate, status, tribe || null, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update project error:', error);
    if (error.code === '23505') {
      res.status(400).json({ error: 'Project code already exists' });
    } else {
      res.status(500).json({ error: 'Failed to update project' });
    }
  }
});

// Delete project (Admin only)
router.delete('/:id', authenticateToken, authorizeAdminOrPM, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'DELETE FROM Projects WHERE ProjectID = $1 RETURNING ProjectID',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

export default router;
