import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import UtilizationSummaryCards from '../../components/Utilization/UtilizationSummaryCards';
import UtilizationBar from '../../components/Utilization/UtilizationBar';
import PieChart from '../../components/Analytics/PieChart';
import BarChart from '../../components/Analytics/BarChart';
import { exportCsv } from '../../components/Utilization/csv';
import '../../components/Utilization/utilization.css';

function useAuthToken() {
  const token = localStorage.getItem('token');
  return token;
}

async function apiGet(path, token) {
  const res = await fetch(path, { headers: { 'Authorization': `Bearer ${token}` }});
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

function colorCell(pct) {
  const p = Number(pct || 0);
  const bg = p >= 80 ? '#dcfce7' : p >= 50 ? '#fef3c7' : '#fee2e2';
  return { background: bg };
}

function clampPct(x) {
  const n = Number(x || 0);
  if (Number.isNaN(n)) return 0;
  if (n < 0) return 0;
  if (n > 100) return 100;
  return n;
}

const VALID_TABS = ['employee', 'tribe', 'team'];

export default function Utilization({
  allowedTabs = ['employee', 'tribe', 'team'],
  title = 'Utilization Dashboard (Admin)',
  employeeUtilizationBasePath = '/admin',
}) {
  const token = useAuthToken();
  const navigate = useNavigate();
  const permittedTabs = useMemo(() => {
    if (!Array.isArray(allowedTabs)) return ['employee'];
    const unique = allowedTabs.filter((tab, idx) => allowedTabs.indexOf(tab) === idx);
    const sanitized = unique.filter((tab) => VALID_TABS.includes(tab));
    return sanitized.length > 0 ? sanitized : ['employee'];
  }, [JSON.stringify(allowedTabs)]);
  const [tab, setTab] = useState(permittedTabs[0]);
  const [year, setYear] = useState(new Date().getUTCFullYear());
  const [month, setMonth] = useState(new Date().getUTCMonth() + 1);
  const [employeeId, setEmployeeId] = useState('');
  const [tribe, setTribe] = useState('UKI');
  const [team, setTeam] = useState('Developer');
  const [employees, setEmployees] = useState([]);

  // Search state for employee view (by EmpID or Name)
  const [employeeSearchInput, setEmployeeSearchInput] = useState('');
  const [employeeSearchQuery, setEmployeeSearchQuery] = useState('');

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [periodType, setPeriodType] = useState('month'); // 'month' | 'year'
  const [yearlySeries, setYearlySeries] = useState([]); // [{label, value}]

  async function loadEmployees() {
    try {
      const json = await apiGet('/api/employees', token);
      setEmployees(json || []);
      if (!employeeId && json && json.length > 0) {
        setEmployeeId(String(json[0].employeeid || json[0].employeeId || json[0].EmployeeID));
      }
    } catch (e) {
      // non-blocking
    }
  }

  async function load() {
    try {
      setLoading(true); setError('');
      setYearlySeries([]);

      // Team tab: special handling for yearly aggregation and overall team view
      if (tab === 'team') {
        const teamsList = ['PM', 'SA', 'BA', 'Developer', 'TribeLead'];
        const teamDisplay = {
          PM: 'Project Manager',
          SA: 'Solution Architect',
          BA: 'Business Analyst',
          Developer: 'Developer',
          TribeLead: 'Tribe Lead',
        };

        // Overall team view: aggregate across all teams for the selected month
        if (team === 'All' && periodType === 'month') {
          const results = await Promise.all(
            teamsList.map(t =>
              apiGet(`/api/dashboard/team?team=${encodeURIComponent(t)}&year=${year}&month=${month}`, token)
                .catch(() => ({ rows: [] }))
            )
          );

          const rows = [];
          let totalAvailable = 0, totalAllocated = 0, totalLogged = 0;

          results.forEach((res, idx) => {
            const key = teamsList[idx];
            const teamLabel = teamDisplay[key] || (key === 'TribeLead' ? 'Tribe Lead' : key);
            (res.rows || []).forEach(r => {
              rows.push({
                team: teamLabel,
                employeeId: r.employeeId,
                name: r.name,
                availableHours: r.availableHours,
                allocatedHours: r.allocatedHours,
                timesheetHours: r.timesheetHours,
                utilizationPercent: r.utilizationPercent
              });
              totalAvailable += r.availableHours || 0;
              totalAllocated += r.allocatedHours || 0;
              totalLogged += r.timesheetHours || 0;
            });
          });

          const utilizationPercent = totalAvailable > 0 ? Number((clampPct((totalLogged / totalAvailable) * 100)).toFixed(2)) : 0;
          setData({ team: 'All', period: { year, month }, availableHours: totalAvailable, allocatedHours: totalAllocated, timesheetHours: totalLogged, utilizationPercent, rows });
          return;
        }

        // Yearly overall view across all teams
        if (team === 'All' && periodType === 'year') {
          const months = Array.from({ length: 12 }, (_, i) => i + 1);
          const byEmployee = new Map();
          let totalAvailable = 0, totalAllocated = 0, totalLogged = 0;

          for (const m of months) {
            const monthlyResults = await Promise.all(
              teamsList.map(t =>
                apiGet(`/api/dashboard/team?team=${encodeURIComponent(t)}&year=${year}&month=${m}`, token)
                  .catch(() => ({ rows: [] }))
              )
            );

            monthlyResults.forEach((res, idx) => {
              const keyTeam = teamsList[idx];
              const teamLabel = teamDisplay[keyTeam] || (keyTeam === 'TribeLead' ? 'Tribe Lead' : keyTeam);
              (res.rows || []).forEach(row => {
                const empKey = `${teamLabel}:${row.employeeId}`;
                const existing = byEmployee.get(empKey) || {
                  team: teamLabel,
                  employeeId: row.employeeId,
                  name: row.name,
                  availableHours: 0,
                  allocatedHours: 0,
                  timesheetHours: 0,
                };
                existing.availableHours += row.availableHours || 0;
                existing.allocatedHours += row.allocatedHours || 0;
                existing.timesheetHours += row.timesheetHours || 0;
                byEmployee.set(empKey, existing);

                totalAvailable += row.availableHours || 0;
                totalAllocated += row.allocatedHours || 0;
                totalLogged += row.timesheetHours || 0;
              });
            });
          }

          const rows = Array.from(byEmployee.values()).map(r => {
            const util = r.availableHours > 0 ? clampPct((r.timesheetHours / r.availableHours) * 100) : 0;
            return { ...r, utilizationPercent: Number(util.toFixed(2)) };
          });

          const utilizationPercent = totalAvailable > 0
            ? Number((clampPct((totalLogged / totalAvailable) * 100)).toFixed(2))
            : 0;

          setData({
            team: 'All',
            period: { year },
            availableHours: totalAvailable,
            allocatedHours: totalAllocated,
            timesheetHours: totalLogged,
            utilizationPercent,
            rows,
          });
          return;
        }

        // Yearly view for a specific team: aggregate across 12 months
        if (team !== 'All' && periodType === 'year') {
          const months = Array.from({ length: 12 }, (_, i) => i + 1);
          const results = await Promise.all(
            months.map(m => apiGet(`/api/dashboard/team?team=${encodeURIComponent(team)}&year=${year}&month=${m}`, token))
          );

          const teamLabel = team === 'TribeLead' ? 'Tribe Lead' : team;
          const byEmployee = new Map();
          results.forEach(r => {
            (r.rows || []).forEach(row => {
              const key = row.employeeId;
              const existing = byEmployee.get(key) || {
                team: teamLabel,
                employeeId: row.employeeId,
                name: row.name,
                availableHours: 0,
                allocatedHours: 0,
                timesheetHours: 0
              };
              existing.availableHours += row.availableHours || 0;
              existing.allocatedHours += row.allocatedHours || 0;
              existing.timesheetHours += row.timesheetHours || 0;
              byEmployee.set(key, existing);
            });
          });

          const rows = Array.from(byEmployee.values()).map(r => {
            const util = r.availableHours > 0 ? clampPct((r.timesheetHours / r.availableHours) * 100) : 0;
            return { ...r, utilizationPercent: Number(util.toFixed(2)) };
          });

          const total = rows.reduce((acc, r) => {
            acc.availableHours += r.availableHours;
            acc.allocatedHours += r.allocatedHours;
            acc.timesheetHours += r.timesheetHours;
            return acc;
          }, { availableHours: 0, allocatedHours: 0, timesheetHours: 0 });
          const utilizationPercent = total.availableHours > 0 ? Number((clampPct((total.timesheetHours / total.availableHours) * 100)).toFixed(2)) : 0;

          setData({ team, period: { year }, ...total, utilizationPercent, rows });
          return;
        }
      }

      // Default behavior for employee and tribe tabs (and team monthly per-team view)
      let url = '';
      if (tab === 'employee') {
        if (!employeeId) {
          setData(null);
          setLoading(false);
          return;
        }
        url = `/api/dashboard/employee/${employeeId}?year=${year}&month=${month}`;
      }
      if (tab === 'tribe') url = `/api/dashboard/tribe?tribe=${encodeURIComponent(tribe)}&year=${year}&month=${month}`;
      if (tab === 'team' && team !== 'All') url = `/api/dashboard/team?team=${encodeURIComponent(team)}&year=${year}&month=${month}`;

      const json = url ? await apiGet(url, token) : null;
      if (json) setData(json);

      // If yearly selected for tribe, compute monthly utilization series across all 12 months
      if (periodType === 'year' && tab === 'tribe') {
        const months = Array.from({ length: 12 }, (_, i) => i + 1);
        const results = await Promise.all(months.map(m => apiGet(`/api/dashboard/tribe?tribe=${encodeURIComponent(tribe)}&year=${year}&month=${m}`, token)));
        const series = results.map((r, i) => ({ label: String(i+1).padStart(2,'0'), value: Number(r.utilizationPercent || 0) }));
        setYearlySeries(series);
      }
    } catch (e) { setError(String(e)); }
    finally { setLoading(false); }
  }

  useEffect(() => {
    if (!permittedTabs.includes(tab)) {
      setTab(permittedTabs[0]);
    }
  }, [permittedTabs, tab]);

  useEffect(() => { if (token) loadEmployees(); }, [token]);
  useEffect(() => { if (token) load(); }, [tab, periodType, year, month, tribe, team]);

  const filteredEmployees = useMemo(() => {
    const term = employeeSearchQuery.trim().toLowerCase();
    if (!term) return employees;
    return employees.filter(emp => {
      const name = (emp.name || '').toLowerCase();
      const idText = String(emp.empid || emp.employeeid || '').toLowerCase();
      return name.includes(term) || idText.includes(term);
    });
  }, [employees, employeeSearchQuery]);

  const chartRows = useMemo(() => {
    if (!data) return [];
    if (data.rows) {
      return data.rows.map(r => ({ label: r.name || r.projectCode || r.label, utilizationPercent: r.utilizationPercent }));
    }
    if (data.byProject) {
      return data.byProject.map(r => ({ label: r.projectCode, utilizationPercent: r.utilizationPercent }));
    }
    return [];
  }, [data]);

  return (
    <div className="container">
      <h2>{title}</h2>

      <div className="panel" style={{ marginBottom: 12 }}>
        <div className="filter-bar">
          {permittedTabs.includes('employee') && (
            <button onClick={() => setTab('employee')} disabled={tab==='employee'}>Employee</button>
          )}
          {permittedTabs.includes('tribe') && (
            <button onClick={() => setTab('tribe')} disabled={tab==='tribe'}>Tribe</button>
          )}
          {permittedTabs.includes('team') && (
            <button onClick={() => setTab('team')} disabled={tab==='team'}>Team</button>
          )}
        </div>
        {tab !== 'employee' && (
          <div className="filter-bar">
            {/* Period selector hidden for tribe view as requested */}
            {tab === 'team' && (
              <label>Period
                <select value={periodType} onChange={e=>setPeriodType(e.target.value)} style={{ width: 120, marginLeft: 6, marginRight: 12 }}>
                  <option value="month">Monthly</option>
                  <option value="year">Yearly</option>
                </select>
              </label>
            )}
            <label>Year <input type="number" value={year} onChange={e=>setYear(Number(e.target.value))} style={{ width: 100 }} /></label>
            {periodType === 'month' && (
              <label>Month <input type="number" value={month} onChange={e=>setMonth(Number(e.target.value))} min={1} max={12} style={{ width: 100 }} /></label>
            )}
            {tab==='tribe' && (
              <label>Tribe <select value={tribe} onChange={e=>setTribe(e.target.value)} style={{ width: 160 }}>
                <option>UKI</option>
                <option>Non-UKI</option>
              </select></label>
            )}
            {tab==='team' && (
              <label>Team <select value={team} onChange={e=>setTeam(e.target.value)} style={{ width: 200 }}>
                <option value="All">Overall</option>
                <option>PM</option>
                <option>SA</option>
                <option>BA</option>
                <option>Developer</option>
                <option value="TribeLead">Tribe Lead</option>
              </select></label>
            )}
            <button onClick={load}>Load</button>
            {data && (
              <button onClick={() => {
                const rows = data.rows || (data.byProject || []).map(r => ({ name: r.projectCode, allocated: r.allocated, logged: r.logged, utilizationPercent: r.utilizationPercent }));
                exportCsv(`util_${tab}_${year}_${month}.csv`, rows);
              }}>Export CSV</button>
            )}
          </div>
        )}
      </div>

      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}

      {/* Employee tab: navigate to detail page */}
      {tab==='employee' && (
        <div className="panel" style={{ marginTop: 12 }}>
          <h3>Employees</h3>
          <div className="filter-bar" style={{ marginBottom: 8 }}>
            <input
              type="text"
              placeholder="Search by EmpID or Name"
              value={employeeSearchInput}
              onChange={(e) => setEmployeeSearchInput(e.target.value)}
              style={{ width: 240 }}
            />
            <button type="button" onClick={() => setEmployeeSearchQuery(employeeSearchInput)}>Search</button>
            {employeeSearchQuery && (
              <button
                type="button"
                onClick={() => { setEmployeeSearchInput(''); setEmployeeSearchQuery(''); }}
              >
                Clear
              </button>
            )}
          </div>
          <table className="table">
            <thead>
              <tr><th>Name</th><th>ID</th><th>Action</th></tr>
            </thead>
            <tbody>
              {filteredEmployees.map(emp => (
                <tr key={emp.employeeid}>
                  <td>{emp.name}</td>
                  <td>{emp.empid}</td>
                  <td>
                    <button
                      onClick={() => navigate(`${employeeUtilizationBasePath}/employees/${emp.employeeid}/utilization`)}
                    >
                      View Utilization
                    </button>
                  </td>
                </tr>
              ))}
              {filteredEmployees.length === 0 && (
                <tr>
                  <td colSpan={3} style={{ textAlign: 'center', fontSize: 12 }}>No employees found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Tribe tab: show projects and nested teams/employees */}
      {tab==='tribe' && data && data.projects && (
        <div className="panel" style={{ marginTop: 12 }}>
          <h3>Projects in {tribe}</h3>
          {/* Period selector removed for tribe view; keep yearly chart only if explicitly loaded as yearly */}
          {periodType === 'year' && yearlySeries.length > 0 && (
            <div className="panel" style={{ marginTop: 8 }}>
              <h4>Yearly Utilization (%)</h4>
              <BarChart rows={yearlySeries} width={640} height={220} color="#34d399" />
            </div>
          )}
          {data.projects.map(p => {
            const empSlices = p.teams.flatMap(t => t.employees.map(e => ({ label: `${e.name} (${t.team})`, value: Number(e.timesheetHours||0), name: e.name, role: t.team })));
            return (
              <div key={p.projectId} className="panel" style={{ marginTop: 12 }}>
                <h4>{p.projectCode} (ID: {p.projectId})</h4>
                <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>Totals: Alloc {Number(p.totals.allocatedHours||0).toFixed(1)}h, Logged {Number(p.totals.timesheetHours||0).toFixed(1)}h, Util {Number(p.totals.utilizationPercent||0).toFixed(1)}%</div>
                <div style={{ display:'flex', gap:16, alignItems:'flex-start', flexWrap:'wrap' }}>
                  <div>
                    <h5 style={{ marginTop: 0 }}>Utilization by Member (Pie)</h5>
                    <PieChart slices={empSlices} size={320} innerRadius={0} />
                  </div>
                  <div style={{ flex:1, minWidth: 260 }}>
                    <table className="table" style={{ fontSize: 12 }}>
                      <thead><tr><th>Team</th><th>Employee</th><th>Allocated</th><th>Logged</th><th>Util%</th></tr></thead>
                      <tbody>
                        {p.teams.flatMap(t => t.employees.map(e => (
                          <tr key={`${t.team}-${e.employeeId}`}>
                            <td>{t.team}</td>
                            <td>{e.name}</td>
                            <td>{Number(e.allocatedHours).toFixed(1)}</td>
                            <td>{Number(e.timesheetHours).toFixed(1)}</td>
                            <td style={colorCell(e.utilizationPercent)}>{Number(e.utilizationPercent).toFixed(1)}%</td>
                          </tr>
                        )))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Team tab: show team-wise employee utilization */}
      {tab==='team' && data && data.rows && (
        <div className="panel" style={{ marginTop: 12 }}>
          <h3>
            {team === 'All'
              ? `All Teams - ${periodType === 'year' ? `Year ${year}` : `Month ${month}/${year}`}`
              : `Team ${team === 'TribeLead' ? 'Tribe Lead' : team} - ${periodType === 'year' ? `Year ${year}` : `Month ${month}/${year}`}`}
          </h3>

          <div className="team-util-grid">
              {(() => {
                // When viewing a specific team, use the selected team name for all rows
                const teamLabel = team === 'All' ? null : (team === 'TribeLead' ? 'Tribe Lead' : team);
                const groups = data.rows.reduce((acc, r) => {
                  // If viewing a specific team, use that team name; otherwise use r.team or 'Other'
                  const key = teamLabel || r.team || 'Other';
                  if (!acc[key]) acc[key] = [];
                  acc[key].push(r);
                  return acc;
                }, {});

                const order = [
                  'Developer',
                  'Project Manager',
                  'Solution Architect',
                  'Business Analyst',
                  'Factory Lead',
                  'Operations Manager',
                  'Operations Support',
                  'Tribe Lead',
                ];

                const orderedKeys = [
                  ...order.filter(k => groups[k]),
                  ...Object.keys(groups).filter(k => !order.includes(k)),
                ];

                const billedClass = (pct) => {
                  const p = Number(pct || 0);
                  if (p > 100) return 'billed-over';
                  if (p > 75) return 'billed-high';
                  if (p >= 50) return 'billed-mid';
                  return 'billed-low';
                };

                return orderedKeys.map(key => {
                  const rows = groups[key];
                  const avg = rows.length
                    ? rows.reduce((s, r) => s + Number(r.utilizationPercent || 0), 0) / rows.length
                    : 0;

                  return (
                    <div key={key} className="team-util-card">
                      <div className="team-util-header">
                        <div className="team-util-title">{key}</div>
                        <div className="team-util-average">
                          <span className="team-util-average-label">Utilization %</span>
                          <span className="team-util-average-value">{avg.toFixed(0)}%</span>
                        </div>
                      </div>
                      <table className="team-util-table">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Utilization %</th>
                          </tr>
                        </thead>
                        <tbody>
                          {rows.map(emp => {
                            const pct = Number(emp.utilizationPercent || 0);
                            // Use the team from emp if available, otherwise use the group key
                            const displayTeam = emp.team || key;
                            return (
                              <tr key={`${emp.employeeId}-${emp.name}`}>
                                <td>{emp.name}</td>
                                <td>{displayTeam}</td>
                                <td>
                                  <span className={`billed-pill ${billedClass(pct)}`}>
                                    {pct.toFixed(0)}%
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  );
                });
              })()}
            </div>
        </div>
      )}
    </div>
  );
}
