import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Signup from './pages/Signup';
import EmployeeDashboard from './pages/employee/EmployeeDashboard';
import Timesheet from './pages/employee/Timesheet';
import AdminDashboard from './pages/admin/AdminDashboard';
import Employees from './pages/admin/Employees';
import Projects from './pages/admin/Projects';
import Allocations from './pages/admin/Allocations';
import Utilization from './pages/admin/Utilization';
import TimesheetsAdmin from './pages/admin/Timesheets';
import EmployeeUtilization from './pages/employee/Utilization';
import AdminEmployeeUtilization from './pages/admin/EmployeeUtilization';
import PMDashboard from './pages/pm/PMDashboard';
import PMEmployees from './pages/pm/PMEmployees';
import PMProjects from './pages/pm/PMProjects';
import PMAllocations from './pages/pm/PMAllocations';
import PMUtilization from './pages/pm/PMUtilization';
import PMEmployeeUtilization from './pages/pm/PMEmployeeUtilization';
import Navbar from './components/Navbar';

const ProtectedRoute = ({ children, adminOnly = false, pmOnly = false }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (adminOnly && user.role !== 'admin') {
    return <Navigate to={user.role === 'pm' ? '/pm' : '/employee'} />;
  }

  if (pmOnly && user.role !== 'pm') {
    return <Navigate to={user.role === 'admin' ? '/admin' : '/employee'} />;
  }

  return children;
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <>
      {user && <Navbar />}
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to={user.role === 'admin' ? '/admin' : user.role === 'pm' ? '/pm' : '/employee'} />} />
        <Route path="/signup" element={!user ? <Signup /> : <Navigate to={user.role === 'admin' ? '/admin' : user.role === 'pm' ? '/pm' : '/employee'} />} />
        
        {/* Employee Routes */}
        <Route path="/employee" element={<ProtectedRoute><EmployeeDashboard /></ProtectedRoute>} />
        <Route path="/employee/timesheet" element={<ProtectedRoute><Timesheet /></ProtectedRoute>} />
        <Route path="/employee/utilization" element={<ProtectedRoute><EmployeeUtilization /></ProtectedRoute>} />
        
        {/* Admin Routes */}
        <Route path="/admin" element={<ProtectedRoute adminOnly><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/employees" element={<ProtectedRoute adminOnly><Employees /></ProtectedRoute>} />
        <Route path="/admin/projects" element={<ProtectedRoute adminOnly><Projects /></ProtectedRoute>} />
        <Route path="/admin/allocations" element={<ProtectedRoute adminOnly><Allocations /></ProtectedRoute>} />
        <Route path="/admin/timesheets" element={<ProtectedRoute adminOnly><TimesheetsAdmin /></ProtectedRoute>} />
        <Route path="/admin/utilization" element={<ProtectedRoute adminOnly><Utilization /></ProtectedRoute>} />
        <Route path="/admin/employees/:employeeId/utilization" element={<ProtectedRoute adminOnly><AdminEmployeeUtilization /></ProtectedRoute>} />
        
        {/* PM Routes */}
        <Route path="/pm" element={<ProtectedRoute pmOnly><PMDashboard /></ProtectedRoute>} />
        <Route path="/pm/employees" element={<ProtectedRoute pmOnly><PMEmployees /></ProtectedRoute>} />
        <Route path="/pm/projects" element={<ProtectedRoute pmOnly><PMProjects /></ProtectedRoute>} />
        <Route path="/pm/allocations" element={<ProtectedRoute pmOnly><PMAllocations /></ProtectedRoute>} />
        <Route path="/pm/utilization" element={<ProtectedRoute pmOnly><PMUtilization /></ProtectedRoute>} />
        <Route path="/pm/employees/:employeeId/utilization" element={<ProtectedRoute pmOnly><PMEmployeeUtilization /></ProtectedRoute>} />
        
        <Route path="/" element={<Navigate to={user ? (user.role === 'admin' ? '/admin' : user.role === 'pm' ? '/pm' : '/employee') : '/login'} />} />
      </Routes>
    </>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;
